"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import type { TeacherLog } from "@/lib/types"
import { Plus, FileText } from "lucide-react"

export default function TeacherLogsPage() {
  const { user } = useAuth()
  const [logs, setLogs] = useState<TeacherLog[]>(dataStore.getTeacherLogs())
  const [dialogOpen, setDialogOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState<string>("all")

  const [formData, setFormData] = useState({
    studentId: "",
    subject: "",
    notes: "",
    strikes: 0,
  })

  if (!user) return null

  const isTeacher = user.role === "teacher"
  const students = dataStore.getStudents()
  const subjects = dataStore.getSubjects()
  const teacher = dataStore.getTeacherByUserId(user.id)

  // Filter logs
  let visibleLogs = logs
  if (selectedStudent !== "all") {
    visibleLogs = logs.filter((l) => l.studentId === selectedStudent)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const student = students.find((s) => s.id === formData.studentId)

    const newLog: TeacherLog = {
      id: Date.now().toString(),
      teacherId: teacher?.id || user.id,
      ...formData,
      date: new Date().toISOString(),
    }

    dataStore.addTeacherLog(newLog)

    // Notify parent if strikes > 0
    if (formData.strikes > 0 && student) {
      dataStore.addNotification({
        id: Date.now().toString(),
        userId: student.parentId,
        title: "Обновени наказания",
        message: `${student.name} вече има ${formData.strikes} наказание/я. Предмет: ${formData.subject}`,
        type: "warning",
        read: false,
        createdAt: new Date().toISOString(),
      })
    }

    setLogs(dataStore.getTeacherLogs())
    setDialogOpen(false)
    setFormData({ studentId: "", subject: "", notes: "", strikes: 0 })
  }

  const handleUpdateStrikes = (logId: string, strikes: number) => {
    if (strikes < 0 || strikes > 5) return

    dataStore.updateTeacherLog(logId, { strikes })
    setLogs(dataStore.getTeacherLogs())
  }

  // Render strike circles
  const StrikeIndicator = ({
    strikes,
    onUpdate,
    logId,
  }: { strikes: number; onUpdate?: (s: number) => void; logId?: string }) => (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          onClick={() => onUpdate && logId && onUpdate(i === strikes ? i - 1 : i)}
          className={`w-5 h-5 rounded-full border-2 transition-colors ${
            i <= strikes
              ? "bg-red-500 border-red-500"
              : "bg-transparent border-muted-foreground/30 hover:border-red-300"
          } ${onUpdate ? "cursor-pointer" : "cursor-default"}`}
          disabled={!onUpdate}
          aria-label={`Наказание ${i}`}
        >
          <span className="sr-only">Наказание {i}</span>
        </button>
      ))}
      <span className="ml-2 text-sm text-muted-foreground">{strikes}/5</span>
    </div>
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Учителски дневник</h1>
            <p className="text-muted-foreground">Записи за ученици с проследяване на наказания (макс. 5)</p>
          </div>
          {isTeacher && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Нов запис
            </Button>
          )}
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <Label className="mb-1 block">Филтриране по ученик</Label>
                <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете ученик" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Всички ученици</SelectItem>
                    {students.map((student) => (
                      <SelectItem key={student.id} value={student.id}>
                        {student.name} ({student.class})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Logs Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Учителски записи ({visibleLogs.length})
            </CardTitle>
            <CardDescription>
              Кликнете върху кръгчетата за наказания, за да добавите или премахнете (макс. 5)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Дата</TableHead>
                    <TableHead>Ученик</TableHead>
                    <TableHead>Училище</TableHead>
                    <TableHead>Град</TableHead>
                    <TableHead>Държава</TableHead>
                    <TableHead>Предмет</TableHead>
                    <TableHead>Бележки</TableHead>
                    <TableHead>Наказания</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visibleLogs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                        Няма намерени записи
                      </TableCell>
                    </TableRow>
                  ) : (
                    visibleLogs.map((log) => {
                      const student = students.find((s) => s.id === log.studentId)
                      return (
                        <TableRow key={log.id}>
                          <TableCell>{new Date(log.date).toLocaleDateString("bg-BG")}</TableCell>
                          <TableCell className="font-medium">{student?.name || "Неизвестен"}</TableCell>
                          <TableCell>{student?.school || "-"}</TableCell>
                          <TableCell>{student?.city || "-"}</TableCell>
                          <TableCell>{student?.country || "-"}</TableCell>
                          <TableCell>{log.subject}</TableCell>
                          <TableCell className="max-w-xs truncate">{log.notes}</TableCell>
                          <TableCell>
                            <StrikeIndicator
                              strikes={log.strikes}
                              onUpdate={isTeacher ? (s) => handleUpdateStrikes(log.id, s) : undefined}
                              logId={log.id}
                            />
                          </TableCell>
                        </TableRow>
                      )
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* New Log Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Нов учителски запис</DialogTitle>
              <DialogDescription>Създайте нов запис за ученик</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Ученик</Label>
                <Select value={formData.studentId} onValueChange={(v) => setFormData({ ...formData, studentId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете ученик" />
                  </SelectTrigger>
                  <SelectContent>
                    {students.map((student) => (
                      <SelectItem key={student.id} value={student.id}>
                        {student.name} ({student.class}) - {student.school}, {student.city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Предмет</Label>
                <Select value={formData.subject} onValueChange={(v) => setFormData({ ...formData, subject: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете предмет" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.name}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Бележки</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="Бележки към записа..."
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Начални наказания (0-5)</Label>
                <StrikeIndicator
                  strikes={formData.strikes}
                  onUpdate={(s) => setFormData({ ...formData, strikes: s })}
                  logId="new"
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit" disabled={!formData.studentId || !formData.subject}>
                  Създай запис
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
