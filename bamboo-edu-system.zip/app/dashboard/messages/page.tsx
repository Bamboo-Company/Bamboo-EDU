"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { dataStore } from "@/lib/data-store"
import type { Message } from "@/lib/types"
import { Plus, Inbox, Send, Mail, MailOpen, Reply, Search, AlertCircle } from "lucide-react"

const ROLE_LABELS: Record<string, string> = {
  admin: "Администратор",
  principal: "Директор",
  "vice-principal": "Зам.-директор",
  teacher: "Учител",
  psychologist: "Психолог",
  nurse: "Мед. сестра",
  student: "Ученик",
  parent: "Родител",
}

export default function MessagesPage() {
  const { user } = useAuth()
  const [messages, setMessages] = useState<Message[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const [selectedMessage, setSelectedMessage] = useState<Message | null>(null)
  const [activeTab, setActiveTab] = useState<"inbox" | "sent">("inbox")
  const [searchTerm, setSearchTerm] = useState("")
  const [replyMode, setReplyMode] = useState(false)

  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([])
  const [isImportant, setIsImportant] = useState(false)

  const [formData, setFormData] = useState({
    receiverId: "",
    subject: "",
    content: "",
  })

  const refreshData = useCallback(() => {
    setMessages(dataStore.getMessages())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user) return null

  const allUsers = dataStore.getUsers().filter((u) => u.id !== user.id)
  const canMarkImportant = ["admin", "principal", "vice-principal"].includes(user.role)

  // Get inbox and sent messages - Support multiple recipients
  const inbox = messages.filter((m) => m.receiverId === user.id || (m.receiverIds && m.receiverIds.includes(user.id)))
  const sent = messages.filter((m) => m.senderId === user.id)

  const unreadCount = inbox.filter((m) => !m.read).length

  // Filter by search
  const filteredMessages = (activeTab === "inbox" ? inbox : sent).filter((m) => {
    const otherUserId = activeTab === "inbox" ? m.senderId : m.receiverId
    const otherUser = allUsers.find((u) => u.id === otherUserId)
    const searchLower = searchTerm.toLowerCase()
    return (
      m.subject.toLowerCase().includes(searchLower) ||
      m.content.toLowerCase().includes(searchLower) ||
      otherUser?.name.toLowerCase().includes(searchLower)
    )
  })

  const toggleRecipient = (userId: string) => {
    setSelectedRecipients((prev) => (prev.includes(userId) ? prev.filter((id) => id !== userId) : [...prev, userId]))
  }

  const selectAllRecipients = () => {
    if (selectedRecipients.length === allUsers.length) {
      setSelectedRecipients([])
    } else {
      setSelectedRecipients(allUsers.map((u) => u.id))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const recipientIds = selectedRecipients.length > 0 ? selectedRecipients : [formData.receiverId]

    if (recipientIds.length === 0 || recipientIds[0] === "") return

    const newMessage: Message = {
      id: `${Date.now()}-msg-${Math.random().toString(36).substr(2, 9)}`,
      senderId: user.id,
      receiverId: recipientIds[0],
      receiverIds: recipientIds,
      subject: formData.subject,
      content: formData.content,
      read: false,
      important: isImportant,
      createdAt: new Date().toISOString(),
    }

    dataStore.addMessage(newMessage)

    // Add notifications for all recipients
    recipientIds.forEach((recipientId) => {
      dataStore.addNotification({
        id: `notif-${Date.now()}-${recipientId}-${Math.random().toString(36).substr(2, 9)}`,
        userId: recipientId,
        title: isImportant ? "Важно съобщение" : "Ново съобщение",
        message: `${user.name}: ${formData.subject}`,
        type: isImportant ? "warning" : "info",
        read: false,
        createdAt: new Date().toISOString(),
      })
    })

    refreshData()
    setDialogOpen(false)
    setReplyMode(false)
    setSelectedRecipients([])
    setIsImportant(false)
    setFormData({ receiverId: "", subject: "", content: "" })
  }

  const viewMessage = (message: Message) => {
    // Mark as read
    if (!message.read && (message.receiverId === user.id || message.receiverIds?.includes(user.id))) {
      dataStore.markMessageRead(message.id)
      refreshData()
    }
    setSelectedMessage(message)
    setViewDialogOpen(true)
  }

  const handleReply = () => {
    if (!selectedMessage) return
    setFormData({
      receiverId: selectedMessage.senderId,
      subject: `RE: ${selectedMessage.subject}`,
      content: "",
    })
    setSelectedRecipients([selectedMessage.senderId])
    setViewDialogOpen(false)
    setReplyMode(true)
    setDialogOpen(true)
  }

  const handleDeleteMessage = (messageId: string) => {
    dataStore.deleteMessage(messageId)
    refreshData()
    setViewDialogOpen(false)
    setSelectedMessage(null)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Съобщения</h1>
            <p className="text-muted-foreground">
              {unreadCount > 0 ? `${unreadCount} непрочетени съобщения` : "Няма непрочетени съобщения"}
            </p>
          </div>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Ново съобщение
          </Button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Търсене в съобщенията..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "inbox" | "sent")}>
          <TabsList>
            <TabsTrigger value="inbox" className="flex items-center gap-2">
              <Inbox className="w-4 h-4" />
              Входящи
              {unreadCount > 0 && (
                <Badge variant="destructive" className="ml-1">
                  {unreadCount}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="sent" className="flex items-center gap-2">
              <Send className="w-4 h-4" />
              Изпратени
            </TabsTrigger>
          </TabsList>

          <TabsContent value="inbox" className="mt-4">
            <Card className="bg-card border-border">
              <CardContent className="p-0">
                {filteredMessages.length > 0 ? (
                  <div className="divide-y divide-border">
                    {filteredMessages.map((message) => {
                      const sender = dataStore.getUsers().find((u) => u.id === message.senderId)
                      return (
                        <div
                          key={message.id}
                          className={`p-4 cursor-pointer hover:bg-muted/50 transition-colors ${!message.read ? "bg-primary/5" : ""}`}
                          onClick={() => viewMessage(message)}
                        >
                          <div className="flex items-start gap-3">
                            <Avatar>
                              <AvatarFallback>{sender?.name?.charAt(0) || "?"}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                {!message.read && <Mail className="w-4 h-4 text-primary" />}
                                {message.read && <MailOpen className="w-4 h-4 text-muted-foreground" />}
                                {message.important && <AlertCircle className="w-4 h-4 text-red-500" />}
                                <span
                                  className={`font-medium ${!message.read ? "text-foreground" : "text-muted-foreground"}`}
                                >
                                  {sender?.name || "Неизвестен"}
                                </span>
                                <Badge variant="outline" className="text-xs">
                                  {ROLE_LABELS[sender?.role || ""] || sender?.role}
                                </Badge>
                              </div>
                              <p
                                className={`font-medium ${!message.read ? "text-foreground" : "text-muted-foreground"}`}
                              >
                                {message.subject}
                              </p>
                              <p className="text-sm text-muted-foreground truncate">{message.content}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {new Date(message.createdAt).toLocaleString("bg-BG")}
                              </p>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">Няма съобщения</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sent" className="mt-4">
            <Card className="bg-card border-border">
              <CardContent className="p-0">
                {filteredMessages.length > 0 ? (
                  <div className="divide-y divide-border">
                    {filteredMessages.map((message) => {
                      const recipientCount = message.receiverIds?.length || 1
                      const firstRecipient = dataStore.getUsers().find((u) => u.id === message.receiverId)
                      return (
                        <div
                          key={message.id}
                          className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
                          onClick={() => viewMessage(message)}
                        >
                          <div className="flex items-start gap-3">
                            <Avatar>
                              <AvatarFallback>{firstRecipient?.name?.charAt(0) || "?"}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2">
                                <Send className="w-4 h-4 text-muted-foreground" />
                                {message.important && <AlertCircle className="w-4 h-4 text-red-500" />}
                                <span className="font-medium text-muted-foreground">
                                  До: {firstRecipient?.name || "Неизвестен"}
                                  {recipientCount > 1 && ` (+${recipientCount - 1} други)`}
                                </span>
                              </div>
                              <p className="font-medium text-foreground">{message.subject}</p>
                              <p className="text-sm text-muted-foreground truncate">{message.content}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {new Date(message.createdAt).toLocaleString("bg-BG")}
                              </p>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-8">Няма изпратени съобщения</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Compose Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{replyMode ? "Отговор" : "Ново съобщение"}</DialogTitle>
              <DialogDescription>
                {replyMode ? "Изпратете отговор на съобщението" : "Изберете получатели и напишете съобщение"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                {/* Recipients Selection */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Получатели *</Label>
                    <Button type="button" variant="outline" size="sm" onClick={selectAllRecipients}>
                      {selectedRecipients.length === allUsers.length ? "Изчисти всички" : "Избери всички"}
                    </Button>
                  </div>
                  <div className="border border-border rounded-md p-3 max-h-48 overflow-y-auto space-y-2">
                    {allUsers.map((u) => (
                      <div
                        key={u.id}
                        className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded cursor-pointer"
                        onClick={() => toggleRecipient(u.id)}
                      >
                        <Checkbox
                          checked={selectedRecipients.includes(u.id)}
                          onCheckedChange={() => toggleRecipient(u.id)}
                        />
                        <span>{u.name}</span>
                        <Badge variant="outline" className="text-xs ml-auto">
                          {ROLE_LABELS[u.role] || u.role}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  {selectedRecipients.length > 0 && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Избрани: {selectedRecipients.length} получателя
                    </p>
                  )}
                </div>

                {/* Important Checkbox - Only for directors */}
                {canMarkImportant && (
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id="important"
                      checked={isImportant}
                      onCheckedChange={(checked) => setIsImportant(checked as boolean)}
                    />
                    <Label htmlFor="important" className="flex items-center gap-2 cursor-pointer">
                      <AlertCircle className="w-4 h-4 text-red-500" />
                      Маркирай като важно
                    </Label>
                  </div>
                )}

                <div>
                  <Label>Тема *</Label>
                  <Input
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="Въведете тема"
                    required
                  />
                </div>

                <div>
                  <Label>Съдържание *</Label>
                  <Textarea
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    placeholder="Напишете съобщението..."
                    rows={5}
                    required
                  />
                </div>
              </div>
              <DialogFooter className="mt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setDialogOpen(false)
                    setReplyMode(false)
                    setSelectedRecipients([])
                    setIsImportant(false)
                  }}
                >
                  Отказ
                </Button>
                <Button
                  type="submit"
                  disabled={selectedRecipients.length === 0 || !formData.subject || !formData.content}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Изпрати
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* View Message Dialog */}
        <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
          <DialogContent className="max-w-2xl">
            {selectedMessage && (
              <>
                <DialogHeader>
                  <div className="flex items-center gap-2">
                    {selectedMessage.important && <AlertCircle className="w-5 h-5 text-red-500" />}
                    <DialogTitle>{selectedMessage.subject}</DialogTitle>
                  </div>
                  <DialogDescription>
                    {activeTab === "inbox" ? "От" : "До"}:{" "}
                    {dataStore
                      .getUsers()
                      .find(
                        (u) => u.id === (activeTab === "inbox" ? selectedMessage.senderId : selectedMessage.receiverId),
                      )?.name || "Неизвестен"}
                    {selectedMessage.receiverIds && selectedMessage.receiverIds.length > 1 && activeTab === "sent" && (
                      <span> (+{selectedMessage.receiverIds.length - 1} други)</span>
                    )}
                    <br />
                    {new Date(selectedMessage.createdAt).toLocaleString("bg-BG")}
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  <p className="whitespace-pre-wrap">{selectedMessage.content}</p>
                </div>
                <DialogFooter>
                  <Button variant="destructive" onClick={() => handleDeleteMessage(selectedMessage.id)}>
                    Изтрий
                  </Button>
                  {activeTab === "inbox" && (
                    <Button onClick={handleReply}>
                      <Reply className="w-4 h-4 mr-2" />
                      Отговори
                    </Button>
                  )}
                </DialogFooter>
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
