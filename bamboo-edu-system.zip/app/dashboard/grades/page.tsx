"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { dataStore } from "@/lib/data-store"
import type { Grade, Subject } from "@/lib/types"
import { Plus, BarChart3, TrendingUp, Trash2 } from "lucide-react"

const GRADE_CONFIG: Record<number, { label: string; color: string; bgColor: string }> = {
  6: { label: "6 (Отличен)", color: "text-green-500", bgColor: "bg-green-500/20 border-green-500" },
  5: { label: "5 (Много добър)", color: "text-blue-500", bgColor: "bg-blue-500/20 border-blue-500" },
  4: { label: "4 (Добър)", color: "text-yellow-300", bgColor: "bg-yellow-300/20 border-yellow-300" },
  3: { label: "3 (Среден)", color: "text-yellow-500", bgColor: "bg-yellow-500/20 border-yellow-500" },
  2: { label: "2 (Слаб)", color: "text-red-500", bgColor: "bg-red-500/20 border-red-500" },
}

const GRADE_TYPE_LABELS: Record<string, string> = {
  current: "Текуща",
  term1: "1-ви срок",
  term2: "2-ри срок",
  yearly: "Годишна",
}

export default function GradesPage() {
  const { user } = useAuth()
  const [grades, setGrades] = useState<Grade[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState<string>("all")
  const [selectedSubject, setSelectedSubject] = useState<string>("all")
  const [selectedGradeType, setSelectedGradeType] = useState<string>("all")

  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([])
  const [formData, setFormData] = useState({
    subject: "",
    score: 6,
    assignmentName: "",
    gradeType: "current" as "current" | "term1" | "term2" | "yearly",
  })

  const refreshData = useCallback(() => {
    setGrades(dataStore.getGrades())
    setSubjects(dataStore.getSubjects())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user) return null

  const isTeacher = ["admin", "principal", "vice-principal", "teacher"].includes(user.role)
  const isStudent = user.role === "student"
  const isParent = user.role === "parent"

  const students = dataStore.getStudents()
  const teacher = isTeacher ? dataStore.getTeacherByUserId(user.id) : null

  // Filter grades based on role
  let visibleGrades = grades
  if (isStudent) {
    const student = students.find((s) => s.name === user.name || s.linkedUserId === user.id)
    if (student) visibleGrades = grades.filter((g) => g.studentId === student.id)
  } else if (isParent) {
    const childIds = students.filter((s) => s.parentId === user.id).map((s) => s.id)
    visibleGrades = grades.filter((g) => childIds.includes(g.studentId))
  }

  // Apply filters
  if (selectedStudent !== "all") {
    visibleGrades = visibleGrades.filter((g) => g.studentId === selectedStudent)
  }
  if (selectedSubject !== "all") {
    visibleGrades = visibleGrades.filter((g) => g.subject === selectedSubject)
  }
  if (selectedGradeType !== "all") {
    visibleGrades = visibleGrades.filter((g) => g.gradeType === selectedGradeType)
  }

  const getSubjectGradeTypes = (subjectName: string) => {
    const subject = subjects.find((s) => s.name === subjectName)
    if (!subject) return ["current", "term1", "term2", "yearly"]

    const types: string[] = []
    if (subject.allowCurrentGrades) types.push("current")
    if (subject.allowTermGrades) {
      types.push("term1")
      types.push("term2")
    }
    if (subject.allowYearlyGrades) types.push("yearly")
    return types
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (selectedStudentIds.length === 0) return

    selectedStudentIds.forEach((studentId) => {
      const newGrade: Grade = {
        id: `${Date.now()}-${studentId}-${Math.random().toString(36).substr(2, 9)}`,
        studentId,
        subject: formData.subject,
        score: formData.score,
        maxScore: 6,
        assignmentName: formData.assignmentName,
        date: new Date().toISOString(),
        teacherId: teacher?.id || user.id,
        gradeType: formData.gradeType,
      }

      dataStore.addGrade(newGrade)

      // Notify parent
      const student = students.find((s) => s.id === studentId)
      if (student?.parentId) {
        dataStore.addNotification({
          id: Date.now().toString() + Math.random(),
          userId: student.parentId,
          title: "Нова оценка",
          message: `${student.name} получи ${formData.score} по ${formData.subject} (${GRADE_TYPE_LABELS[formData.gradeType]})`,
          type: "info",
          read: false,
          createdAt: new Date().toISOString(),
        })
      }
    })

    // Refresh state from dataStore
    refreshData()
    setDialogOpen(false)
    setSelectedStudentIds([])
    setFormData({ subject: "", score: 6, assignmentName: "", gradeType: "current" })
  }

  const handleDeleteGrade = (gradeId: string) => {
    dataStore.deleteGrade(gradeId)
    refreshData()
  }

  const toggleStudentSelection = (studentId: string) => {
    setSelectedStudentIds((prev) =>
      prev.includes(studentId) ? prev.filter((id) => id !== studentId) : [...prev, studentId],
    )
  }

  const selectAllStudents = () => {
    if (selectedStudentIds.length === students.length) {
      setSelectedStudentIds([])
    } else {
      setSelectedStudentIds(students.map((s) => s.id))
    }
  }

  const calculateAverages = () => {
    const studentGrades = selectedStudent !== "all" ? grades.filter((g) => g.studentId === selectedStudent) : []

    const subjectAverages: Record<
      string,
      {
        current: { total: number; count: number; average: number }
        term1: { total: number; count: number; average: number }
        term2: { total: number; count: number; average: number }
        yearly: { total: number; count: number; average: number }
        overall: { total: number; count: number; average: number }
      }
    > = {}

    studentGrades.forEach((grade) => {
      if (!subjectAverages[grade.subject]) {
        subjectAverages[grade.subject] = {
          current: { total: 0, count: 0, average: 0 },
          term1: { total: 0, count: 0, average: 0 },
          term2: { total: 0, count: 0, average: 0 },
          yearly: { total: 0, count: 0, average: 0 },
          overall: { total: 0, count: 0, average: 0 },
        }
      }

      const gradeType = grade.gradeType || "current"
      subjectAverages[grade.subject][gradeType].total += grade.score
      subjectAverages[grade.subject][gradeType].count++
      subjectAverages[grade.subject][gradeType].average =
        subjectAverages[grade.subject][gradeType].total / subjectAverages[grade.subject][gradeType].count

      // Overall average
      subjectAverages[grade.subject].overall.total += grade.score
      subjectAverages[grade.subject].overall.count++
      subjectAverages[grade.subject].overall.average =
        subjectAverages[grade.subject].overall.total / subjectAverages[grade.subject].overall.count
    })

    return subjectAverages
  }

  const averages = calculateAverages()

  const getGradeDisplay = (score: number) => {
    const config = GRADE_CONFIG[score] || GRADE_CONFIG[2]
    return (
      <span className={`px-2 py-1 rounded border text-sm font-bold ${config.bgColor} ${config.color}`}>
        {config.label}
      </span>
    )
  }

  const getGradeTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      current: "bg-blue-500/20 text-blue-500 border-blue-500",
      term1: "bg-purple-500/20 text-purple-500 border-purple-500",
      term2: "bg-orange-500/20 text-orange-500 border-orange-500",
      yearly: "bg-green-500/20 text-green-500 border-green-500",
    }
    return <Badge className={`${colors[type] || colors.current} border`}>{GRADE_TYPE_LABELS[type] || "Текуща"}</Badge>
  }

  // Get subjects that have at least one grade type enabled
  const availableSubjects = subjects.filter((s) => s.allowCurrentGrades || s.allowTermGrades || s.allowYearlyGrades)

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Оценки</h1>
            <p className="text-muted-foreground">
              {isTeacher ? "Въведете и управлявайте оценките на учениците" : "Прегледайте вашите оценки"}
            </p>
          </div>
          {isTeacher && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Добави оценка
            </Button>
          )}
        </div>

        {/* Filters */}
        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              {isTeacher && (
                <div className="flex-1">
                  <Label className="mb-1 block">Ученик</Label>
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger>
                      <SelectValue placeholder="Изберете ученик" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Всички ученици</SelectItem>
                      {students.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.name} ({student.class})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div className="flex-1">
                <Label className="mb-1 block">Предмет</Label>
                <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете предмет" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Всички предмети</SelectItem>
                    {availableSubjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.name}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label className="mb-1 block">Тип оценка</Label>
                <Select value={selectedGradeType} onValueChange={setSelectedGradeType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете тип" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Всички типове</SelectItem>
                    <SelectItem value="current">Текущи</SelectItem>
                    <SelectItem value="term1">1-ви срок</SelectItem>
                    <SelectItem value="term2">2-ри срок</SelectItem>
                    <SelectItem value="yearly">Годишни</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Grades Table */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Списък с оценки
            </CardTitle>
            <CardDescription>{visibleGrades.length} оценки</CardDescription>
          </CardHeader>
          <CardContent>
            {visibleGrades.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    {isTeacher && <TableHead>Ученик</TableHead>}
                    <TableHead>Предмет</TableHead>
                    <TableHead>Оценка</TableHead>
                    <TableHead>Тип</TableHead>
                    <TableHead>Описание</TableHead>
                    <TableHead>Дата</TableHead>
                    {isTeacher && <TableHead>Действия</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visibleGrades.map((grade) => {
                    const student = students.find((s) => s.id === grade.studentId)
                    return (
                      <TableRow key={grade.id}>
                        {isTeacher && <TableCell>{student?.name || "Неизвестен"}</TableCell>}
                        <TableCell>{grade.subject}</TableCell>
                        <TableCell>{getGradeDisplay(grade.score)}</TableCell>
                        <TableCell>{getGradeTypeBadge(grade.gradeType || "current")}</TableCell>
                        <TableCell>{grade.assignmentName || "-"}</TableCell>
                        <TableCell>{new Date(grade.date).toLocaleDateString("bg-BG")}</TableCell>
                        {isTeacher && (
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteGrade(grade.id)}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            ) : (
              <p className="text-center text-muted-foreground py-8">Няма намерени оценки</p>
            )}
          </CardContent>
        </Card>

        {/* Averages */}
        {selectedStudent !== "all" && Object.keys(averages).length > 0 && (
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Средни оценки
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Предмет</TableHead>
                    <TableHead>Текущи</TableHead>
                    <TableHead>1-ви срок</TableHead>
                    <TableHead>2-ри срок</TableHead>
                    <TableHead>Годишна</TableHead>
                    <TableHead>Обща средна</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {Object.entries(averages).map(([subject, data]) => (
                    <TableRow key={subject}>
                      <TableCell className="font-medium">{subject}</TableCell>
                      <TableCell>
                        {data.current.count > 0 ? (
                          <span className="text-blue-500 font-bold">{data.current.average.toFixed(2)}</span>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell>
                        {data.term1.count > 0 ? (
                          <span className="text-purple-500 font-bold">{data.term1.average.toFixed(2)}</span>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell>
                        {data.term2.count > 0 ? (
                          <span className="text-orange-500 font-bold">{data.term2.average.toFixed(2)}</span>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell>
                        {data.yearly.count > 0 ? (
                          <span className="text-green-500 font-bold">{data.yearly.average.toFixed(2)}</span>
                        ) : (
                          "-"
                        )}
                      </TableCell>
                      <TableCell>
                        <span className="font-bold text-foreground">{data.overall.average.toFixed(2)}</span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Add Grade Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Добави оценка</DialogTitle>
              <DialogDescription>Изберете ученици и въведете оценката</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                {/* Student Selection */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Ученици *</Label>
                    <Button type="button" variant="outline" size="sm" onClick={selectAllStudents}>
                      {selectedStudentIds.length === students.length ? "Изчисти всички" : "Избери всички"}
                    </Button>
                  </div>
                  <div className="border border-border rounded-md p-3 max-h-48 overflow-y-auto space-y-2">
                    {students.map((student) => (
                      <div
                        key={student.id}
                        className="flex items-center gap-2 p-2 hover:bg-muted/50 rounded cursor-pointer"
                        onClick={() => toggleStudentSelection(student.id)}
                      >
                        <Checkbox
                          checked={selectedStudentIds.includes(student.id)}
                          onCheckedChange={() => toggleStudentSelection(student.id)}
                        />
                        <span>
                          {student.name} ({student.class})
                        </span>
                      </div>
                    ))}
                  </div>
                  {selectedStudentIds.length > 0 && (
                    <p className="text-sm text-muted-foreground mt-1">Избрани: {selectedStudentIds.length} ученика</p>
                  )}
                </div>

                {/* Subject */}
                <div>
                  <Label>Предмет *</Label>
                  <Select value={formData.subject} onValueChange={(v) => setFormData({ ...formData, subject: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Изберете предмет" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableSubjects.map((subject) => (
                        <SelectItem key={subject.id} value={subject.name}>
                          {subject.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Grade Type */}
                {formData.subject && (
                  <div>
                    <Label>Тип оценка *</Label>
                    <Select
                      value={formData.gradeType}
                      onValueChange={(v) =>
                        setFormData({ ...formData, gradeType: v as "current" | "term1" | "term2" | "yearly" })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Изберете тип" />
                      </SelectTrigger>
                      <SelectContent>
                        {getSubjectGradeTypes(formData.subject).map((type) => (
                          <SelectItem key={type} value={type}>
                            {GRADE_TYPE_LABELS[type]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Grade Score */}
                <div>
                  <Label>Оценка *</Label>
                  <div className="flex gap-2 mt-2">
                    {[2, 3, 4, 5, 6].map((score) => (
                      <Button
                        key={score}
                        type="button"
                        variant={formData.score === score ? "default" : "outline"}
                        className={`flex-1 ${formData.score === score ? GRADE_CONFIG[score].bgColor : ""}`}
                        onClick={() => setFormData({ ...formData, score })}
                      >
                        <span className={formData.score === score ? "text-foreground" : GRADE_CONFIG[score].color}>
                          {score}
                        </span>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Assignment Name */}
                <div>
                  <Label>Описание (незадължително)</Label>
                  <Input
                    value={formData.assignmentName}
                    onChange={(e) => setFormData({ ...formData, assignmentName: e.target.value })}
                    placeholder="Напр. Контролно, Домашна работа..."
                  />
                </div>
              </div>
              <DialogFooter className="mt-6">
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit" disabled={selectedStudentIds.length === 0 || !formData.subject}>
                  Добави
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
