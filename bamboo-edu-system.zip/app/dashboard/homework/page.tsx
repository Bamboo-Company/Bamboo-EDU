"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import type { HomeworkAssignment, HomeworkSubmission } from "@/lib/types"
import { Plus, BookOpen, CheckCircle, AlertCircle, MinusCircle, Trash2 } from "lucide-react"

const SUBMISSION_STATUSES = [
  { value: "done", label: "Направено", icon: CheckCircle, color: "bg-green-500/20 text-green-400 border-green-500" },
  {
    value: "partially-done",
    label: "Частично",
    icon: MinusCircle,
    color: "bg-amber-500/20 text-amber-400 border-amber-500",
  },
  { value: "not-done", label: "Ненаправено", icon: AlertCircle, color: "bg-red-500/20 text-red-400 border-red-500" },
] as const

export default function HomeworkPage() {
  const { user } = useAuth()
  const [assignments, setAssignments] = useState<HomeworkAssignment[]>([])
  const [submissions, setSubmissions] = useState<HomeworkSubmission[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [gradeDialogOpen, setGradeDialogOpen] = useState(false)
  const [selectedAssignment, setSelectedAssignment] = useState<HomeworkAssignment | null>(null)

  const [formData, setFormData] = useState({
    subject: "",
    title: "",
    description: "",
    classId: "",
    dueDate: "",
  })

  const refreshData = useCallback(() => {
    setAssignments(dataStore.getHomeworkAssignments())
    setSubmissions(dataStore.getHomeworkSubmissions())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user) return null

  const isTeacher = ["admin", "principal", "vice-principal", "teacher"].includes(user.role)
  const isStudent = user.role === "student"
  const isParent = user.role === "parent"

  const students = dataStore.getStudents()
  const subjects = dataStore.getSubjects()
  const classes = dataStore.getClasses()

  const teacher = isTeacher ? dataStore.getTeacherByUserId(user.id) : null

  const visibleAssignments = assignments.filter((a) => {
    if (isTeacher) return true
    if (isStudent) {
      const student = students.find((s) => s.name === user.name || s.linkedUserId === user.id)
      return student && a.classId === student.class
    }
    if (isParent) {
      const childStudents = dataStore.getStudentsByParentId(user.id)
      return childStudents.some((s) => a.classId === s.class)
    }
    return false
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newAssignment: HomeworkAssignment = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      teacherId: teacher?.id || user.id,
      ...formData,
      createdAt: new Date().toISOString(),
    }

    dataStore.addHomeworkAssignment(newAssignment)

    const classStudents = students.filter((s) => s.class === formData.classId)

    classStudents.forEach((student) => {
      const newSubmission: HomeworkSubmission = {
        id: `${newAssignment.id}-${student.id}`,
        assignmentId: newAssignment.id,
        studentId: student.id,
        status: "not-done",
      }
      dataStore.addHomeworkSubmission(newSubmission)

      if (student.parentId) {
        dataStore.addNotification({
          id: `${Date.now()}-${student.parentId}-${Math.random().toString(36).substr(2, 9)}`,
          userId: student.parentId,
          title: "Ново домашно задание",
          message: `${formData.title} - Краен срок: ${formData.dueDate}`,
          type: "info",
          read: false,
          createdAt: new Date().toISOString(),
        })
      }
    })

    refreshData()
    setDialogOpen(false)
    setFormData({ subject: "", title: "", description: "", classId: "", dueDate: "" })
  }

  const handleGradeSubmission = (studentId: string, status: HomeworkSubmission["status"]) => {
    if (!selectedAssignment) return

    const submissionId = `${selectedAssignment.id}-${studentId}`
    dataStore.updateHomeworkSubmission(submissionId, {
      status,
      gradedBy: user.id,
      submittedAt: new Date().toISOString(),
    })

    refreshData()
  }

  const handleDeleteAssignment = (assignmentId: string) => {
    dataStore.deleteHomeworkAssignment(assignmentId)
    refreshData()
  }

  const getSubmissionStatus = (assignmentId: string, studentId: string) => {
    return submissions.find((s) => s.assignmentId === assignmentId && s.studentId === studentId)
  }

  const openGradeDialog = (assignment: HomeworkAssignment) => {
    setSelectedAssignment(assignment)
    setGradeDialogOpen(true)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Домашни</h1>
            <p className="text-muted-foreground">
              {isTeacher ? "Управлявайте домашните задания" : "Прегледайте вашите домашни задания"}
            </p>
          </div>
          {isTeacher && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Ново задание
            </Button>
          )}
        </div>

        <div className="grid gap-4">
          {visibleAssignments.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">Все още няма домашни задания</CardContent>
            </Card>
          ) : (
            visibleAssignments.map((assignment) => {
              const isDue = new Date(assignment.dueDate) < new Date()
              const classSubmissions = submissions.filter((s) => s.assignmentId === assignment.id)
              const doneCount = classSubmissions.filter((s) => s.status === "done").length

              return (
                <Card key={assignment.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <BookOpen className="w-5 h-5" />
                          {assignment.title}
                        </CardTitle>
                        <CardDescription>
                          {assignment.subject} | Клас: {assignment.classId} | Краен срок:{" "}
                          {new Date(assignment.dueDate).toLocaleDateString("bg-BG")}
                        </CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={isDue ? "destructive" : "default"}>{isDue ? "Просрочен" : "Активен"}</Badge>
                        {isTeacher && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteAssignment(assignment.id)}
                            className="text-red-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{assignment.description}</p>

                    {isTeacher && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">
                          Завършени: {doneCount}/{classSubmissions.length}
                        </span>
                        <Button size="sm" onClick={() => openGradeDialog(assignment)}>
                          Оцени предаванията
                        </Button>
                      </div>
                    )}

                    {(isStudent || isParent) && (
                      <div className="space-y-2">
                        {students
                          .filter((s) => {
                            if (isStudent) return s.name === user.name || s.linkedUserId === user.id
                            if (isParent) return dataStore.getStudentsByParentId(user.id).some((ps) => ps.id === s.id)
                            return false
                          })
                          .filter((s) => s.class === assignment.classId)
                          .map((student) => {
                            const submission = getSubmissionStatus(assignment.id, student.id)
                            const statusConfig = SUBMISSION_STATUSES.find((s) => s.value === submission?.status)
                            return (
                              <div key={student.id} className="flex items-center justify-between p-2 bg-muted rounded">
                                <span>{student.name}</span>
                                {statusConfig && (
                                  <Badge className={statusConfig.color}>
                                    <statusConfig.icon className="w-3 h-3 mr-1" />
                                    {statusConfig.label}
                                  </Badge>
                                )}
                              </div>
                            )
                          })}
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ново домашно задание</DialogTitle>
              <DialogDescription>Създайте ново домашно задание за клас</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label>Предмет</Label>
                <Select value={formData.subject} onValueChange={(v) => setFormData({ ...formData, subject: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете предмет" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.name}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Заглавие</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="напр. Упражнения от Глава 5"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Описание</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Инструкции за домашното..."
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Клас</Label>
                <Select value={formData.classId} onValueChange={(v) => setFormData({ ...formData, classId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете клас" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.name}>
                        {cls.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Краен срок</Label>
                <Input
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  required
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">Създай задание</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        <Dialog open={gradeDialogOpen} onOpenChange={setGradeDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Оценяване на предавания</DialogTitle>
              <DialogDescription>{selectedAssignment?.title}</DialogDescription>
            </DialogHeader>
            <div className="max-h-96 overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ученик</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedAssignment &&
                    students
                      .filter((s) => s.class === selectedAssignment.classId)
                      .map((student) => {
                        const submission = getSubmissionStatus(selectedAssignment.id, student.id)
                        return (
                          <TableRow key={student.id}>
                            <TableCell className="font-medium">{student.name}</TableCell>
                            <TableCell>
                              {submission && (
                                <Badge
                                  className={
                                    SUBMISSION_STATUSES.find((s) => s.value === submission.status)?.color || ""
                                  }
                                >
                                  {SUBMISSION_STATUSES.find((s) => s.value === submission.status)?.label}
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                {SUBMISSION_STATUSES.map((status) => (
                                  <Button
                                    key={status.value}
                                    size="sm"
                                    variant={submission?.status === status.value ? "default" : "outline"}
                                    onClick={() => handleGradeSubmission(student.id, status.value)}
                                  >
                                    <status.icon className="w-4 h-4" />
                                  </Button>
                                ))}
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                </TableBody>
              </Table>
            </div>
            <DialogFooter>
              <Button onClick={() => setGradeDialogOpen(false)}>Затвори</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
