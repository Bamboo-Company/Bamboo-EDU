"use client"

import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import type { Attendance } from "@/lib/types"
import { Check, X, Clock, AlertCircle, UserCheck } from "lucide-react"

const ATTENDANCE_STATUSES = [
  { value: "present", label: "Присъства", icon: Check, color: "bg-green-500/20 text-green-400 border-green-500" },
  { value: "absent", label: "Отсъства", icon: X, color: "bg-red-500/20 text-red-400 border-red-500" },
  { value: "late", label: "Закъснял", icon: Clock, color: "bg-amber-500/20 text-amber-400 border-amber-500" },
  { value: "excused", label: "Извинен", icon: AlertCircle, color: "bg-blue-500/20 text-blue-400 border-blue-500" },
] as const

export default function AttendancePage() {
  const { user } = useAuth()
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])
  const [selectedClass, setSelectedClass] = useState("all")
  const [selectedSubject, setSelectedSubject] = useState("")
  const [attendanceRecords, setAttendanceRecords] = useState<Attendance[]>([])
  const [selectedStudents, setSelectedStudents] = useState<string[]>([])
  const [bulkStatus, setBulkStatus] = useState<Attendance["status"] | "">("")

  const refreshData = useCallback(() => {
    setAttendanceRecords(dataStore.getAttendance())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user) return null

  const students = dataStore.getStudents()
  const subjects = dataStore.getSubjects()
  const classes = dataStore.getClasses()

  const filteredStudents = selectedClass === "all" ? students : students.filter((s) => s.class === selectedClass)

  const getAttendanceForStudent = (studentId: string) => {
    return attendanceRecords.find(
      (a) => a.studentId === studentId && a.date === selectedDate && a.subject === selectedSubject,
    )
  }

  const toggleStudent = (studentId: string) => {
    setSelectedStudents((prev) =>
      prev.includes(studentId) ? prev.filter((id) => id !== studentId) : [...prev, studentId],
    )
  }

  const selectAllStudents = () => {
    if (selectedStudents.length === filteredStudents.length) {
      setSelectedStudents([])
    } else {
      setSelectedStudents(filteredStudents.map((s) => s.id))
    }
  }

  const applyBulkAttendance = () => {
    if (!bulkStatus || selectedStudents.length === 0) return

    selectedStudents.forEach((studentId) => {
      const existing = attendanceRecords.find(
        (a) => a.studentId === studentId && a.date === selectedDate && a.subject === selectedSubject,
      )

      if (existing) {
        dataStore.updateAttendance(existing.id, { status: bulkStatus })
      } else {
        dataStore.addAttendance({
          id: `${Date.now()}-${studentId}-${Math.random().toString(36).substr(2, 9)}`,
          studentId,
          date: selectedDate,
          status: bulkStatus,
          recordedBy: user.id,
          subject: selectedSubject,
        })
      }
    })

    refreshData()
    setSelectedStudents([])
    setBulkStatus("")
  }

  const handleAttendanceChange = (studentId: string, status: Attendance["status"]) => {
    const existing = attendanceRecords.find(
      (a) => a.studentId === studentId && a.date === selectedDate && a.subject === selectedSubject,
    )

    if (existing) {
      dataStore.updateAttendance(existing.id, { status })
    } else {
      dataStore.addAttendance({
        id: `${Date.now()}-${studentId}-${Math.random().toString(36).substr(2, 9)}`,
        studentId,
        date: selectedDate,
        status,
        recordedBy: user.id,
        subject: selectedSubject,
      })
    }

    refreshData()
  }

  const getStatusBadge = (status?: Attendance["status"]) => {
    if (!status) {
      return <Badge variant="secondary">Неотбелязан</Badge>
    }
    const statusConfig = ATTENDANCE_STATUSES.find((s) => s.value === status)
    if (!statusConfig) return null
    return <Badge className={statusConfig.color}>{statusConfig.label}</Badge>
  }

  // Calculate stats for selected date
  const dayRecords = attendanceRecords.filter((a) => a.date === selectedDate && a.subject === selectedSubject)
  const stats = {
    present: dayRecords.filter((a) => a.status === "present").length,
    absent: dayRecords.filter((a) => a.status === "absent").length,
    late: dayRecords.filter((a) => a.status === "late").length,
    excused: dayRecords.filter((a) => a.status === "excused").length,
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Присъствие</h1>
          <p className="text-muted-foreground">Проследявайте и управлявайте присъствието на учениците</p>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          {ATTENDANCE_STATUSES.map((status) => (
            <Card key={status.value}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{status.label}</p>
                    <p className="text-2xl font-bold">{stats[status.value]}</p>
                  </div>
                  <status.icon className={`w-8 h-8 ${status.color.split(" ")[1]}`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <Label className="text-sm font-medium text-muted-foreground mb-1 block">Дата</Label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                />
              </div>
              <div className="flex-1">
                <Label className="text-sm font-medium text-muted-foreground mb-1 block">Клас</Label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете клас" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Всички класове</SelectItem>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.name}>
                        {cls.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <Label className="text-sm font-medium text-muted-foreground mb-1 block">Предмет</Label>
                <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете предмет" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject.id} value={subject.name}>
                        {subject.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {selectedStudents.length > 0 && (
          <Card className="border-primary">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row gap-4 items-center">
                <span className="text-sm font-medium">{selectedStudents.length} ученици избрани</span>
                <Select value={bulkStatus} onValueChange={(v) => setBulkStatus(v as Attendance["status"])}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Избери статус" />
                  </SelectTrigger>
                  <SelectContent>
                    {ATTENDANCE_STATUSES.map((status) => (
                      <SelectItem key={status.value} value={status.value}>
                        {status.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={applyBulkAttendance} disabled={!bulkStatus}>
                  Приложи към избраните
                </Button>
                <Button variant="outline" onClick={() => setSelectedStudents([])}>
                  Премахни избора
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Attendance Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserCheck className="w-5 h-5" />
              Присъствие за {new Date(selectedDate).toLocaleDateString("bg-BG")}
              {selectedSubject && ` - ${selectedSubject}`}
            </CardTitle>
            <CardDescription>Отбележете присъствието за всеки ученик</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={selectedStudents.length === filteredStudents.length && filteredStudents.length > 0}
                        onCheckedChange={selectAllStudents}
                      />
                    </TableHead>
                    <TableHead>Име на ученик</TableHead>
                    <TableHead>Клас</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => {
                    const record = getAttendanceForStudent(student.id)
                    return (
                      <TableRow
                        key={student.id}
                        className={selectedStudents.includes(student.id) ? "bg-primary/10" : ""}
                      >
                        <TableCell>
                          <Checkbox
                            checked={selectedStudents.includes(student.id)}
                            onCheckedChange={() => toggleStudent(student.id)}
                          />
                        </TableCell>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell>{student.class}</TableCell>
                        <TableCell>{getStatusBadge(record?.status)}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            {ATTENDANCE_STATUSES.map((status) => (
                              <Button
                                key={status.value}
                                size="sm"
                                variant={record?.status === status.value ? "default" : "outline"}
                                className={record?.status === status.value ? status.color : ""}
                                onClick={() => handleAttendanceChange(student.id, status.value)}
                              >
                                <status.icon className="w-4 h-4" />
                              </Button>
                            ))}
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
