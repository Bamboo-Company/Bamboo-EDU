"use client"

import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import type { ClassProgram, DailySchedule, SchoolClass, Subject, Teacher } from "@/lib/types"
import { Calendar, Clock, Save, Edit } from "lucide-react"

const DAYS_OF_WEEK = [
  { id: 1, name: "Понеделник" },
  { id: 2, name: "Вторник" },
  { id: 3, name: "Среда" },
  { id: 4, name: "Четвъртък" },
  { id: 5, name: "Петък" },
]

const PERIODS = [1, 2, 3, 4, 5, 6, 7, 8]

export default function SchedulePage() {
  const { user } = useAuth()
  const [classes, setClasses] = useState<SchoolClass[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [teachers, setTeachers] = useState<Teacher[]>([])
  const [programs, setPrograms] = useState<ClassProgram[]>([])
  const [selectedClassId, setSelectedClassId] = useState<string>("")
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [currentSchedule, setCurrentSchedule] = useState<DailySchedule[]>([])

  const refreshData = useCallback(() => {
    setClasses(dataStore.getClasses())
    setSubjects(dataStore.getSubjects())
    setTeachers(dataStore.getTeachers())
    setPrograms(dataStore.getClassPrograms())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user) return null

  const canEdit = ["admin", "principal", "vice-principal", "teacher"].includes(user.role)

  const selectedProgram = programs.find((p) => p.classId === selectedClassId)

  const initializeSchedule = () => {
    const schedule: DailySchedule[] = DAYS_OF_WEEK.map((day) => ({
      dayOfWeek: day.id,
      periods: PERIODS.map((period) => ({
        period,
        subjectId: "",
        teacherId: "",
      })),
    }))
    setCurrentSchedule(selectedProgram?.weeklySchedule || schedule)
  }

  const handleEditSchedule = () => {
    initializeSchedule()
    setEditDialogOpen(true)
  }

  const updatePeriod = (dayOfWeek: number, period: number, field: "subjectId" | "teacherId", value: string) => {
    setCurrentSchedule((prev) =>
      prev.map((day) =>
        day.dayOfWeek === dayOfWeek
          ? {
              ...day,
              periods: day.periods.map((p) => (p.period === period ? { ...p, [field]: value } : p)),
            }
          : day,
      ),
    )
  }

  const handleSaveSchedule = () => {
    if (!selectedClassId) return

    const existingProgram = programs.find((p) => p.classId === selectedClassId)

    if (existingProgram) {
      dataStore.updateClassProgram(existingProgram.id, { weeklySchedule: currentSchedule })
    } else {
      const newProgram: ClassProgram = {
        id: Date.now().toString(),
        classId: selectedClassId,
        weeklySchedule: currentSchedule,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
      dataStore.addClassProgram(newProgram)
    }

    refreshData()
    setEditDialogOpen(false)
  }

  const getSubjectName = (subjectId: string) => {
    const subject = subjects.find((s) => s.id === subjectId)
    return subject?.name || "-"
  }

  const getTeacherName = (teacherId: string) => {
    const teacher = teachers.find((t) => t.id === teacherId)
    return teacher?.name || ""
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Седмична програма</h1>
            <p className="text-muted-foreground">Преглед и редакция на учебната програма по класове</p>
          </div>
        </div>

        {/* Class selector */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Изберете клас
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <Select value={selectedClassId} onValueChange={setSelectedClassId}>
                <SelectTrigger className="w-64">
                  <SelectValue placeholder="Изберете клас" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {canEdit && selectedClassId && (
                <Button onClick={handleEditSchedule}>
                  <Edit className="w-4 h-4 mr-2" />
                  Редактирай програмата
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Schedule display */}
        {selectedClassId && (
          <Card>
            <CardHeader>
              <CardTitle>Програма за {classes.find((c) => c.id === selectedClassId)?.name}</CardTitle>
              <CardDescription>Седмично разписание на учебните часове</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-20">Час</TableHead>
                      {DAYS_OF_WEEK.map((day) => (
                        <TableHead key={day.id} className="text-center min-w-[150px]">
                          {day.name}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {PERIODS.map((period) => (
                      <TableRow key={period}>
                        <TableCell className="font-medium text-center">
                          <div className="flex items-center justify-center gap-2">
                            <Clock className="w-4 h-4 text-muted-foreground" />
                            {period}
                          </div>
                        </TableCell>
                        {DAYS_OF_WEEK.map((day) => {
                          const daySchedule = selectedProgram?.weeklySchedule?.find((d) => d.dayOfWeek === day.id)
                          const periodData = daySchedule?.periods.find((p) => p.period === period)
                          return (
                            <TableCell key={day.id} className="text-center">
                              {periodData?.subjectId ? (
                                <div className="p-2 bg-primary/10 rounded-lg">
                                  <p className="font-medium text-sm">{getSubjectName(periodData.subjectId)}</p>
                                  {periodData.teacherId && (
                                    <p className="text-xs text-muted-foreground">
                                      {getTeacherName(periodData.teacherId)}
                                    </p>
                                  )}
                                </div>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                          )
                        })}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Edit dialog */}
        <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
          <DialogContent className="max-w-[95vw] max-h-[95vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Редактиране на програма</DialogTitle>
              <DialogDescription>Задайте предмет и учител за всеки час от седмицата</DialogDescription>
            </DialogHeader>

            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-20">Час</TableHead>
                    {DAYS_OF_WEEK.map((day) => (
                      <TableHead key={day.id} className="text-center min-w-[200px]">
                        {day.name}
                      </TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {PERIODS.map((period) => (
                    <TableRow key={period}>
                      <TableCell className="font-medium text-center">{period}</TableCell>
                      {DAYS_OF_WEEK.map((day) => {
                        const daySchedule = currentSchedule.find((d) => d.dayOfWeek === day.id)
                        const periodData = daySchedule?.periods.find((p) => p.period === period)
                        return (
                          <TableCell key={day.id} className="p-2">
                            <div className="space-y-2">
                              <Select
                                value={periodData?.subjectId || "none"}
                                onValueChange={(v) => updatePeriod(day.id, period, "subjectId", v === "none" ? "" : v)}
                              >
                                <SelectTrigger className="w-full h-8 text-xs">
                                  <SelectValue placeholder="Предмет" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="none">-- Няма --</SelectItem>
                                  {subjects.map((subject) => (
                                    <SelectItem key={subject.id} value={subject.id}>
                                      {subject.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <Select
                                value={periodData?.teacherId || "none"}
                                onValueChange={(v) => updatePeriod(day.id, period, "teacherId", v === "none" ? "" : v)}
                              >
                                <SelectTrigger className="w-full h-8 text-xs">
                                  <SelectValue placeholder="Учител" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="none">-- Няма --</SelectItem>
                                  {teachers.map((teacher) => (
                                    <SelectItem key={teacher.id} value={teacher.id}>
                                      {teacher.name}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>
                          </TableCell>
                        )
                      })}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            <div className="flex justify-end gap-2 mt-4">
              <Button variant="outline" onClick={() => setEditDialogOpen(false)}>
                Отказ
              </Button>
              <Button onClick={handleSaveSchedule} className="bg-green-600 hover:bg-green-700">
                <Save className="w-4 h-4 mr-2" />
                Запази програмата
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
