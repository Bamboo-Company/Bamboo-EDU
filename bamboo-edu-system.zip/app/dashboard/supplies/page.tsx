"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { dataStore } from "@/lib/data-store"
import type { SupplyRequest } from "@/lib/types"
import { Plus, Check, X, Package } from "lucide-react"

const SUPPLY_TYPES = [
  { value: "books", label: "📚 Учебници" },
  { value: "workbooks", label: "📓 Тетрадки" },
  { value: "supplies", label: "✏️ Консумативи (моливи и др.)" },
  { value: "teacher-books", label: "📖 Учителски книги" },
] as const

export default function SuppliesPage() {
  const { user } = useAuth()
  const [requests, setRequests] = useState<SupplyRequest[]>(dataStore.getSupplyRequests())
  const [dialogOpen, setDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("all")

  const [formData, setFormData] = useState({
    type: "supplies" as SupplyRequest["type"],
    itemName: "",
    quantity: 1,
    reason: "",
  })

  if (!user) return null

  const isTeacher = user.role === "teacher"
  const canReview = ["admin", "principal", "vice-principal"].includes(user.role)

  const filteredRequests = requests.filter((r) => {
    if (isTeacher) {
      const teacher = dataStore.getTeacherByUserId(user.id)
      if (teacher && r.teacherId !== teacher.id) return false
    }
    if (activeTab === "pending") return r.status === "pending"
    if (activeTab === "approved") return r.status === "approved"
    if (activeTab === "denied") return r.status === "denied"
    return true
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const teacher = dataStore.getTeacherByUserId(user.id)

    const newRequest: SupplyRequest = {
      id: Date.now().toString(),
      teacherId: teacher?.id || user.id,
      ...formData,
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    dataStore.addSupplyRequest(newRequest)
    setRequests(dataStore.getSupplyRequests())
    setDialogOpen(false)
    setFormData({ type: "supplies", itemName: "", quantity: 1, reason: "" })
  }

  const handleReview = (requestId: string, status: "approved" | "denied") => {
    dataStore.updateSupplyRequest(requestId, {
      status,
      reviewedBy: user.id,
      reviewedAt: new Date().toISOString(),
    })

    // Add notification for teacher
    const request = requests.find((r) => r.id === requestId)
    if (request) {
      const teacher = dataStore.getTeachers().find((t) => t.id === request.teacherId)
      if (teacher) {
        dataStore.addNotification({
          id: Date.now().toString(),
          userId: teacher.userId,
          title: `📦 Заявка за консумативи ${status === "approved" ? "одобрена" : "отхвърлена"}`,
          message: `Вашата заявка за ${request.quantity}x ${request.itemName} беше ${status === "approved" ? "одобрена" : "отхвърлена"}.`,
          type: status === "approved" ? "success" : "error",
          read: false,
          createdAt: new Date().toISOString(),
        })
      }
    }

    setRequests(dataStore.getSupplyRequests())
  }

  const getStatusBadge = (status: SupplyRequest["status"]) => {
    const styles = {
      pending: "bg-amber-500/20 text-amber-400 border-amber-500",
      approved: "bg-green-500/20 text-green-400 border-green-500",
      denied: "bg-red-500/20 text-red-400 border-red-500",
    }
    const labels = {
      pending: "⏳ Чакаща",
      approved: "✅ Одобрена",
      denied: "❌ Отхвърлена",
    }
    return <Badge className={styles[status]}>{labels[status]}</Badge>
  }

  const requiresName = formData.type === "books" || formData.type === "workbooks" || formData.type === "teacher-books"

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">📦 Заявки за консумативи</h1>
            <p className="text-muted-foreground">
              {isTeacher
                ? "Заявете консумативи за вашите класове"
                : "Прегледайте и управлявайте заявките за консумативи"}
            </p>
          </div>
          {isTeacher && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Нова заявка
            </Button>
          )}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="all">Всички</TabsTrigger>
            <TabsTrigger value="pending">⏳ Чакащи</TabsTrigger>
            <TabsTrigger value="approved">✅ Одобрени</TabsTrigger>
            <TabsTrigger value="denied">❌ Отхвърлени</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Package className="w-5 h-5" />
                  Заявки ({filteredRequests.length})
                </CardTitle>
                <CardDescription>Заявки за консумативи от учители</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Тип</TableHead>
                        <TableHead>Наименование</TableHead>
                        <TableHead>Количество</TableHead>
                        <TableHead>Причина</TableHead>
                        <TableHead>Статус</TableHead>
                        <TableHead>Дата</TableHead>
                        {canReview && <TableHead className="text-right">Действия</TableHead>}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRequests.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={canReview ? 7 : 6} className="text-center text-muted-foreground py-8">
                            Няма намерени заявки
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredRequests.map((request) => (
                          <TableRow key={request.id}>
                            <TableCell className="capitalize">
                              {SUPPLY_TYPES.find((t) => t.value === request.type)?.label}
                            </TableCell>
                            <TableCell className="font-medium">{request.itemName}</TableCell>
                            <TableCell>{request.quantity}</TableCell>
                            <TableCell className="max-w-xs truncate">{request.reason}</TableCell>
                            <TableCell>{getStatusBadge(request.status)}</TableCell>
                            <TableCell>{new Date(request.createdAt).toLocaleDateString("bg-BG")}</TableCell>
                            {canReview && (
                              <TableCell className="text-right">
                                {request.status === "pending" && (
                                  <div className="flex justify-end gap-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="text-green-500 bg-transparent"
                                      onClick={() => handleReview(request.id, "approved")}
                                    >
                                      <Check className="w-4 h-4" />
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="text-destructive bg-transparent"
                                      onClick={() => handleReview(request.id, "denied")}
                                    >
                                      <X className="w-4 h-4" />
                                    </Button>
                                  </div>
                                )}
                              </TableCell>
                            )}
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* New Request Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Нова заявка за консумативи</DialogTitle>
              <DialogDescription>Заявете консумативи за вашата класна стая</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="type">Тип консуматив</Label>
                <Select
                  value={formData.type}
                  onValueChange={(v) => setFormData({ ...formData, type: v as SupplyRequest["type"] })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SUPPLY_TYPES.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="itemName">{requiresName ? "Заглавие на книгата" : "Наименование"}</Label>
                <Input
                  id="itemName"
                  value={formData.itemName}
                  onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                  placeholder={requiresName ? "напр. Eyes Open 2" : "напр. Моливи, Гуми"}
                  required
                />
                {requiresName && (
                  <p className="text-xs text-muted-foreground">Моля, посочете точното заглавие на книгата</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Количество</Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: Number.parseInt(e.target.value) || 1 })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">Причина</Label>
                <Textarea
                  id="reason"
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                  placeholder="Защо ви трябват тези консумативи?"
                  required
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">Изпрати заявка</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
