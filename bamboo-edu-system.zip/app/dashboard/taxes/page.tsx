"use client"

import type React from "react"
import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { dataStore } from "@/lib/data-store"
import type { Tax, TaxPayment, School } from "@/lib/types"
import {
  Plus,
  Receipt,
  Trash2,
  Pencil,
  CheckCircle,
  XCircle,
  Clock,
  Building2,
  AlertTriangle,
  Users,
} from "lucide-react"

export default function TaxesPage() {
  const { user } = useAuth()
  const [taxes, setTaxes] = useState<Tax[]>([])
  const [payments, setPayments] = useState<TaxPayment[]>([])
  const [schools, setSchools] = useState<School[]>([])
  const [selectedSchool, setSelectedSchool] = useState<string>("")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false)
  const [editingTax, setEditingTax] = useState<Tax | null>(null)
  const [selectedTax, setSelectedTax] = useState<Tax | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    description: "",
    amount: "",
    dueDate: "",
    targetClasses: [] as string[],
    isRecurring: false,
    recurringPeriod: "monthly" as "monthly" | "semester" | "yearly",
  })

  const refreshData = useCallback(() => {
    setTaxes(dataStore.getTaxes())
    setPayments(dataStore.getTaxPayments())
    setSchools(dataStore.getSchools())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user) return null

  // Check if user can manage taxes (admin or principal of a school)
  const isAdmin = user.role === "admin"
  const principalSchools = dataStore.getUserPrincipalSchools(user.id)
  const canManageTaxes = isAdmin || principalSchools.length > 0

  if (!canManageTaxes && user.role !== "parent" && user.role !== "student") {
    return (
      <DashboardLayout>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Достъпът е отказан</AlertTitle>
          <AlertDescription>Нямате права за достъп до тази страница.</AlertDescription>
        </Alert>
      </DashboardLayout>
    )
  }

  const classes = dataStore.getClasses()
  const students = dataStore.getStudents()

  // Filter taxes based on user role
  const filteredTaxes = isAdmin
    ? selectedSchool
      ? taxes.filter((t) => t.schoolId === selectedSchool)
      : taxes
    : taxes.filter((t) => principalSchools.includes(t.schoolId))

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name || !formData.amount) return

    const schoolId = isAdmin ? selectedSchool : principalSchools[0]
    if (!schoolId) return

    if (editingTax) {
      dataStore.updateTax(editingTax.id, {
        ...formData,
        amount: Number.parseFloat(formData.amount),
      })
    } else {
      const newTax: Tax = {
        id: Date.now().toString(),
        schoolId,
        name: formData.name,
        description: formData.description,
        amount: Number.parseFloat(formData.amount),
        currency: "лв.",
        dueDate: formData.dueDate,
        targetClasses: formData.targetClasses,
        isRecurring: formData.isRecurring,
        recurringPeriod: formData.isRecurring ? formData.recurringPeriod : undefined,
        createdBy: user.id,
        createdAt: new Date().toISOString(),
      }
      dataStore.addTax(newTax)
    }

    refreshData()
    setDialogOpen(false)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      amount: "",
      dueDate: "",
      targetClasses: [],
      isRecurring: false,
      recurringPeriod: "monthly",
    })
    setEditingTax(null)
  }

  const handleEdit = (tax: Tax) => {
    setEditingTax(tax)
    setFormData({
      name: tax.name,
      description: tax.description,
      amount: tax.amount.toString(),
      dueDate: tax.dueDate,
      targetClasses: tax.targetClasses,
      isRecurring: tax.isRecurring,
      recurringPeriod: tax.recurringPeriod || "monthly",
    })
    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    dataStore.deleteTax(id)
    refreshData()
  }

  const toggleClass = (classId: string) => {
    setFormData((prev) => ({
      ...prev,
      targetClasses: prev.targetClasses.includes(classId)
        ? prev.targetClasses.filter((c) => c !== classId)
        : [...prev.targetClasses, classId],
    }))
  }

  const handleRecordPayment = (tax: Tax, studentId: string, status: "paid" | "partial" | "unpaid" | "exempt") => {
    const existingPayment = payments.find((p) => p.taxId === tax.id && p.studentId === studentId)

    if (existingPayment) {
      dataStore.updateTaxPayment(existingPayment.id, {
        status,
        paidAmount: status === "paid" ? tax.amount : status === "partial" ? tax.amount / 2 : 0,
        paidDate: new Date().toISOString(),
        recordedBy: user.id,
      })
    } else {
      const newPayment: TaxPayment = {
        id: Date.now().toString(),
        taxId: tax.id,
        studentId,
        paidAmount: status === "paid" ? tax.amount : status === "partial" ? tax.amount / 2 : 0,
        paidDate: new Date().toISOString(),
        status,
        recordedBy: user.id,
      }
      dataStore.addTaxPayment(newPayment)
    }
    refreshData()
  }

  const getPaymentStatus = (taxId: string, studentId: string): TaxPayment | undefined => {
    return payments.find((p) => p.taxId === taxId && p.studentId === studentId)
  }

  const getStudentsForTax = (tax: Tax) => {
    if (tax.targetClasses.length === 0) return students
    return students.filter((s) => tax.targetClasses.includes(s.class))
  }

  const getTaxStats = (tax: Tax) => {
    const taxStudents = getStudentsForTax(tax)
    const taxPayments = payments.filter((p) => p.taxId === tax.id)
    const paid = taxPayments.filter((p) => p.status === "paid").length
    const partial = taxPayments.filter((p) => p.status === "partial").length
    const exempt = taxPayments.filter((p) => p.status === "exempt").length
    const unpaid = taxStudents.length - paid - partial - exempt
    const totalCollected = taxPayments.reduce((sum, p) => sum + p.paidAmount, 0)
    const totalExpected = taxStudents.length * tax.amount

    return { paid, partial, exempt, unpaid, totalCollected, totalExpected, total: taxStudents.length }
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Такси и задължения</h1>
            <p className="text-muted-foreground">Управление на училищни такси и плащания</p>
          </div>
          <div className="flex items-center gap-4">
            {isAdmin && schools.length > 0 && (
              <Select value={selectedSchool} onValueChange={setSelectedSchool}>
                <SelectTrigger className="w-[250px]">
                  <SelectValue placeholder="Всички училища" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Всички училища</SelectItem>
                  {schools.map((school) => (
                    <SelectItem key={school.id} value={school.id}>
                      {school.shortName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            {canManageTaxes && (
              <Button onClick={() => setDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Добави такса
              </Button>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Общо такси</p>
                  <p className="text-2xl font-bold">{filteredTaxes.length}</p>
                </div>
                <Receipt className="w-8 h-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-green-500/30 bg-green-500/5">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Събрани</p>
                  <p className="text-2xl font-bold text-green-500">
                    {payments
                      .filter((p) => p.status === "paid")
                      .reduce((sum, p) => sum + p.paidAmount, 0)
                      .toFixed(2)}{" "}
                    лв.
                  </p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-yellow-500/30 bg-yellow-500/5">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Частично платени</p>
                  <p className="text-2xl font-bold text-yellow-500">
                    {payments.filter((p) => p.status === "partial").length}
                  </p>
                </div>
                <Clock className="w-8 h-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-red-500/30 bg-red-500/5">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Неплатени</p>
                  <p className="text-2xl font-bold text-red-500">
                    {filteredTaxes.reduce((sum, tax) => sum + getTaxStats(tax).unpaid, 0)}
                  </p>
                </div>
                <XCircle className="w-8 h-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Taxes List */}
        <div className="space-y-4">
          {filteredTaxes.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">Няма добавени такси</CardContent>
            </Card>
          ) : (
            filteredTaxes.map((tax) => {
              const stats = getTaxStats(tax)
              const school = schools.find((s) => s.id === tax.schoolId)
              return (
                <Card key={tax.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Receipt className="w-5 h-5" />
                          {tax.name}
                        </CardTitle>
                        <CardDescription>{tax.description}</CardDescription>
                        {school && (
                          <Badge variant="outline" className="mt-2">
                            <Building2 className="w-3 h-3 mr-1" />
                            {school.shortName}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="text-lg px-4 py-2">
                          {tax.amount.toFixed(2)} {tax.currency}
                        </Badge>
                        {canManageTaxes && (
                          <>
                            <Button variant="outline" size="icon" onClick={() => handleEdit(tax)}>
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="icon" onClick={() => handleDelete(tax.id)}>
                              <Trash2 className="w-4 h-4 text-destructive" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-5 gap-4 mb-4">
                      <div className="text-center p-3 rounded-lg bg-muted">
                        <p className="text-2xl font-bold">{stats.total}</p>
                        <p className="text-xs text-muted-foreground">Общо</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-green-500/10">
                        <p className="text-2xl font-bold text-green-500">{stats.paid}</p>
                        <p className="text-xs text-muted-foreground">Платени</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-yellow-500/10">
                        <p className="text-2xl font-bold text-yellow-500">{stats.partial}</p>
                        <p className="text-xs text-muted-foreground">Частични</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-red-500/10">
                        <p className="text-2xl font-bold text-red-500">{stats.unpaid}</p>
                        <p className="text-xs text-muted-foreground">Неплатени</p>
                      </div>
                      <div className="text-center p-3 rounded-lg bg-blue-500/10">
                        <p className="text-2xl font-bold text-blue-500">{stats.exempt}</p>
                        <p className="text-xs text-muted-foreground">Освободени</p>
                      </div>
                    </div>

                    {/* Payment progress */}
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Събрани: {stats.totalCollected.toFixed(2)} лв.</span>
                        <span>Очаквани: {stats.totalExpected.toFixed(2)} лв.</span>
                      </div>
                      <div className="h-3 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-500 transition-all"
                          style={{ width: `${(stats.totalCollected / stats.totalExpected) * 100}%` }}
                        />
                      </div>
                    </div>

                    {/* Student payments table */}
                    <details className="group">
                      <summary className="cursor-pointer list-none">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
                          <Users className="w-4 h-4" />
                          Покажи плащания по ученици
                          <span className="group-open:rotate-180 transition-transform">▼</span>
                        </div>
                      </summary>
                      <div className="mt-4">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Ученик</TableHead>
                              <TableHead>Клас</TableHead>
                              <TableHead>Статус</TableHead>
                              <TableHead>Платено</TableHead>
                              {canManageTaxes && <TableHead>Действия</TableHead>}
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {getStudentsForTax(tax).map((student) => {
                              const payment = getPaymentStatus(tax.id, student.id)
                              return (
                                <TableRow key={student.id}>
                                  <TableCell className="font-medium">{student.name}</TableCell>
                                  <TableCell>{student.class}</TableCell>
                                  <TableCell>
                                    <Badge
                                      variant={
                                        payment?.status === "paid"
                                          ? "default"
                                          : payment?.status === "partial"
                                            ? "secondary"
                                            : payment?.status === "exempt"
                                              ? "outline"
                                              : "destructive"
                                      }
                                      className={payment?.status === "paid" ? "bg-green-500" : ""}
                                    >
                                      {payment?.status === "paid"
                                        ? "Платено"
                                        : payment?.status === "partial"
                                          ? "Частично"
                                          : payment?.status === "exempt"
                                            ? "Освободен"
                                            : "Неплатено"}
                                    </Badge>
                                  </TableCell>
                                  <TableCell>{payment ? `${payment.paidAmount.toFixed(2)} лв.` : "0.00 лв."}</TableCell>
                                  {canManageTaxes && (
                                    <TableCell>
                                      <div className="flex gap-1">
                                        <Button
                                          size="sm"
                                          variant={payment?.status === "paid" ? "default" : "outline"}
                                          className={payment?.status === "paid" ? "bg-green-500" : ""}
                                          onClick={() => handleRecordPayment(tax, student.id, "paid")}
                                        >
                                          Платено
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant={payment?.status === "partial" ? "default" : "outline"}
                                          onClick={() => handleRecordPayment(tax, student.id, "partial")}
                                        >
                                          Частично
                                        </Button>
                                        <Button
                                          size="sm"
                                          variant={payment?.status === "exempt" ? "default" : "outline"}
                                          onClick={() => handleRecordPayment(tax, student.id, "exempt")}
                                        >
                                          Освободен
                                        </Button>
                                      </div>
                                    </TableCell>
                                  )}
                                </TableRow>
                              )
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    </details>
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>

        {/* Add/Edit Tax Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingTax ? "Редактирай такса" : "Добави нова такса"}</DialogTitle>
              <DialogDescription>Въведете информация за таксата</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Име на таксата *</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
                    placeholder="напр. Такса за извънкласни дейности"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>Сума (лв.) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.amount}
                    onChange={(e) => setFormData((prev) => ({ ...prev, amount: e.target.value }))}
                    placeholder="0.00"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Описание</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
                  placeholder="Допълнителна информация за таксата..."
                />
              </div>

              <div className="space-y-2">
                <Label>Краен срок</Label>
                <Input
                  type="date"
                  value={formData.dueDate}
                  onChange={(e) => setFormData((prev) => ({ ...prev, dueDate: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label>За класове</Label>
                <div className="flex flex-wrap gap-2 p-3 border rounded-lg bg-muted/30">
                  {classes.length === 0 ? (
                    <p className="text-sm text-muted-foreground">Няма добавени класове</p>
                  ) : (
                    classes.map((cls) => (
                      <Button
                        key={cls.id}
                        type="button"
                        variant={formData.targetClasses.includes(cls.id) ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleClass(cls.id)}
                      >
                        {cls.grade} {cls.name}
                      </Button>
                    ))
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Ако не изберете класове, таксата ще важи за всички ученици
                </p>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="recurring"
                    checked={formData.isRecurring}
                    onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, isRecurring: checked as boolean }))}
                  />
                  <Label htmlFor="recurring">Периодична такса</Label>
                </div>
                {formData.isRecurring && (
                  <Select
                    value={formData.recurringPeriod}
                    onValueChange={(v) => setFormData((prev) => ({ ...prev, recurringPeriod: v as any }))}
                  >
                    <SelectTrigger className="w-[150px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="monthly">Месечна</SelectItem>
                      <SelectItem value="semester">Срочна</SelectItem>
                      <SelectItem value="yearly">Годишна</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              </div>

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setDialogOpen(false)
                    resetForm()
                  }}
                >
                  Отказ
                </Button>
                <Button type="submit">{editingTax ? "Запази" : "Добави"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
