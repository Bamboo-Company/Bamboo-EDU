"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { dataStore } from "@/lib/data-store"
import type { Notification } from "@/lib/types"
import { Bell, BellOff, Check, CheckCheck, Info, AlertTriangle, CheckCircle, XCircle } from "lucide-react"

export default function NotificationsPage() {
  const { user } = useAuth()
  const [notifications, setNotifications] = useState<Notification[]>(
    user ? dataStore.getNotificationsByUser(user.id) : [],
  )

  if (!user) return null

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    dataStore.markNotificationRead(id)
    setNotifications(dataStore.getNotificationsByUser(user.id))
  }

  const markAllAsRead = () => {
    dataStore.markAllNotificationsRead(user.id)
    setNotifications(dataStore.getNotificationsByUser(user.id))
  }

  const getIcon = (type: Notification["type"]) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case "warning":
        return <AlertTriangle className="w-5 h-5 text-amber-500" />
      case "error":
        return <XCircle className="w-5 h-5 text-red-500" />
      default:
        return <Info className="w-5 h-5 text-blue-500" />
    }
  }

  const getBadgeColor = (type: Notification["type"]) => {
    switch (type) {
      case "success":
        return "bg-green-500/20 text-green-400 border-green-500"
      case "warning":
        return "bg-amber-500/20 text-amber-400 border-amber-500"
      case "error":
        return "bg-red-500/20 text-red-400 border-red-500"
      default:
        return "bg-blue-500/20 text-blue-400 border-blue-500"
    }
  }

  const getTypeLabel = (type: Notification["type"]) => {
    switch (type) {
      case "success":
        return "✅ Успех"
      case "warning":
        return "⚠️ Внимание"
      case "error":
        return "❌ Грешка"
      default:
        return "ℹ️ Инфо"
    }
  }

  // Sort by date, newest first
  const sortedNotifications = [...notifications].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">🔔 Известия</h1>
            <p className="text-muted-foreground">
              {unreadCount > 0 ? `Имате ${unreadCount} непрочетени известия` : "Всичко е прочетено!"}
            </p>
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              <CheckCheck className="w-4 h-4 mr-2" />
              Маркирай всички като прочетени
            </Button>
          )}
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Непрочетени</p>
                  <p className="text-2xl font-bold">{unreadCount}</p>
                </div>
                <Bell className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Общо</p>
                  <p className="text-2xl font-bold">{notifications.length}</p>
                </div>
                <BellOff className="w-8 h-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notifications List */}
        <Card>
          <CardHeader>
            <CardTitle>Всички известия</CardTitle>
            <CardDescription>Вашите скорошни известия</CardDescription>
          </CardHeader>
          <CardContent>
            {sortedNotifications.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bell className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Все още няма известия</p>
              </div>
            ) : (
              <div className="space-y-3">
                {sortedNotifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 rounded-lg border transition-colors ${
                      !notification.read ? "bg-primary/5 border-primary/20" : "bg-card"
                    }`}
                  >
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0 mt-0.5">{getIcon(notification.type)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <span className={`font-medium ${!notification.read ? "text-primary" : ""}`}>
                            {notification.title}
                          </span>
                          <Badge className={getBadgeColor(notification.type)}>{getTypeLabel(notification.type)}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{notification.message}</p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-muted-foreground">
                            {new Date(notification.createdAt).toLocaleString("bg-BG")}
                          </span>
                          {!notification.read && (
                            <Button variant="ghost" size="sm" onClick={() => markAsRead(notification.id)}>
                              <Check className="w-4 h-4 mr-1" />
                              Маркирай като прочетено
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}
