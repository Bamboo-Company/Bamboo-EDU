"use client"

import type React from "react"
import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { dataStore } from "@/lib/data-store"
import type { School, SchoolUserRole, UserRole } from "@/lib/types"
import { Building2, Plus, Pencil, Trash2, AlertTriangle, UserPlus } from "lucide-react"

const SCHOOL_TYPES = [
  "Средно училище",
  "Основно училище",
  "Начално училище",
  "Професионална гимназия",
  "Езикова гимназия",
  "Математическа гимназия",
  "Спортно училище",
  "Частно училище",
]

const OWNERSHIP_TYPES = ["Държавно", "Общинско", "Частно"]
const FUNDING_SOURCES = ["Община", "Министерство на образованието", "Частен бюджет", "Смесено финансиране"]

const ROLE_LABELS: Record<UserRole, string> = {
  admin: "Администратор",
  principal: "Директор",
  "vice-principal": "Зам. директор",
  teacher: "Учител",
  psychologist: "Психолог",
  nurse: "Медицинска сестра",
  student: "Ученик",
  parent: "Родител",
}

export default function SchoolsPage() {
  const { user } = useAuth()
  const [schools, setSchools] = useState<School[]>([])
  const [schoolRoles, setSchoolRoles] = useState<SchoolUserRole[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [roleDialogOpen, setRoleDialogOpen] = useState(false)
  const [editingSchool, setEditingSchool] = useState<School | null>(null)
  const [selectedSchool, setSelectedSchool] = useState<School | null>(null)
  const [actionResult, setActionResult] = useState<{ type: "success" | "error"; message: string } | null>(null)

  const [formData, setFormData] = useState<Partial<School>>({
    fullName: "",
    shortName: "",
    type: "",
    ownership: "",
    isRegionalCenter: false,
    isProtected: false,
    isInnovative: false,
    isStateFunded: false,
    isNationalImportance: false,
    providesVocationalTraining: false,
    fundedBy: "",
    hasDelegatedBudget: false,
    approvedBudget: "",
    createdByInternationalTreaty: false,
    city: "",
    district: "",
    address: "",
    postalCode: "",
    phone1: "",
    phone2: "",
    website: "",
    email1: "",
    email2: "",
    isFullEDnevnik: false,
  })

  const [roleData, setRoleData] = useState({ userId: "", role: "" as UserRole })

  const refreshData = useCallback(() => {
    setSchools(dataStore.getSchools())
    setSchoolRoles(dataStore.getSchoolUserRoles())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user || user.role !== "admin") {
    return (
      <DashboardLayout>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Достъпът е отказан</AlertTitle>
          <AlertDescription>Само администратори могат да управляват училищата.</AlertDescription>
        </Alert>
      </DashboardLayout>
    )
  }

  const users = dataStore.getAllUsers().filter((u) => u.role !== "admin")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.fullName || !formData.shortName) return

    if (editingSchool) {
      dataStore.updateSchool(editingSchool.id, formData)
      setActionResult({ type: "success", message: "Училището е актуализирано успешно!" })
    } else {
      const newSchool: School = {
        id: Date.now().toString(),
        ...formData,
        createdAt: new Date().toISOString(),
      } as School
      dataStore.addSchool(newSchool)
      setActionResult({ type: "success", message: "Училището е добавено успешно!" })
    }

    refreshData()
    setDialogOpen(false)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      fullName: "",
      shortName: "",
      type: "",
      ownership: "",
      isRegionalCenter: false,
      isProtected: false,
      isInnovative: false,
      isStateFunded: false,
      isNationalImportance: false,
      providesVocationalTraining: false,
      fundedBy: "",
      hasDelegatedBudget: false,
      approvedBudget: "",
      createdByInternationalTreaty: false,
      city: "",
      district: "",
      address: "",
      postalCode: "",
      phone1: "",
      phone2: "",
      website: "",
      email1: "",
      email2: "",
      isFullEDnevnik: false,
    })
    setEditingSchool(null)
  }

  const handleEdit = (school: School) => {
    setEditingSchool(school)
    setFormData(school)
    setDialogOpen(true)
  }

  const handleDelete = (id: string) => {
    dataStore.deleteSchool(id)
    refreshData()
    setActionResult({ type: "success", message: "Училището е изтрито успешно!" })
  }

  const handleAddRole = (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedSchool || !roleData.userId || !roleData.role) return

    const existingRole = schoolRoles.find((r) => r.userId === roleData.userId && r.schoolId === selectedSchool.id)
    if (existingRole) {
      setActionResult({ type: "error", message: "Потребителят вече има роля в това училище!" })
      return
    }

    const newRole: SchoolUserRole = {
      id: Date.now().toString(),
      userId: roleData.userId,
      schoolId: selectedSchool.id,
      role: roleData.role,
    }
    dataStore.addSchoolUserRole(newRole)
    refreshData()
    setRoleDialogOpen(false)
    setRoleData({ userId: "", role: "" as UserRole })
    setActionResult({ type: "success", message: "Ролята е добавена успешно!" })
  }

  const handleDeleteRole = (roleId: string) => {
    dataStore.deleteSchoolUserRole(roleId)
    refreshData()
  }

  const getSchoolRoles = (schoolId: string) => {
    return schoolRoles.filter((r) => r.schoolId === schoolId)
  }

  const getUserName = (userId: string) => {
    const u = dataStore.getUserById(userId)
    return u?.name || "Неизвестен"
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Управление на училища</h1>
            <p className="text-muted-foreground">Добавяне и управление на училища в системата</p>
          </div>
          <Button
            onClick={() => {
              resetForm()
              setDialogOpen(true)
            }}
          >
            <Plus className="w-4 h-4 mr-2" />
            Добави училище
          </Button>
        </div>

        {actionResult && (
          <Alert variant={actionResult.type === "success" ? "default" : "destructive"}>
            <AlertTitle>{actionResult.type === "success" ? "Успех" : "Грешка"}</AlertTitle>
            <AlertDescription>{actionResult.message}</AlertDescription>
          </Alert>
        )}

        {/* Schools list */}
        <div className="grid gap-4">
          {schools.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">
                <Building2 className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Няма добавени училища</p>
              </CardContent>
            </Card>
          ) : (
            schools.map((school) => {
              const roles = getSchoolRoles(school.id)
              return (
                <Card key={school.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Building2 className="w-5 h-5" />
                          {school.shortName}
                        </CardTitle>
                        <CardDescription>{school.fullName}</CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedSchool(school)
                            setRoleDialogOpen(true)
                          }}
                        >
                          <UserPlus className="w-4 h-4 mr-1" />
                          Добави роля
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleEdit(school)}>
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-red-500 bg-transparent"
                          onClick={() => handleDelete(school.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 text-sm">
                      <div>
                        <span className="text-muted-foreground">Вид:</span> {school.type}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Тип:</span> {school.ownership}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Населено място:</span> {school.city}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Адрес:</span> {school.address}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Телефон:</span> {school.phone1}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Ел. поща:</span> {school.email1}
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-4">
                      {school.isInnovative && <Badge variant="secondary">Иновативно</Badge>}
                      {school.isFullEDnevnik && <Badge variant="secondary">100% e-Дневник</Badge>}
                      {school.hasDelegatedBudget && <Badge variant="secondary">Делегиран бюджет</Badge>}
                      {school.isStateFunded && <Badge variant="secondary">Държавно финансиране</Badge>}
                    </div>

                    {/* School roles */}
                    {roles.length > 0 && (
                      <div className="mt-4 pt-4 border-t">
                        <p className="text-sm font-medium mb-2">Назначен персонал:</p>
                        <div className="flex flex-wrap gap-2">
                          {roles.map((role) => (
                            <Badge key={role.id} variant="outline" className="flex items-center gap-1">
                              {getUserName(role.userId)} - {ROLE_LABELS[role.role]}
                              <button
                                onClick={() => handleDeleteRole(role.id)}
                                className="ml-1 text-red-500 hover:text-red-700"
                              >
                                ×
                              </button>
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })
          )}
        </div>

        {/* Add/Edit School Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingSchool ? "Редактиране на училище" : "Добавяне на училище"}</DialogTitle>
              <DialogDescription>Попълнете информацията за училището</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid grid-cols-3">
                  <TabsTrigger value="basic">Основни данни</TabsTrigger>
                  <TabsTrigger value="details">Детайли</TabsTrigger>
                  <TabsTrigger value="contact">Контакти</TabsTrigger>
                </TabsList>

                <TabsContent value="basic" className="space-y-4 mt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Пълно (официално) име *</Label>
                      <Input
                        value={formData.fullName}
                        onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                        placeholder='1 Средно училище "Пенчо П. Славейков"'
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Кратко име *</Label>
                      <Input
                        value={formData.shortName}
                        onChange={(e) => setFormData({ ...formData, shortName: e.target.value })}
                        placeholder='1 СУ "Пенчо П. Славейков"'
                        required
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Вид</Label>
                      <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Изберете вид" />
                        </SelectTrigger>
                        <SelectContent>
                          {SCHOOL_TYPES.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Тип</Label>
                      <Select
                        value={formData.ownership}
                        onValueChange={(v) => setFormData({ ...formData, ownership: v })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Изберете тип" />
                        </SelectTrigger>
                        <SelectContent>
                          {OWNERSHIP_TYPES.map((type) => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="details" className="space-y-4 mt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isRegionalCenter"
                        checked={formData.isRegionalCenter}
                        onCheckedChange={(c) => setFormData({ ...formData, isRegionalCenter: !!c })}
                      />
                      <Label htmlFor="isRegionalCenter">Средищно училище</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isProtected"
                        checked={formData.isProtected}
                        onCheckedChange={(c) => setFormData({ ...formData, isProtected: !!c })}
                      />
                      <Label htmlFor="isProtected">Защитено училище</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isInnovative"
                        checked={formData.isInnovative}
                        onCheckedChange={(c) => setFormData({ ...formData, isInnovative: !!c })}
                      />
                      <Label htmlFor="isInnovative">Иновативно училище</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isStateFunded"
                        checked={formData.isStateFunded}
                        onCheckedChange={(c) => setFormData({ ...formData, isStateFunded: !!c })}
                      />
                      <Label htmlFor="isStateFunded">На държавно финансиране</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isNationalImportance"
                        checked={formData.isNationalImportance}
                        onCheckedChange={(c) => setFormData({ ...formData, isNationalImportance: !!c })}
                      />
                      <Label htmlFor="isNationalImportance">От национално значение</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="providesVocationalTraining"
                        checked={formData.providesVocationalTraining}
                        onCheckedChange={(c) => setFormData({ ...formData, providesVocationalTraining: !!c })}
                      />
                      <Label htmlFor="providesVocationalTraining">Осигурява професионална подготовка</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="hasDelegatedBudget"
                        checked={formData.hasDelegatedBudget}
                        onCheckedChange={(c) => setFormData({ ...formData, hasDelegatedBudget: !!c })}
                      />
                      <Label htmlFor="hasDelegatedBudget">На делегиран бюджет</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="createdByInternationalTreaty"
                        checked={formData.createdByInternationalTreaty}
                        onCheckedChange={(c) => setFormData({ ...formData, createdByInternationalTreaty: !!c })}
                      />
                      <Label htmlFor="createdByInternationalTreaty">Създадено по международен договор</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="isFullEDnevnik"
                        checked={formData.isFullEDnevnik}
                        onCheckedChange={(c) => setFormData({ ...formData, isFullEDnevnik: !!c })}
                      />
                      <Label htmlFor="isFullEDnevnik">100% e-Дневник</Label>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Финансира се от</Label>
                      <Select
                        value={formData.fundedBy}
                        onValueChange={(v) => setFormData({ ...formData, fundedBy: v })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Изберете" />
                        </SelectTrigger>
                        <SelectContent>
                          {FUNDING_SOURCES.map((source) => (
                            <SelectItem key={source} value={source}>
                              {source}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Утвърден бюджет (лв.)</Label>
                      <Input
                        value={formData.approvedBudget}
                        onChange={(e) => setFormData({ ...formData, approvedBudget: e.target.value })}
                        placeholder="3675731"
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="contact" className="space-y-4 mt-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Населено място</Label>
                      <Input
                        value={formData.city}
                        onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                        placeholder="София"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Район</Label>
                      <Input
                        value={formData.district}
                        onChange={(e) => setFormData({ ...formData, district: e.target.value })}
                        placeholder="Оборище"
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Адрес</Label>
                      <Input
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        placeholder='ул."Стара планина" 11'
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Пощенски код</Label>
                      <Input
                        value={formData.postalCode}
                        onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                        placeholder="1000"
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Телефон</Label>
                      <Input
                        value={formData.phone1}
                        onChange={(e) => setFormData({ ...formData, phone1: e.target.value })}
                        placeholder="+359884801457"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Телефон №2</Label>
                      <Input
                        value={formData.phone2}
                        onChange={(e) => setFormData({ ...formData, phone2: e.target.value })}
                        placeholder="0885344338"
                      />
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label>Уеб сайт</Label>
                      <Input
                        value={formData.website}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        placeholder="1sousofia.org"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Ел. поща</Label>
                      <Input
                        value={formData.email1}
                        onChange={(e) => setFormData({ ...formData, email1: e.target.value })}
                        placeholder="info-2216001@edu.mon.bg"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Ел. поща №2</Label>
                    <Input
                      value={formData.email2}
                      onChange={(e) => setFormData({ ...formData, email2: e.target.value })}
                      placeholder="Допълнителен имейл"
                    />
                  </div>
                </TabsContent>
              </Tabs>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">{editingSchool ? "Запази" : "Добави"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Add Role Dialog */}
        <Dialog open={roleDialogOpen} onOpenChange={setRoleDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Добавяне на роля</DialogTitle>
              <DialogDescription>Назначете потребител с роля в {selectedSchool?.shortName}</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddRole} className="space-y-4">
              <div className="space-y-2">
                <Label>Потребител</Label>
                <Select value={roleData.userId} onValueChange={(v) => setRoleData({ ...roleData, userId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете потребител" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.map((u) => (
                      <SelectItem key={u.id} value={u.id}>
                        {u.name} ({u.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Роля в това училище</Label>
                <Select value={roleData.role} onValueChange={(v) => setRoleData({ ...roleData, role: v as UserRole })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете роля" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="principal">Директор</SelectItem>
                    <SelectItem value="vice-principal">Зам. директор</SelectItem>
                    <SelectItem value="teacher">Учител</SelectItem>
                    <SelectItem value="psychologist">Психолог</SelectItem>
                    <SelectItem value="nurse">Медицинска сестра</SelectItem>
                    <SelectItem value="student">Ученик</SelectItem>
                    <SelectItem value="parent">Родител</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setRoleDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">Добави</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
