"use client"

import { useState } from "react"
import { useParams, useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import {
  ArrowLeft,
  User,
  GraduationCap,
  MapPin,
  Calendar,
  ThumbsUp,
  ThumbsDown,
  Heart,
  Brain,
  UserCheck,
  FileText,
} from "lucide-react"

export default function StudentDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("overview")

  const studentId = params.id as string
  const student = dataStore.getStudentById(studentId)

  if (!user) return null

  if (!student) {
    return (
      <DashboardLayout>
        <div className="text-center py-8">
          <h1 className="text-xl font-bold text-foreground">Student Not Found</h1>
          <Button variant="link" onClick={() => router.back()}>
            Go Back
          </Button>
        </div>
      </DashboardLayout>
    )
  }

  const attendance = dataStore.getAttendanceByStudent(studentId)
  const behavioralReviews = dataStore.getBehavioralReviewsByStudent(studentId)
  const grades = dataStore.getGradesByStudent(studentId)
  const teacherLogs = dataStore.getTeacherLogsByStudent(studentId)
  const studentLogs = dataStore.getStudentLogsByStudent(studentId)

  // Check permissions for health logs
  const canViewHealthLogs = ["admin", "principal", "psychologist", "nurse"].includes(user.role)

  // Calculate stats
  const attendanceStats = {
    present: attendance.filter((a) => a.status === "present").length,
    absent: attendance.filter((a) => a.status === "absent").length,
    late: attendance.filter((a) => a.status === "late").length,
  }

  const behaviorStats = {
    positive: behavioralReviews.filter((b) => b.type === "positive").length,
    negative: behavioralReviews.filter((b) => b.type === "negative").length,
  }

  // Calculate grade averages by subject
  const gradesBySubject: Record<string, { total: number; count: number }> = {}
  grades.forEach((g) => {
    if (!gradesBySubject[g.subject]) {
      gradesBySubject[g.subject] = { total: 0, count: 0 }
    }
    gradesBySubject[g.subject].total += g.score
    gradesBySubject[g.subject].count++
  })

  const StrikeIndicator = ({ strikes }: { strikes: number }) => (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <div
          key={i}
          className={`w-4 h-4 rounded-full ${i <= strikes ? "bg-red-500" : "bg-muted-foreground/20"}`}
          aria-label={`Strike ${i}`}
        />
      ))}
    </div>
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold text-foreground">{student.name}</h1>
            <p className="text-muted-foreground">Student Profile</p>
          </div>
        </div>

        {/* Student Info Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Full Name</p>
                  <p className="font-medium">{student.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Grade & Class</p>
                  <p className="font-medium">
                    Grade {student.grade} - {student.class}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="font-medium">
                    {student.city}, {student.country}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Enrolled</p>
                  <p className="font-medium">{new Date(student.enrollmentDate).toLocaleDateString()}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid gap-4 md:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Attendance Rate</p>
                  <p className="text-2xl font-bold">
                    {attendance.length > 0 ? Math.round((attendanceStats.present / attendance.length) * 100) : 0}%
                  </p>
                </div>
                <UserCheck className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Positive Behavior</p>
                  <p className="text-2xl font-bold text-green-600">{behaviorStats.positive}</p>
                </div>
                <ThumbsUp className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Negative Behavior</p>
                  <p className="text-2xl font-bold text-red-600">{behaviorStats.negative}</p>
                </div>
                <ThumbsDown className="w-8 h-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Grades</p>
                  <p className="text-2xl font-bold">{grades.length}</p>
                </div>
                <GraduationCap className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="grades">Grades</TabsTrigger>
            <TabsTrigger value="behavior">Behavior</TabsTrigger>
            <TabsTrigger value="logs">Teacher Logs</TabsTrigger>
            {canViewHealthLogs && <TabsTrigger value="health">Health Logs</TabsTrigger>}
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            {/* Grade Averages */}
            <Card>
              <CardHeader>
                <CardTitle>Subject Averages</CardTitle>
                <CardDescription>Average grades by subject</CardDescription>
              </CardHeader>
              <CardContent>
                {Object.keys(gradesBySubject).length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No grades recorded yet</p>
                ) : (
                  <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-4">
                    {Object.entries(gradesBySubject).map(([subject, data]) => (
                      <div key={subject} className="p-4 bg-muted rounded-lg">
                        <p className="text-sm text-muted-foreground">{subject}</p>
                        <p className="text-2xl font-bold">{(data.total / data.count).toFixed(2)}</p>
                        <p className="text-xs text-muted-foreground">
                          {data.total} total / {data.count} grades
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="grades" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>All Grades</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Assignment</TableHead>
                      <TableHead>Score</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {grades.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          No grades recorded
                        </TableCell>
                      </TableRow>
                    ) : (
                      grades.map((grade) => (
                        <TableRow key={grade.id}>
                          <TableCell>{new Date(grade.date).toLocaleDateString()}</TableCell>
                          <TableCell>{grade.subject}</TableCell>
                          <TableCell>{grade.assignmentName}</TableCell>
                          <TableCell className="font-bold">
                            {grade.score}/{grade.maxScore}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="behavior" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Behavioral Records</CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {behavioralReviews.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          No behavioral records
                        </TableCell>
                      </TableRow>
                    ) : (
                      behavioralReviews.map((review) => (
                        <TableRow key={review.id}>
                          <TableCell>{new Date(review.date).toLocaleDateString()}</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                review.type === "positive" ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                              }
                            >
                              {review.type}
                            </Badge>
                          </TableCell>
                          <TableCell>{review.category}</TableCell>
                          <TableCell className="max-w-xs truncate">{review.description || "-"}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logs" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Teacher Logs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Subject</TableHead>
                      <TableHead>Notes</TableHead>
                      <TableHead>Strikes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teacherLogs.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          No teacher logs
                        </TableCell>
                      </TableRow>
                    ) : (
                      teacherLogs.map((log) => (
                        <TableRow key={log.id}>
                          <TableCell>{new Date(log.date).toLocaleDateString()}</TableCell>
                          <TableCell>{log.subject}</TableCell>
                          <TableCell className="max-w-xs truncate">{log.notes}</TableCell>
                          <TableCell>
                            <StrikeIndicator strikes={log.strikes} />
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {canViewHealthLogs && (
            <TabsContent value="health" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Health & Wellness Logs</CardTitle>
                  <CardDescription>Records from psychologist and nurse</CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Notes</TableHead>
                        <TableHead>Confidential</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {studentLogs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                            No health logs
                          </TableCell>
                        </TableRow>
                      ) : (
                        studentLogs.map((log) => (
                          <TableRow key={log.id}>
                            <TableCell>{new Date(log.date).toLocaleDateString()}</TableCell>
                            <TableCell>
                              {log.staffRole === "psychologist" ? (
                                <Badge className="bg-purple-100 text-purple-800">
                                  <Brain className="w-3 h-3 mr-1" />
                                  Psychologist
                                </Badge>
                              ) : (
                                <Badge className="bg-pink-100 text-pink-800">
                                  <Heart className="w-3 h-3 mr-1" />
                                  Nurse
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell className="max-w-xs truncate">{log.notes}</TableCell>
                            <TableCell>
                              {log.confidential ? (
                                <Badge variant="destructive">Yes</Badge>
                              ) : (
                                <Badge variant="secondary">No</Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </DashboardLayout>
  )
}
