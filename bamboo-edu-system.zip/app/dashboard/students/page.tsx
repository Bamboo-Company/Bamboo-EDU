"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import type { Student } from "@/lib/types"
import { Plus, Edit, Trash2, Search, Eye, Link } from "lucide-react"
import NextLink from "next/link"

export default function StudentsPage() {
  const { user } = useAuth()
  const [students, setStudents] = useState<Student[]>(dataStore.getStudents())
  const [searchTerm, setSearchTerm] = useState("")
  const [classFilter, setClassFilter] = useState<string>("all")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [editingStudent, setEditingStudent] = useState<Student | null>(null)
  const [studentToDelete, setStudentToDelete] = useState<Student | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    grade: "",
    class: "",
    school: "",
    city: "",
    country: "",
    parentId: "",
    dateOfBirth: "",
    enrollmentDate: "",
  })

  if (!user) return null

  const canEdit = ["admin", "principal", "vice-principal"].includes(user.role)
  const classes = dataStore.getClasses()
  const users = dataStore.getUsers()

  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.school.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesClass = classFilter === "all" || s.class === classFilter
    return matchesSearch && matchesClass
  })

  const handleOpenDialog = (studentToEdit?: Student) => {
    if (studentToEdit) {
      setEditingStudent(studentToEdit)
      setFormData({
        name: studentToEdit.name,
        grade: studentToEdit.grade,
        class: studentToEdit.class,
        school: studentToEdit.school,
        city: studentToEdit.city,
        country: studentToEdit.country,
        parentId: studentToEdit.parentId,
        dateOfBirth: studentToEdit.dateOfBirth,
        enrollmentDate: studentToEdit.enrollmentDate,
      })
    } else {
      setEditingStudent(null)
      setFormData({
        name: "",
        grade: "",
        class: "",
        school: "Bamboo International School",
        city: "София",
        country: "България",
        parentId: "",
        dateOfBirth: "",
        enrollmentDate: new Date().toISOString().split("T")[0],
      })
    }
    setDialogOpen(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingStudent) {
      dataStore.updateStudent(editingStudent.id, formData)
    } else {
      const newStudent: Student = {
        id: `s${Date.now()}`,
        ...formData,
      }
      dataStore.addStudent(newStudent)
    }

    setStudents(dataStore.getStudents())
    setDialogOpen(false)
  }

  const handleDelete = () => {
    if (studentToDelete) {
      dataStore.deleteStudent(studentToDelete.id)
      setStudents(dataStore.getStudents())
    }
    setDeleteDialogOpen(false)
    setStudentToDelete(null)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Ученици</h1>
            <p className="text-muted-foreground">Управление на записите и информацията за учениците</p>
          </div>
          {canEdit && (
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Добави ученик
            </Button>
          )}
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Търсене по име или училище..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={classFilter} onValueChange={setClassFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Филтриране по клас" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Всички класове</SelectItem>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.name}>
                      {cls.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Students Table */}
        <Card>
          <CardHeader>
            <CardTitle>Ученици ({filteredStudents.length})</CardTitle>
            <CardDescription>Всички записани ученици</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Име</TableHead>
                    <TableHead>Клас</TableHead>
                    <TableHead>Училище</TableHead>
                    <TableHead>Град</TableHead>
                    <TableHead>Държава</TableHead>
                    <TableHead>Акаунт</TableHead>
                    <TableHead className="text-right">Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                        Няма намерени ученици
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredStudents.map((s) => {
                      const linkedUser = s.linkedUserId ? users.find((u) => u.id === s.linkedUserId) : null
                      return (
                        <TableRow key={s.id}>
                          <TableCell className="font-medium">{s.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{s.class}</Badge>
                          </TableCell>
                          <TableCell>{s.school}</TableCell>
                          <TableCell>{s.city}</TableCell>
                          <TableCell>{s.country}</TableCell>
                          <TableCell>
                            {linkedUser ? (
                              <Badge className="bg-green-500/20 text-green-500 border-green-500">
                                <Link className="w-3 h-3 mr-1" />
                                Свързан
                              </Badge>
                            ) : (
                              <Badge variant="secondary">Несвързан</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <NextLink href={`/dashboard/students/${s.id}`}>
                                <Button variant="ghost" size="icon">
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </NextLink>
                              {canEdit && (
                                <>
                                  <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(s)}>
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => {
                                      setStudentToDelete(s)
                                      setDeleteDialogOpen(true)
                                    }}
                                  >
                                    <Trash2 className="w-4 h-4 text-destructive" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Add/Edit Student Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>{editingStudent ? "Редактиране на ученик" : "Добавяне на нов ученик"}</DialogTitle>
              <DialogDescription>
                {editingStudent ? "Актуализирайте информацията за ученика" : "Попълнете данните за ученика"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Пълно име</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dateOfBirth">Дата на раждане</Label>
                  <Input
                    id="dateOfBirth"
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="grade">Клас (число)</Label>
                  <Input
                    id="grade"
                    value={formData.grade}
                    onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                    placeholder="напр. 10"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="class">Паралелка</Label>
                  <Select value={formData.class} onValueChange={(v) => setFormData({ ...formData, class: v })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Изберете паралелка" />
                    </SelectTrigger>
                    <SelectContent>
                      {classes.map((cls) => (
                        <SelectItem key={cls.id} value={cls.name}>
                          {cls.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="school">Училище</Label>
                  <Input
                    id="school"
                    value={formData.school}
                    onChange={(e) => setFormData({ ...formData, school: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="city">Град</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="country">Държава</Label>
                  <Input
                    id="country"
                    value={formData.country}
                    onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="enrollmentDate">Дата на записване</Label>
                  <Input
                    id="enrollmentDate"
                    type="date"
                    value={formData.enrollmentDate}
                    onChange={(e) => setFormData({ ...formData, enrollmentDate: e.target.value })}
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">{editingStudent ? "Запази промените" : "Създай ученик"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Изтриване на ученик?</DialogTitle>
              <DialogDescription>
                Сигурни ли сте, че искате да изтриете {studentToDelete?.name}? Това ще премахне и всички свързани
                записи.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                Отказ
              </Button>
              <Button variant="destructive" onClick={handleDelete}>
                Изтрий
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
