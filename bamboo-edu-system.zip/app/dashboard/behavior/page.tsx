"use client"

import React from "react"
import { useState, useEffect, useCallback } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { dataStore } from "@/lib/data-store"
import { POSITIVE_BADGES, NEGATIVE_BADGES, type BehavioralReview, type BehaviorBadge } from "@/lib/types"
import {
  Plus,
  ThumbsUp,
  ThumbsDown,
  Trash2,
  Hand,
  Heart,
  Users,
  Crown,
  Clock,
  Lightbulb,
  Check,
  Angry,
  Megaphone,
  Gavel,
  AlertTriangle,
  AlertCircle,
  ClipboardList,
  DoorOpen,
  UserMinus,
  TrendingDown,
  TrendingUp,
  Hourglass,
  BookX,
  Shirt,
  FileQuestion,
  Copy,
  Frown,
  ArrowLeft,
  Save,
  Brain,
  Target,
  Palette,
  Star,
  HandHelping,
  User,
  School,
  GraduationCap,
} from "lucide-react"

const iconMap: Record<string, React.ReactNode> = {
  hand: <Hand className="w-12 h-12" />,
  heart: <Heart className="w-12 h-12" />,
  users: <Users className="w-12 h-12" />,
  crown: <Crown className="w-12 h-12" />,
  thumbsup: <ThumbsUp className="w-12 h-12" />,
  clock: <Clock className="w-12 h-12" />,
  lightbulb: <Lightbulb className="w-12 h-12" />,
  check: <Check className="w-12 h-12" />,
  angry: <Angry className="w-12 h-12" />,
  megaphone: <Megaphone className="w-12 h-12" />,
  gavel: <Gavel className="w-12 h-12" />,
  alerttriangle: <AlertTriangle className="w-12 h-12" />,
  alert: <AlertCircle className="w-12 h-12" />,
  clipboard: <ClipboardList className="w-12 h-12" />,
  dooropen: <DoorOpen className="w-12 h-12" />,
  userminus: <UserMinus className="w-12 h-12" />,
  trendingdown: <TrendingDown className="w-12 h-12" />,
  trendingup: <TrendingUp className="w-12 h-12" />,
  hourglass: <Hourglass className="w-12 h-12" />,
  bookx: <BookX className="w-12 h-12" />,
  shirt: <Shirt className="w-12 h-12" />,
  filequestion: <FileQuestion className="w-12 h-12" />,
  copy: <Copy className="w-12 h-12" />,
  frown: <Frown className="w-12 h-12" />,
  brain: <Brain className="w-12 h-12" />,
  target: <Target className="w-12 h-12" />,
  palette: <Palette className="w-12 h-12" />,
  star: <Star className="w-12 h-12" />,
  handhelping: <HandHelping className="w-12 h-12" />,
  user: <User className="w-12 h-12" />,
}

export default function BehaviorPage() {
  const { user } = useAuth()
  const [reviews, setReviews] = useState<BehavioralReview[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState<"all" | "positive" | "negative">("all")

  const [selectedSchool, setSelectedSchool] = useState("")
  const [selectedClass, setSelectedClass] = useState("")
  const [selectedStudents, setSelectedStudents] = useState<string[]>([])

  const [badgeTab, setBadgeTab] = useState<"positive" | "negative">("positive")
  const [selectedBadge, setSelectedBadge] = useState<BehaviorBadge | null>(null)
  const [comment, setComment] = useState("")

  const refreshData = useCallback(() => {
    setReviews(dataStore.getBehavioralReviews())
  }, [])

  useEffect(() => {
    refreshData()
  }, [refreshData])

  if (!user) return null

  const allStudents = dataStore.getStudents()
  const allClasses = dataStore.getClasses()
  const subjects = dataStore.getSubjects()
  const schools = dataStore.getSchools()

  const classes = selectedSchool ? allClasses.filter((c) => c.schoolId === selectedSchool) : allClasses

  const students = selectedClass
    ? allStudents.filter((s) => s.class === selectedClass && (!selectedSchool || s.schoolId === selectedSchool))
    : []

  const getUserSchools = () => {
    if (user.role === "admin") return schools
    if (user.schoolRoles && user.schoolRoles.length > 0) {
      return schools.filter((s) => user.schoolRoles?.some((sr) => sr.schoolId === s.id))
    }
    return []
  }

  const userSchools = getUserSchools()

  const getLinkedStudents = (): string[] => {
    if (user.role === "student") {
      const linkedStudent = dataStore.getStudentByUserId(user.id)
      return linkedStudent ? [linkedStudent.id] : []
    } else if (user.role === "parent") {
      const linkedStudents = dataStore.getStudentsByParentId(user.id)
      return linkedStudents.map((s) => s.id)
    }
    return []
  }

  const linkedStudentIds = getLinkedStudents()

  const getFilteredReviews = () => {
    let filtered = activeTab === "all" ? reviews : reviews.filter((r) => r.type === activeTab)

    if (user.role === "student" || user.role === "parent") {
      if (linkedStudentIds.length > 0) {
        filtered = filtered.filter((r) => linkedStudentIds.includes(r.studentId))
      } else {
        filtered = []
      }
    }

    return filtered
  }

  const filteredReviews = getFilteredReviews()

  const canAddReviews = ["admin", "principal", "vice-principal", "teacher"].includes(user.role)

  const toggleStudent = (studentId: string) => {
    setSelectedStudents((prev) =>
      prev.includes(studentId) ? prev.filter((id) => id !== studentId) : [...prev, studentId],
    )
  }

  const selectAllStudents = () => {
    if (selectedStudents.length === students.length) {
      setSelectedStudents([])
    } else {
      setSelectedStudents(students.map((s) => s.id))
    }
  }

  const handleSave = () => {
    if (selectedStudents.length === 0 || !selectedBadge) return

    selectedStudents.forEach((studentId) => {
      const newReview: BehavioralReview = {
        id: `${Date.now()}-${studentId}-${Math.random().toString(36).substr(2, 9)}`,
        studentId,
        type: selectedBadge.type,
        category: selectedBadge.name,
        badgeId: selectedBadge.id,
        description: comment || selectedBadge.description,
        date: new Date().toISOString(),
        recordedBy: user.id,
      }

      dataStore.addBehavioralReview(newReview)

      const student = allStudents.find((s) => s.id === studentId)
      if (student?.parentId) {
        dataStore.addNotification({
          id: `${Date.now()}-notif-${student.id}-${Math.random().toString(36).substr(2, 9)}`,
          userId: student.parentId,
          title: `${selectedBadge.type === "positive" ? "Похвала" : "Забележка"}`,
          message: `${student.name}: ${selectedBadge.name}`,
          type: selectedBadge.type === "positive" ? "success" : "warning",
          read: false,
          createdAt: new Date().toISOString(),
        })
      }
    })

    refreshData()
    setDialogOpen(false)
    setSelectedBadge(null)
    setSelectedStudents([])
    setSelectedClass("")
    setSelectedSchool("")
    setComment("")
  }

  const handleDeleteReview = (reviewId: string) => {
    dataStore.deleteBehavioralReview(reviewId)
    refreshData()
  }

  const currentBadges = badgeTab === "positive" ? POSITIVE_BADGES : NEGATIVE_BADGES

  const getBadgeById = (id: string): BehaviorBadge | undefined => {
    return [...POSITIVE_BADGES, ...NEGATIVE_BADGES].find((b) => b.id === id)
  }

  const handleSchoolChange = (schoolId: string) => {
    setSelectedSchool(schoolId)
    setSelectedClass("")
    setSelectedStudents([])
  }

  const handleClassChange = (classId: string) => {
    setSelectedClass(classId)
    setSelectedStudents([])
  }

  const handleOpenDialog = () => {
    setSelectedSchool("")
    setSelectedClass("")
    setSelectedStudents([])
    setSelectedBadge(null)
    setBadgeTab("positive")
    setComment("")
    setDialogOpen(true)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Отзиви за поведение</h1>
            <p className="text-muted-foreground">
              {user.role === "student" || user.role === "parent"
                ? "Преглед на похвали и забележки"
                : "Въвеждане на похвали и забележки"}
            </p>
          </div>
          {canAddReviews && (
            <Button onClick={handleOpenDialog} size="lg">
              <Plus className="w-4 h-4 mr-2" />
              Добави отзив
            </Button>
          )}
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card className="border-green-500/30 bg-green-500/5">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Похвали</p>
                  <p className="text-2xl font-bold text-green-500">
                    {filteredReviews.filter((r) => r.type === "positive").length}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                  <ThumbsUp className="w-6 h-6 text-green-500" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-red-500/30 bg-red-500/5">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Забележки</p>
                  <p className="text-2xl font-bold text-red-500">
                    {filteredReviews.filter((r) => r.type === "negative").length}
                  </p>
                </div>
                <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center">
                  <ThumbsDown className="w-6 h-6 text-red-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filter Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
          <TabsList>
            <TabsTrigger value="all">Всички</TabsTrigger>
            <TabsTrigger value="positive">Похвали</TabsTrigger>
            <TabsTrigger value="negative">Забележки</TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Reviews Table */}
        <Card>
          <CardHeader>
            <CardTitle>История на отзивите</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredReviews.length === 0 ? (
              <p className="text-center text-muted-foreground py-8">Няма записани отзиви</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ученик</TableHead>
                    <TableHead>Тип</TableHead>
                    <TableHead>Категория</TableHead>
                    <TableHead>Описание</TableHead>
                    <TableHead>Дата</TableHead>
                    {canAddReviews && <TableHead>Действия</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReviews.map((review) => {
                    const student = allStudents.find((s) => s.id === review.studentId)
                    const badge = getBadgeById(review.badgeId)
                    return (
                      <TableRow key={review.id}>
                        <TableCell className="font-medium">{student?.name || "Неизвестен"}</TableCell>
                        <TableCell>
                          <Badge variant={review.type === "positive" ? "default" : "destructive"}>
                            {review.type === "positive" ? "Похвала" : "Забележка"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {badge && (
                            <div className="flex items-center gap-2">
                              <div
                                className="w-8 h-8 rounded-full flex items-center justify-center text-white"
                                style={{ backgroundColor: badge.color }}
                              >
                                {React.cloneElement(iconMap[badge.icon] as React.ReactElement, {
                                  className: "w-4 h-4",
                                })}
                              </div>
                              {review.category}
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="max-w-xs truncate">{review.description}</TableCell>
                        <TableCell>{new Date(review.date).toLocaleDateString("bg-BG")}</TableCell>
                        {canAddReviews && (
                          <TableCell>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteReview(review.id)}>
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </TableCell>
                        )}
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent
            showCloseButton={false}
            className="!fixed !inset-0 !top-0 !left-0 !translate-x-0 !translate-y-0 !w-screen !h-screen !max-w-none !max-h-none !m-0 !p-0 !rounded-none !border-0 bg-background z-[100]"
          >
            <div className="flex flex-col h-screen w-screen overflow-hidden">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b bg-card shrink-0">
                <div className="flex items-center gap-4">
                  <Button variant="outline" size="lg" onClick={() => setDialogOpen(false)}>
                    <ArrowLeft className="w-5 h-5 mr-2" />
                    Назад
                  </Button>
                  <div>
                    <h2 className="text-2xl font-bold">Въвеждане на отзив</h2>
                    <p className="text-muted-foreground">
                      {selectedSchool && schools.find((s) => s.id === selectedSchool)?.shortName}
                      {selectedClass && ` • ${classes.find((c) => c.id === selectedClass)?.name}`}
                      {selectedStudents.length > 0 && ` • ${selectedStudents.length} ученици`}
                      {selectedBadge && ` • ${selectedBadge.label}`}
                    </p>
                  </div>
                </div>
                <Button
                  size="lg"
                  onClick={handleSave}
                  disabled={selectedStudents.length === 0 || !selectedBadge}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white px-8"
                >
                  <Save className="w-5 h-5 mr-2" />
                  Запази
                </Button>
              </div>

              {/* Main Content - 5 columns taking full height */}
              <div className="flex-1 grid grid-cols-5 gap-0 overflow-hidden">
                {/* Column 1: School Selection */}
                <div className="flex flex-col border-r overflow-hidden bg-purple-950/30">
                  <div className="p-3 bg-purple-600 text-white shrink-0">
                    <div className="flex items-center gap-2">
                      <School className="w-5 h-5" />
                      <span className="font-bold text-lg">1. Избери училище</span>
                    </div>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-2 space-y-1">
                      {schools.map((school) => (
                        <div
                          key={school.id}
                          onClick={() => {
                            setSelectedSchool(school.id)
                            setSelectedClass("")
                            setSelectedStudents([])
                          }}
                          className={`p-3 rounded-lg cursor-pointer transition-all ${
                            selectedSchool === school.id ? "bg-purple-600 text-white" : "hover:bg-purple-600/20"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <School className="w-5 h-5" />
                            <span className="font-medium text-sm">{school.shortName || school.fullName}</span>
                          </div>
                        </div>
                      ))}
                      {schools.length === 0 && (
                        <p className="text-muted-foreground text-center py-4 text-sm">Няма училища</p>
                      )}
                    </div>
                  </ScrollArea>
                </div>

                {/* Column 2: Class Selection */}
                <div className="flex flex-col border-r overflow-hidden bg-blue-950/30">
                  <div className="p-3 bg-blue-600 text-white shrink-0">
                    <div className="flex items-center gap-2">
                      <GraduationCap className="w-5 h-5" />
                      <span className="font-bold text-lg">2. Избери клас</span>
                    </div>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-2 space-y-1">
                      {!selectedSchool ? (
                        <p className="text-muted-foreground text-center py-4 text-sm">Първо избери училище</p>
                      ) : classes.length === 0 ? (
                        <p className="text-muted-foreground text-center py-4 text-sm">Няма класове</p>
                      ) : (
                        classes.map((cls) => (
                          <div
                            key={cls.id}
                            onClick={() => {
                              setSelectedClass(cls.id)
                              setSelectedStudents([])
                            }}
                            className={`p-3 rounded-lg cursor-pointer transition-all ${
                              selectedClass === cls.id ? "bg-blue-600 text-white" : "hover:bg-blue-600/20"
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <GraduationCap className="w-5 h-5" />
                              <span className="font-medium">{cls.name}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </div>

                {/* Column 3: Student Selection */}
                <div className="flex flex-col border-r overflow-hidden bg-green-950/30">
                  <div className="p-3 bg-green-600 text-white shrink-0">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Users className="w-5 h-5" />
                        <span className="font-bold text-lg">3. Избери ученик</span>
                      </div>
                      {students.length > 0 && (
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => {
                            if (selectedStudents.length === students.length) {
                              setSelectedStudents([])
                            } else {
                              setSelectedStudents(students.map((s) => s.id))
                            }
                          }}
                          className="text-xs h-7"
                        >
                          {selectedStudents.length === students.length ? "Изчисти" : "Избери всички"}
                        </Button>
                      )}
                    </div>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-2 space-y-1">
                      {!selectedClass ? (
                        <p className="text-muted-foreground text-center py-4 text-sm">Първо избери клас</p>
                      ) : students.length === 0 ? (
                        <p className="text-muted-foreground text-center py-4 text-sm">Няма ученици</p>
                      ) : (
                        students.map((student, index) => (
                          <div
                            key={student.id}
                            onClick={() => toggleStudent(student.id)}
                            className={`p-3 rounded-lg cursor-pointer transition-all ${
                              selectedStudents.includes(student.id)
                                ? "bg-green-600 text-white"
                                : "hover:bg-green-600/20"
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <div
                                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                                  selectedStudents.includes(student.id) ? "bg-white/20" : "bg-green-600/20"
                                }`}
                              >
                                {index + 1}
                              </div>
                              <span className="font-medium text-sm">{student.name}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </ScrollArea>
                </div>

                {/* Column 4: Badge Selection */}
                <div className="flex flex-col border-r overflow-hidden bg-amber-950/30">
                  <div className="p-3 bg-amber-600 text-white shrink-0">
                    <div className="flex items-center gap-2">
                      <Star className="w-5 h-5" />
                      <span className="font-bold text-lg">4. Избери значка</span>
                    </div>
                  </div>
                  <Tabs
                    value={badgeTab}
                    onValueChange={(v) => setBadgeTab(v as "positive" | "negative")}
                    className="flex flex-col flex-1 overflow-hidden"
                  >
                    <TabsList className="w-full rounded-none shrink-0 h-12">
                      <TabsTrigger
                        value="positive"
                        className="flex-1 data-[state=active]:bg-green-600 data-[state=active]:text-white text-base"
                      >
                        Похвали
                      </TabsTrigger>
                      <TabsTrigger
                        value="negative"
                        className="flex-1 data-[state=active]:bg-red-600 data-[state=active]:text-white text-base"
                      >
                        Забележки
                      </TabsTrigger>
                    </TabsList>
                    <ScrollArea className="flex-1">
                      <div className="p-3 grid grid-cols-2 gap-2">
                        {(badgeTab === "positive" ? POSITIVE_BADGES : NEGATIVE_BADGES).map((badge) => (
                          <div
                            key={badge.id}
                            onClick={() => setSelectedBadge(badge)}
                            className={`flex flex-col items-center p-3 rounded-xl cursor-pointer transition-all ${
                              selectedBadge?.id === badge.id
                                ? "ring-4 ring-white bg-white/20 scale-105"
                                : "hover:bg-white/10"
                            }`}
                          >
                            <div
                              className="w-16 h-16 rounded-full flex items-center justify-center text-white mb-2 shadow-xl"
                              style={{ backgroundColor: badge.color }}
                            >
                              {iconMap[badge.icon] || <Star className="w-12 h-12" />}
                            </div>
                            <span className="text-xs text-center font-medium leading-tight">{badge.label}</span>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </Tabs>
                </div>

                {/* Column 5: Comment */}
                <div className="flex flex-col overflow-hidden bg-slate-950/30">
                  <div className="p-3 bg-slate-600 text-white shrink-0">
                    <div className="flex items-center gap-2">
                      <ClipboardList className="w-5 h-5" />
                      <span className="font-bold text-lg">5. Въведи отзив</span>
                    </div>
                  </div>
                  <div className="flex-1 p-4 flex flex-col">
                    {selectedBadge ? (
                      <>
                        <div className="flex flex-col items-center mb-4">
                          <div
                            className="w-24 h-24 rounded-full flex items-center justify-center text-white mb-2 shadow-xl"
                            style={{ backgroundColor: selectedBadge.color }}
                          >
                            {iconMap[selectedBadge.icon] || <Star className="w-12 h-12" />}
                          </div>
                          <span className="font-bold text-lg">{selectedBadge.label}</span>
                        </div>
                        <Textarea
                          value={comment}
                          onChange={(e) => setComment(e.target.value)}
                          placeholder="Въведи коментар (по избор)..."
                          className="flex-1 min-h-[200px] text-base resize-none"
                        />
                      </>
                    ) : (
                      <div className="flex-1 flex items-center justify-center text-muted-foreground text-center p-4">
                        <div>
                          <Star className="w-16 h-16 mx-auto mb-4 opacity-20" />
                          <p className="text-lg">Тук се визуализират избраните отзиви.</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
