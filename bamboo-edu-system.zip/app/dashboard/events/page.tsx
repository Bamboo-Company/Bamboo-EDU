"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { dataStore } from "@/lib/data-store"
import type { Event, UserRole } from "@/lib/types"
import { Plus, Calendar, MapPin, Clock, Trash2 } from "lucide-react"

const ALL_ROLES: UserRole[] = [
  "admin",
  "principal",
  "vice-principal",
  "teacher",
  "psychologist",
  "nurse",
  "student",
  "parent",
]

const ROLE_LABELS: Record<UserRole, string> = {
  admin: "Администратор",
  principal: "Директор",
  "vice-principal": "Зам.-директор",
  teacher: "Учител",
  psychologist: "Психолог",
  nurse: "Мед. сестра",
  student: "Ученик",
  parent: "Родител",
}

export default function EventsPage() {
  const { user } = useAuth()
  const [events, setEvents] = useState<Event[]>(dataStore.getEvents())
  const [dialogOpen, setDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [eventToDelete, setEventToDelete] = useState<Event | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    date: "",
    time: "",
    location: "",
    targetRoles: [] as UserRole[],
  })

  if (!user) return null

  const canCreate = ["admin", "principal", "vice-principal", "teacher"].includes(user.role)
  const canDelete = ["admin", "principal", "vice-principal"].includes(user.role)

  // Filter events based on user role
  const visibleEvents = events.filter((e) => e.targetRoles.includes(user.role) || e.createdBy === user.id)

  // Sort by date
  const sortedEvents = [...visibleEvents].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  const upcomingEvents = sortedEvents.filter((e) => new Date(e.date) >= new Date())
  const pastEvents = sortedEvents.filter((e) => new Date(e.date) < new Date())

  const handleRoleToggle = (role: UserRole) => {
    setFormData((prev) => ({
      ...prev,
      targetRoles: prev.targetRoles.includes(role)
        ? prev.targetRoles.filter((r) => r !== role)
        : [...prev.targetRoles, role],
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    const newEvent: Event = {
      id: Date.now().toString(),
      ...formData,
      createdBy: user.id,
    }

    dataStore.addEvent(newEvent)

    // Send notifications to target roles
    const users = dataStore.getUsers().filter((u) => formData.targetRoles.includes(u.role))
    users.forEach((targetUser) => {
      dataStore.addNotification({
        id: `${Date.now()}-${targetUser.id}`,
        userId: targetUser.id,
        title: "📅 Ново събитие",
        message: `${formData.title} на ${formData.date} в ${formData.time}`,
        type: "info",
        read: false,
        createdAt: new Date().toISOString(),
      })
    })

    setEvents(dataStore.getEvents())
    setDialogOpen(false)
    setFormData({ title: "", description: "", date: "", time: "", location: "", targetRoles: [] })
  }

  const handleDelete = () => {
    if (eventToDelete) {
      dataStore.deleteEvent(eventToDelete.id)
      setEvents(dataStore.getEvents())
    }
    setDeleteDialogOpen(false)
    setEventToDelete(null)
  }

  const EventCard = ({ event }: { event: Event }) => (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{event.title}</CardTitle>
            <CardDescription className="flex items-center gap-2 mt-1">
              <Calendar className="w-4 h-4" />
              {new Date(event.date).toLocaleDateString("bg-BG", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </CardDescription>
          </div>
          {canDelete && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => {
                setEventToDelete(event)
                setDeleteDialogOpen(true)
              }}
            >
              <Trash2 className="w-4 h-4 text-destructive" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <p className="text-sm text-muted-foreground">{event.description}</p>
        <div className="flex flex-wrap gap-4 text-sm">
          <div className="flex items-center gap-1 text-muted-foreground">
            <Clock className="w-4 h-4" />
            {event.time}
          </div>
          <div className="flex items-center gap-1 text-muted-foreground">
            <MapPin className="w-4 h-4" />
            {event.location}
          </div>
        </div>
        <div className="flex flex-wrap gap-1">
          {event.targetRoles.map((role) => (
            <Badge key={role} variant="secondary" className="text-xs">
              {ROLE_LABELS[role]}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">📅 Събития</h1>
            <p className="text-muted-foreground">Училищни събития и съобщения</p>
          </div>
          {canCreate && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Създай събитие
            </Button>
          )}
        </div>

        {/* Upcoming Events */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-foreground">🗓️ Предстоящи събития</h2>
          {upcomingEvents.length === 0 ? (
            <Card>
              <CardContent className="py-8 text-center text-muted-foreground">Няма предстоящи събития</CardContent>
            </Card>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {upcomingEvents.map((event) => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          )}
        </div>

        {/* Past Events */}
        {pastEvents.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-muted-foreground">📜 Минали събития</h2>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {pastEvents.map((event) => (
                <div key={event.id} className="opacity-60">
                  <EventCard event={event} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Create Event Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Създай ново събитие</DialogTitle>
              <DialogDescription>Планирайте ново училищно събитие</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Заглавие на събитието</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Описание</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="date">Дата</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Час</Label>
                  <Input
                    id="time"
                    type="time"
                    value={formData.time}
                    onChange={(e) => setFormData({ ...formData, time: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Локация</Label>
                <Input
                  id="location"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="напр. Главна аула"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Видимо за</Label>
                <div className="grid grid-cols-2 gap-2">
                  {ALL_ROLES.map((role) => (
                    <div key={role} className="flex items-center space-x-2">
                      <Checkbox
                        id={`role-${role}`}
                        checked={formData.targetRoles.includes(role)}
                        onCheckedChange={() => handleRoleToggle(role)}
                      />
                      <label htmlFor={`role-${role}`} className="text-sm cursor-pointer">
                        {ROLE_LABELS[role]}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit" disabled={formData.targetRoles.length === 0}>
                  Създай събитие
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Изтриване на събитие?</DialogTitle>
              <DialogDescription>
                Сигурни ли сте, че искате да изтриете "{eventToDelete?.title}"? Това действие не може да бъде отменено.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                Отказ
              </Button>
              <Button variant="destructive" onClick={handleDelete}>
                Изтрий
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
