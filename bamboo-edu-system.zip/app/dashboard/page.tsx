"use client"

import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { dataStore } from "@/lib/data-store"
import { Users, GraduationCap, Calendar, MessageSquare, AlertTriangle } from "lucide-react"

const ROLE_TRANSLATIONS: Record<string, string> = {
  admin: "Администратор",
  principal: "Директор",
  "vice-principal": "Заместник-директор",
  teacher: "Учител",
  psychologist: "Психолог",
  nurse: "Медицинска сестра",
  student: "Ученик",
  parent: "Родител",
}

export default function DashboardPage() {
  const { user } = useAuth()

  if (!user) return null

  const students = dataStore.getStudents()
  const users = dataStore.getUsers()
  const events = dataStore.getEvents()
  const pendingRequests = dataStore.getPendingSupplyRequests()
  const unreadMessages = dataStore.getInbox(user.id).filter((m) => !m.read)

  const stats = [
    {
      label: "Общо ученици",
      value: students.length,
      icon: <GraduationCap className="w-5 h-5" />,
      color: "text-primary",
    },
    { label: "Общо потребители", value: users.length, icon: <Users className="w-5 h-5" />, color: "text-blue-500" },
    {
      label: "Предстоящи събития",
      value: events.length,
      icon: <Calendar className="w-5 h-5" />,
      color: "text-amber-500",
    },
    {
      label: "Непрочетени съобщения",
      value: unreadMessages.length,
      icon: <MessageSquare className="w-5 h-5" />,
      color: "text-purple-500",
    },
  ]

  const adminStats = [
    {
      label: "Чакащи заявки",
      value: pendingRequests.length,
      icon: <AlertTriangle className="w-5 h-5" />,
      color: "text-orange-500",
    },
  ]

  const displayStats = ["admin", "principal", "vice-principal"].includes(user.role) ? [...stats, ...adminStats] : stats

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Добре дошли, {user.name} 👋</h1>
          <p className="text-muted-foreground">Роля: {ROLE_TRANSLATIONS[user.role] || user.role}</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {displayStats.map((stat) => (
            <Card key={stat.label}>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">{stat.label}</CardTitle>
                <div className={stat.color}>{stat.icon}</div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions based on role */}
        <Card>
          <CardHeader>
            <CardTitle>Бързи действия ⚡</CardTitle>
            <CardDescription>Често използвани задачи за вашата роля</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {user.role === "teacher" && (
                <>
                  <QuickActionCard
                    title="📋 Отбележи присъствие"
                    description="Отбележете присъствието на учениците за днес"
                    href="/dashboard/attendance"
                  />
                  <QuickActionCard
                    title="📚 Задай домашно"
                    description="Създайте ново домашно задание"
                    href="/dashboard/homework"
                  />
                  <QuickActionCard
                    title="📝 Въведи оценки"
                    description="Запишете оценките на учениците"
                    href="/dashboard/grades"
                  />
                </>
              )}
              {(user.role === "psychologist" || user.role === "nurse") && (
                <>
                  <QuickActionCard
                    title="📋 Дневници на ученици"
                    description="Преглед и създаване на здравни дневници"
                    href="/dashboard/health"
                  />
                  <QuickActionCard
                    title="👥 Преглед на ученици"
                    description="Достъп до информация за учениците"
                    href="/dashboard/students"
                  />
                </>
              )}
              {(user.role === "student" || user.role === "parent") && (
                <>
                  <QuickActionCard
                    title="📚 Преглед на домашни"
                    description="Проверете зададените домашни"
                    href="/dashboard/homework"
                  />
                  <QuickActionCard
                    title="📊 Преглед на оценки"
                    description="Проверете академичното представяне"
                    href="/dashboard/grades"
                  />
                  <QuickActionCard
                    title="📅 Събития"
                    description="Вижте предстоящите училищни събития"
                    href="/dashboard/events"
                  />
                </>
              )}
              {["admin", "principal", "vice-principal"].includes(user.role) && (
                <>
                  <QuickActionCard
                    title="👥 Управление на потребители"
                    description="Добавяне или редактиране на потребителски акаунти"
                    href="/dashboard/users"
                  />
                  <QuickActionCard
                    title="📦 Заявки за консумативи"
                    description="Преглед на чакащи заявки за консумативи"
                    href="/dashboard/supplies"
                  />
                  <QuickActionCard
                    title="📅 Създай събитие"
                    description="Планирайте ново училищно събитие"
                    href="/dashboard/events"
                  />
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

function QuickActionCard({ title, description, href }: { title: string; description: string; href: string }) {
  return (
    <a href={href} className="block p-4 rounded-lg border border-border hover:bg-muted transition-colors">
      <h3 className="font-medium text-foreground">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </a>
  )
}
