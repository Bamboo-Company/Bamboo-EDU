"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import { AlertTriangle, Link, UserCheck, GraduationCap, Users, Trash2 } from "lucide-react"

const STUDENT_LINKS_KEY = "bamboo_edu_student_links"
const PARENT_LINKS_KEY = "bamboo_edu_parent_links"
const TEACHER_ASSIGNMENTS_KEY = "bamboo_edu_teacher_assignments"

interface StudentLink {
  studentId: string
  userId: string
}

interface ParentLink {
  studentId: string
  parentUserId: string
}

interface TeacherAssignment {
  id: string
  teacherUserId: string
  classId: string
  subjectId: string
}

export default function LinkingPage() {
  const { user } = useAuth()
  const [studentLinks, setStudentLinks] = useState<StudentLink[]>([])
  const [parentLinks, setParentLinks] = useState<ParentLink[]>([])
  const [teacherAssignments, setTeacherAssignments] = useState<TeacherAssignment[]>([])

  const [studentLinkDialogOpen, setStudentLinkDialogOpen] = useState(false)
  const [parentLinkDialogOpen, setParentLinkDialogOpen] = useState(false)
  const [teacherAssignDialogOpen, setTeacherAssignDialogOpen] = useState(false)

  const [newStudentLink, setNewStudentLink] = useState({ studentId: "", userId: "" })
  const [newParentLink, setNewParentLink] = useState({ studentId: "", parentUserId: "" })
  const [newTeacherAssign, setNewTeacherAssign] = useState({ teacherUserId: "", classId: "", subjectId: "" })

  const students = dataStore.getStudents()
  const users = dataStore.getUsers()
  const classes = dataStore.getClasses()
  const subjects = dataStore.getSubjects()

  const studentUsers = users.filter((u) => u.role === "student")
  const parentUsers = users.filter((u) => u.role === "parent")
  const teacherUsers = users.filter((u) => u.role === "teacher")

  useEffect(() => {
    const storedStudentLinks = localStorage.getItem(STUDENT_LINKS_KEY)
    if (storedStudentLinks) {
      setStudentLinks(JSON.parse(storedStudentLinks))
    }
    const storedParentLinks = localStorage.getItem(PARENT_LINKS_KEY)
    if (storedParentLinks) {
      setParentLinks(JSON.parse(storedParentLinks))
    }
    const storedTeacherAssignments = localStorage.getItem(TEACHER_ASSIGNMENTS_KEY)
    if (storedTeacherAssignments) {
      setTeacherAssignments(JSON.parse(storedTeacherAssignments))
    }
  }, [])

  const saveStudentLinks = (links: StudentLink[]) => {
    localStorage.setItem(STUDENT_LINKS_KEY, JSON.stringify(links))
    setStudentLinks(links)
  }

  const saveParentLinks = (links: ParentLink[]) => {
    localStorage.setItem(PARENT_LINKS_KEY, JSON.stringify(links))
    setParentLinks(links)
  }

  const saveTeacherAssignments = (assignments: TeacherAssignment[]) => {
    localStorage.setItem(TEACHER_ASSIGNMENTS_KEY, JSON.stringify(assignments))
    setTeacherAssignments(assignments)
  }

  // Check access - only admin, principal, vice-principal
  if (!user || !["admin", "principal", "vice-principal"].includes(user.role)) {
    return (
      <DashboardLayout>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Достъпът отказан</AlertTitle>
          <AlertDescription>Нямате право да достъпвате тази страница.</AlertDescription>
        </Alert>
      </DashboardLayout>
    )
  }

  const handleAddStudentLink = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newStudentLink.studentId || !newStudentLink.userId) return

    // Check if student is already linked
    const existing = studentLinks.find((l) => l.studentId === newStudentLink.studentId)
    if (existing) {
      // Update existing link
      const updated = studentLinks.map((l) =>
        l.studentId === newStudentLink.studentId ? { ...l, userId: newStudentLink.userId } : l,
      )
      saveStudentLinks(updated)
    } else {
      saveStudentLinks([...studentLinks, newStudentLink])
    }

    setStudentLinkDialogOpen(false)
    setNewStudentLink({ studentId: "", userId: "" })
  }

  const handleRemoveStudentLink = (studentId: string) => {
    saveStudentLinks(studentLinks.filter((l) => l.studentId !== studentId))
  }

  const handleAddParentLink = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newParentLink.studentId || !newParentLink.parentUserId) return

    // Check if this exact link exists
    const existing = parentLinks.find(
      (l) => l.studentId === newParentLink.studentId && l.parentUserId === newParentLink.parentUserId,
    )
    if (!existing) {
      saveParentLinks([...parentLinks, newParentLink])
    }

    setParentLinkDialogOpen(false)
    setNewParentLink({ studentId: "", parentUserId: "" })
  }

  const handleRemoveParentLink = (studentId: string, parentUserId: string) => {
    saveParentLinks(parentLinks.filter((l) => !(l.studentId === studentId && l.parentUserId === parentUserId)))
  }

  const handleAddTeacherAssignment = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newTeacherAssign.teacherUserId || !newTeacherAssign.classId || !newTeacherAssign.subjectId) return

    // Check if assignment already exists
    const existing = teacherAssignments.find(
      (a) =>
        a.teacherUserId === newTeacherAssign.teacherUserId &&
        a.classId === newTeacherAssign.classId &&
        a.subjectId === newTeacherAssign.subjectId,
    )
    if (!existing) {
      const newAssignment: TeacherAssignment = {
        id: Date.now().toString(),
        ...newTeacherAssign,
      }
      saveTeacherAssignments([...teacherAssignments, newAssignment])
    }

    setTeacherAssignDialogOpen(false)
    setNewTeacherAssign({ teacherUserId: "", classId: "", subjectId: "" })
  }

  const handleRemoveTeacherAssignment = (id: string) => {
    saveTeacherAssignments(teacherAssignments.filter((a) => a.id !== id))
  }

  const getStudentName = (id: string) => students.find((s) => s.id === id)?.name || "Неизвестен"
  const getUserName = (id: string) => users.find((u) => u.id === id)?.name || "Неизвестен"
  const getClassName = (id: string) => classes.find((c) => c.id === id)?.name || "Неизвестен"
  const getSubjectName = (id: string) => subjects.find((s) => s.id === id)?.name || "Неизвестен"

  const getLinkedUserId = (studentId: string) => studentLinks.find((l) => l.studentId === studentId)?.userId
  const getParentLinksForStudent = (studentId: string) => parentLinks.filter((l) => l.studentId === studentId)

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Свързване на акаунти</h1>
          <p className="text-muted-foreground mt-1">
            Свържете ученически записи с потребителски акаунти, родителски акаунти и определете учители за класове
          </p>
        </div>

        <Tabs defaultValue="students" className="space-y-4">
          <TabsList className="bg-card border border-border">
            <TabsTrigger
              value="students"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <GraduationCap className="w-4 h-4 mr-2" />
              Ученици
            </TabsTrigger>
            <TabsTrigger
              value="parents"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <Users className="w-4 h-4 mr-2" />
              Родители
            </TabsTrigger>
            <TabsTrigger
              value="teachers"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              <UserCheck className="w-4 h-4 mr-2" />
              Учители
            </TabsTrigger>
          </TabsList>

          {/* Student Linking Tab */}
          <TabsContent value="students">
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-foreground">Свързване на ученици с акаунти</CardTitle>
                  <CardDescription>Свържете ученически записи с техните потребителски акаунти</CardDescription>
                </div>
                <Button onClick={() => setStudentLinkDialogOpen(true)} className="bg-primary hover:bg-primary/90">
                  <Link className="w-4 h-4 mr-2" />
                  Свържи ученик
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead className="text-muted-foreground">Ученик (запис)</TableHead>
                      <TableHead className="text-muted-foreground">Потребителски акаунт</TableHead>
                      <TableHead className="text-muted-foreground">Статус</TableHead>
                      <TableHead className="text-muted-foreground">Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {students.map((student) => {
                      const linkedUserId = getLinkedUserId(student.id)
                      const linkedUser = linkedUserId ? users.find((u) => u.id === linkedUserId) : null
                      return (
                        <TableRow key={student.id} className="border-border">
                          <TableCell className="text-foreground font-medium">{student.name}</TableCell>
                          <TableCell className="text-foreground">
                            {linkedUser ? linkedUser.name : <span className="text-muted-foreground">Не е свързан</span>}
                          </TableCell>
                          <TableCell>
                            {linkedUser ? (
                              <Badge className="bg-green-600">Свързан</Badge>
                            ) : (
                              <Badge variant="secondary">Не е свързан</Badge>
                            )}
                          </TableCell>
                          <TableCell>
                            {linkedUser && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveStudentLink(student.id)}
                                className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                    {students.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          Няма добавени ученици
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Parent Linking Tab */}
          <TabsContent value="parents">
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-foreground">Свързване на родители с ученици</CardTitle>
                  <CardDescription>Свържете родителски акаунти с техните деца</CardDescription>
                </div>
                <Button onClick={() => setParentLinkDialogOpen(true)} className="bg-primary hover:bg-primary/90">
                  <Link className="w-4 h-4 mr-2" />
                  Свържи родител
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead className="text-muted-foreground">Ученик</TableHead>
                      <TableHead className="text-muted-foreground">Родител</TableHead>
                      <TableHead className="text-muted-foreground">Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {parentLinks.map((link, index) => (
                      <TableRow key={index} className="border-border">
                        <TableCell className="text-foreground font-medium">{getStudentName(link.studentId)}</TableCell>
                        <TableCell className="text-foreground">{getUserName(link.parentUserId)}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveParentLink(link.studentId, link.parentUserId)}
                            className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {parentLinks.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center text-muted-foreground py-8">
                          Няма свързани родители
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Teacher Assignment Tab */}
          <TabsContent value="teachers">
            <Card className="bg-card border-border">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-foreground">Определяне на учители за класове</CardTitle>
                  <CardDescription>Задайте кои учители преподават в кои класове и по кои предмети</CardDescription>
                </div>
                <Button onClick={() => setTeacherAssignDialogOpen(true)} className="bg-primary hover:bg-primary/90">
                  <Link className="w-4 h-4 mr-2" />
                  Добави назначение
                </Button>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow className="border-border">
                      <TableHead className="text-muted-foreground">Учител</TableHead>
                      <TableHead className="text-muted-foreground">Клас</TableHead>
                      <TableHead className="text-muted-foreground">Предмет</TableHead>
                      <TableHead className="text-muted-foreground">Действия</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teacherAssignments.map((assignment) => (
                      <TableRow key={assignment.id} className="border-border">
                        <TableCell className="text-foreground font-medium">
                          {getUserName(assignment.teacherUserId)}
                        </TableCell>
                        <TableCell className="text-foreground">{getClassName(assignment.classId)}</TableCell>
                        <TableCell className="text-foreground">{getSubjectName(assignment.subjectId)}</TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveTeacherAssignment(assignment.id)}
                            className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {teacherAssignments.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                          Няма назначени учители
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Student Link Dialog */}
        <Dialog open={studentLinkDialogOpen} onOpenChange={setStudentLinkDialogOpen}>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-foreground">Свързване на ученик с акаунт</DialogTitle>
              <DialogDescription>Изберете ученик и потребителски акаунт за свързване</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddStudentLink} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Ученик (запис)</label>
                <Select
                  value={newStudentLink.studentId}
                  onValueChange={(v) => setNewStudentLink({ ...newStudentLink, studentId: v })}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Изберете ученик" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {students.map((student) => (
                      <SelectItem key={student.id} value={student.id}>
                        {student.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Потребителски акаунт (ученик)</label>
                <Select
                  value={newStudentLink.userId}
                  onValueChange={(v) => setNewStudentLink({ ...newStudentLink, userId: v })}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Изберете акаунт" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {studentUsers.map((u) => (
                      <SelectItem key={u.id} value={u.id}>
                        {u.name} ({u.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setStudentLinkDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90">
                  Свържи
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Parent Link Dialog */}
        <Dialog open={parentLinkDialogOpen} onOpenChange={setParentLinkDialogOpen}>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-foreground">Свързване на родител с ученик</DialogTitle>
              <DialogDescription>Изберете родител и ученик за свързване</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddParentLink} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Ученик</label>
                <Select
                  value={newParentLink.studentId}
                  onValueChange={(v) => setNewParentLink({ ...newParentLink, studentId: v })}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Изберете ученик" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {students.map((student) => (
                      <SelectItem key={student.id} value={student.id}>
                        {student.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Родител</label>
                <Select
                  value={newParentLink.parentUserId}
                  onValueChange={(v) => setNewParentLink({ ...newParentLink, parentUserId: v })}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Изберете родител" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {parentUsers.map((u) => (
                      <SelectItem key={u.id} value={u.id}>
                        {u.name} ({u.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setParentLinkDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90">
                  Свържи
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Teacher Assignment Dialog */}
        <Dialog open={teacherAssignDialogOpen} onOpenChange={setTeacherAssignDialogOpen}>
          <DialogContent className="bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-foreground">Назначаване на учител</DialogTitle>
              <DialogDescription>Изберете учител, клас и предмет</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddTeacherAssignment} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Учител</label>
                <Select
                  value={newTeacherAssign.teacherUserId}
                  onValueChange={(v) => setNewTeacherAssign({ ...newTeacherAssign, teacherUserId: v })}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Изберете учител" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {teacherUsers.map((u) => (
                      <SelectItem key={u.id} value={u.id}>
                        {u.name} ({u.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Клас</label>
                <Select
                  value={newTeacherAssign.classId}
                  onValueChange={(v) => setNewTeacherAssign({ ...newTeacherAssign, classId: v })}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Изберете клас" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {classes.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name} ({c.grade} клас)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Предмет</label>
                <Select
                  value={newTeacherAssign.subjectId}
                  onValueChange={(v) => setNewTeacherAssign({ ...newTeacherAssign, subjectId: v })}
                >
                  <SelectTrigger className="bg-background border-border">
                    <SelectValue placeholder="Изберете предмет" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border-border">
                    {subjects.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setTeacherAssignDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit" className="bg-primary hover:bg-primary/90">
                  Назначи
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
