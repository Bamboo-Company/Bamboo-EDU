"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import type { SchoolClass, Subject, Strike, FeatureSettings, ClassPeriod, TeacherAssignment } from "@/lib/types"
import {
  Download,
  Trash2,
  Power,
  PowerOff,
  AlertTriangle,
  Database,
  Shield,
  Users,
  BookOpen,
  GraduationCap,
  AlertCircle,
  Plus,
  Pencil,
  Settings,
  Link,
  Clock,
  UserCheck,
  Minus,
} from "lucide-react"
import { useRouter } from "next/navigation"

const FEATURE_SETTINGS_KEY = "bamboo_edu_feature_settings"
const SUBJECTS_SETTINGS_KEY = "bamboo_edu_subjects_settings"
const CLASSES_SETTINGS_KEY = "bamboo_edu_classes_settings"
const TEACHER_ASSIGNMENTS_KEY = "bamboo_edu_teacher_assignments"

export default function AdminToolsPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [shutdownDialogOpen, setShutdownDialogOpen] = useState(false)
  const [actionResult, setActionResult] = useState<{ type: "success" | "error"; message: string } | null>(null)

  const [classes, setClasses] = useState<SchoolClass[]>(dataStore.getClasses())
  const [subjects, setSubjects] = useState<Subject[]>(dataStore.getSubjects())
  const [strikes, setStrikes] = useState<Strike[]>(dataStore.getStrikes())
  const [teacherAssignments, setTeacherAssignments] = useState<TeacherAssignment[]>([])

  const [classDialogOpen, setClassDialogOpen] = useState(false)
  const [subjectDialogOpen, setSubjectDialogOpen] = useState(false)
  const [strikeDialogOpen, setStrikeDialogOpen] = useState(false)
  const [linkDialogOpen, setLinkDialogOpen] = useState(false)
  const [scheduleDialogOpen, setScheduleDialogOpen] = useState(false)
  const [classSubjectsDialogOpen, setClassSubjectsDialogOpen] = useState(false)
  const [teacherAssignDialogOpen, setTeacherAssignDialogOpen] = useState(false)
  const [parentLinkDialogOpen, setParentLinkDialogOpen] = useState(false)

  const [editingClass, setEditingClass] = useState<SchoolClass | null>(null)
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null)
  const [selectedClassForSchedule, setSelectedClassForSchedule] = useState<SchoolClass | null>(null)
  const [selectedClassForSubjects, setSelectedClassForSubjects] = useState<SchoolClass | null>(null)

  const [newClassName, setNewClassName] = useState("")
  const [newClassGrade, setNewClassGrade] = useState("")
  const [newSubjectName, setNewSubjectName] = useState("")
  const [newStrike, setNewStrike] = useState({ studentId: "", reason: "" })
  const [linkData, setLinkData] = useState({ studentId: "", userId: "" })
  const [parentLinkData, setParentLinkData] = useState({ studentId: "", parentUserId: "" })

  const [schedulePeriods, setSchedulePeriods] = useState<ClassPeriod[]>([
    { period: 1, startTime: "07:30", duration: 40, endTime: "08:10" },
    { period: 2, startTime: "08:20", duration: 40, endTime: "09:00" },
    { period: 3, startTime: "09:10", duration: 40, endTime: "09:50" },
    { period: 4, startTime: "10:00", duration: 40, endTime: "10:40" },
    { period: 5, startTime: "10:50", duration: 40, endTime: "11:30" },
  ])
  const [scheduleName, setScheduleName] = useState("Смяна 1")

  const [newAssignment, setNewAssignment] = useState({ teacherUserId: "", classId: "", subjectId: "" })

  const [selectedSubjectsForClass, setSelectedSubjectsForClass] = useState<string[]>([])

  const [featureSettings, setFeatureSettings] = useState<FeatureSettings>({
    gradesEnabled: true,
    attendanceEnabled: true,
    behaviorEnabled: true,
    homeworkEnabled: true,
    healthEnabled: true,
    eventsEnabled: true,
    messagesEnabled: true,
    suppliesEnabled: true,
  })

  useEffect(() => {
    // Load feature settings
    const stored = localStorage.getItem(FEATURE_SETTINGS_KEY)
    if (stored) {
      const parsed = JSON.parse(stored)
      setFeatureSettings(parsed)
      dataStore.updateFeatureSettings(parsed)
    }
    // Load subject settings
    const storedSubjects = localStorage.getItem(SUBJECTS_SETTINGS_KEY)
    if (storedSubjects) {
      const parsed = JSON.parse(storedSubjects)
      parsed.forEach((s: Subject) => {
        dataStore.updateSubject(s.id, s)
      })
      setSubjects(dataStore.getSubjects())
    }
    // Load class settings
    const storedClasses = localStorage.getItem(CLASSES_SETTINGS_KEY)
    if (storedClasses) {
      const parsed = JSON.parse(storedClasses)
      parsed.forEach((c: SchoolClass) => {
        dataStore.updateClass(c.id, c)
      })
      setClasses(dataStore.getClasses())
    }
    // Load teacher assignments
    const storedAssignments = localStorage.getItem(TEACHER_ASSIGNMENTS_KEY)
    if (storedAssignments) {
      setTeacherAssignments(JSON.parse(storedAssignments))
    }
  }, [])

  const saveFeatureSettings = (newSettings: FeatureSettings) => {
    setFeatureSettings(newSettings)
    dataStore.updateFeatureSettings(newSettings)
    localStorage.setItem(FEATURE_SETTINGS_KEY, JSON.stringify(newSettings))
  }

  const saveSubjectSettings = (updatedSubjects: Subject[]) => {
    localStorage.setItem(SUBJECTS_SETTINGS_KEY, JSON.stringify(updatedSubjects))
    setSubjects(updatedSubjects)
  }

  const saveClassSettings = (updatedClasses: SchoolClass[]) => {
    localStorage.setItem(CLASSES_SETTINGS_KEY, JSON.stringify(updatedClasses))
    setClasses(updatedClasses)
  }

  const saveTeacherAssignments = (assignments: TeacherAssignment[]) => {
    localStorage.setItem(TEACHER_ASSIGNMENTS_KEY, JSON.stringify(assignments))
    setTeacherAssignments(assignments)
  }

  if (!user || user.role !== "admin") {
    return (
      <DashboardLayout>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Достъпът отказан</AlertTitle>
          <AlertDescription>Нямате право да достъпвате тази страница.</AlertDescription>
        </Alert>
      </DashboardLayout>
    )
  }

  const isShutdown = dataStore.getShutdownStatus()
  const students = dataStore.getStudents()
  const users = dataStore.getUsers()
  const teacherUsers = users.filter((u) => u.role === "teacher")
  const studentUsers = users.filter((u) => u.role === "student")
  const parentUsers = users.filter((u) => u.role === "parent")

  const calculateEndTime = (startTime: string, duration: number): string => {
    const [hours, minutes] = startTime.split(":").map(Number)
    const totalMinutes = hours * 60 + minutes + duration
    const endHours = Math.floor(totalMinutes / 60)
    const endMins = totalMinutes % 60
    return `${endHours.toString().padStart(2, "0")}:${endMins.toString().padStart(2, "0")}`
  }

  const handleExportData = () => {
    const data = dataStore.exportAllData()
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `bamboo-edu-export-${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    setActionResult({ type: "success", message: "Данните са експортирани успешно!" })
  }

  const handleDeleteAllData = () => {
    dataStore.deleteAllData()
    setClasses(dataStore.getClasses())
    setSubjects(dataStore.getSubjects())
    setStrikes(dataStore.getStrikes())
    setTeacherAssignments([])
    localStorage.removeItem(FEATURE_SETTINGS_KEY)
    localStorage.removeItem(SUBJECTS_SETTINGS_KEY)
    localStorage.removeItem(CLASSES_SETTINGS_KEY)
    localStorage.removeItem(TEACHER_ASSIGNMENTS_KEY)
    setDeleteDialogOpen(false)
    setActionResult({ type: "success", message: "Всички данни са изтрити." })
  }

  const handleToggleShutdown = () => {
    if (isShutdown) {
      dataStore.restoreSite()
      setActionResult({ type: "success", message: "Уебсайтът е възстановен." })
    } else {
      dataStore.shutdownSite()
      setActionResult({ type: "success", message: "Уебсайтът е спрян." })
    }
    setShutdownDialogOpen(false)
  }

  const handleAddClass = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newClassName || !newClassGrade) return

    if (editingClass) {
      dataStore.updateClass(editingClass.id, { name: newClassName, grade: newClassGrade })
    } else {
      const newClass: SchoolClass = {
        id: Date.now().toString(),
        name: newClassName,
        grade: newClassGrade,
        createdAt: new Date().toISOString(),
        schedule: [],
        subjects: [],
      }
      dataStore.addClass(newClass)
    }

    const updated = dataStore.getClasses()
    saveClassSettings(updated)
    setClassDialogOpen(false)
    setNewClassName("")
    setNewClassGrade("")
    setEditingClass(null)
  }

  const handleEditClass = (cls: SchoolClass) => {
    setEditingClass(cls)
    setNewClassName(cls.name)
    setNewClassGrade(cls.grade)
    setClassDialogOpen(true)
  }

  const handleDeleteClass = (id: string) => {
    dataStore.deleteClass(id)
    const updated = dataStore.getClasses()
    saveClassSettings(updated)
  }

  const handleOpenScheduleDialog = (cls: SchoolClass) => {
    setSelectedClassForSchedule(cls)
    if (cls.schedule && cls.schedule.length > 0) {
      setSchedulePeriods(cls.schedule)
    } else {
      setSchedulePeriods([
        { period: 1, startTime: "07:30", duration: 40, endTime: "08:10" },
        { period: 2, startTime: "08:20", duration: 40, endTime: "09:00" },
        { period: 3, startTime: "09:10", duration: 40, endTime: "09:50" },
        { period: 4, startTime: "10:00", duration: 40, endTime: "10:40" },
        { period: 5, startTime: "10:50", duration: 40, endTime: "11:30" },
      ])
    }
    setScheduleDialogOpen(true)
  }

  const handleAddPeriod = () => {
    const lastPeriod = schedulePeriods[schedulePeriods.length - 1]
    const newPeriod: ClassPeriod = {
      period: schedulePeriods.length + 1,
      startTime: lastPeriod ? calculateEndTime(lastPeriod.startTime, lastPeriod.duration + 10) : "08:00",
      duration: 40,
      endTime: "",
    }
    newPeriod.endTime = calculateEndTime(newPeriod.startTime, newPeriod.duration)
    setSchedulePeriods([...schedulePeriods, newPeriod])
  }

  const handleRemovePeriod = (index: number) => {
    const updated = schedulePeriods.filter((_, i) => i !== index).map((p, i) => ({ ...p, period: i + 1 }))
    setSchedulePeriods(updated)
  }

  const handleUpdatePeriod = (index: number, field: string, value: string | number) => {
    const updated = [...schedulePeriods]
    updated[index] = { ...updated[index], [field]: value }
    if (field === "startTime" || field === "duration") {
      updated[index].endTime = calculateEndTime(
        field === "startTime" ? (value as string) : updated[index].startTime,
        field === "duration" ? (value as number) : updated[index].duration,
      )
    }
    setSchedulePeriods(updated)
  }

  const handleSaveSchedule = () => {
    if (selectedClassForSchedule) {
      dataStore.updateClass(selectedClassForSchedule.id, { schedule: schedulePeriods })
      const updated = dataStore.getClasses()
      saveClassSettings(updated)
      setScheduleDialogOpen(false)
      setActionResult({ type: "success", message: "Дневният режим е запазен!" })
    }
  }

  const handleOpenClassSubjects = (cls: SchoolClass) => {
    setSelectedClassForSubjects(cls)
    setSelectedSubjectsForClass(cls.subjects || [])
    setClassSubjectsDialogOpen(true)
  }

  const handleToggleSubjectForClass = (subjectId: string) => {
    setSelectedSubjectsForClass((prev) =>
      prev.includes(subjectId) ? prev.filter((id) => id !== subjectId) : [...prev, subjectId],
    )
  }

  const handleSaveClassSubjects = () => {
    if (selectedClassForSubjects) {
      dataStore.updateClass(selectedClassForSubjects.id, { subjects: selectedSubjectsForClass })
      const updated = dataStore.getClasses()
      saveClassSettings(updated)
      setClassSubjectsDialogOpen(false)
      setActionResult({ type: "success", message: "Предметите за класа са запазени!" })
    }
  }

  const handleAddTeacherAssignment = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newAssignment.teacherUserId || !newAssignment.classId || !newAssignment.subjectId) return

    const assignment: TeacherAssignment = {
      id: Date.now().toString(),
      ...newAssignment,
    }
    const updated = [...teacherAssignments, assignment]
    saveTeacherAssignments(updated)
    setTeacherAssignDialogOpen(false)
    setNewAssignment({ teacherUserId: "", classId: "", subjectId: "" })
    setActionResult({ type: "success", message: "Учителят е назначен успешно!" })
  }

  const handleDeleteTeacherAssignment = (id: string) => {
    const updated = teacherAssignments.filter((a) => a.id !== id)
    saveTeacherAssignments(updated)
  }

  const handleLinkParent = (e: React.FormEvent) => {
    e.preventDefault()
    if (!parentLinkData.studentId || !parentLinkData.parentUserId) return

    dataStore.linkParentToStudent(parentLinkData.studentId, parentLinkData.parentUserId)
    setParentLinkDialogOpen(false)
    setParentLinkData({ studentId: "", parentUserId: "" })
    setActionResult({ type: "success", message: "Родителят е свързан с ученика успешно!" })
  }

  const handleAddSubject = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newSubjectName) return

    if (editingSubject) {
      dataStore.updateSubject(editingSubject.id, { name: newSubjectName })
    } else {
      const newSubject: Subject = {
        id: Date.now().toString(),
        name: newSubjectName,
        createdAt: new Date().toISOString(),
        allowCurrentGrades: true,
        allowTermGrades: true,
        allowYearlyGrades: true,
      }
      dataStore.addSubject(newSubject)
    }

    const updated = dataStore.getSubjects()
    saveSubjectSettings(updated)
    setSubjectDialogOpen(false)
    setNewSubjectName("")
    setEditingSubject(null)
  }

  const handleEditSubject = (subj: Subject) => {
    setEditingSubject(subj)
    setNewSubjectName(subj.name)
    setSubjectDialogOpen(true)
  }

  const handleDeleteSubject = (id: string) => {
    dataStore.deleteSubject(id)
    const updated = dataStore.getSubjects()
    saveSubjectSettings(updated)
  }

  const handleToggleSubjectGradeType = (
    subjectId: string,
    gradeType: "allowCurrentGrades" | "allowTermGrades" | "allowYearlyGrades",
  ) => {
    const subject = subjects.find((s) => s.id === subjectId)
    if (subject) {
      const newValue = !subject[gradeType]
      dataStore.updateSubject(subjectId, { [gradeType]: newValue })
      const updated = dataStore.getSubjects()
      saveSubjectSettings(updated)
    }
  }

  const handleAddStrike = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newStrike.studentId || !newStrike.reason) return

    const studentStrikes = dataStore.getStrikesByStudent(newStrike.studentId)
    if (studentStrikes.length >= 5) {
      setActionResult({ type: "error", message: "Ученикът вече има максимален брой наказания (5)." })
      return
    }

    const strike: Strike = {
      id: Date.now().toString(),
      studentId: newStrike.studentId,
      reason: newStrike.reason,
      issuedBy: user.id,
      date: new Date().toISOString(),
    }
    dataStore.addStrike(strike)

    setStrikes(dataStore.getStrikes())
    setStrikeDialogOpen(false)
    setNewStrike({ studentId: "", reason: "" })
  }

  const handleDeleteStrike = (id: string) => {
    dataStore.deleteStrike(id)
    setStrikes(dataStore.getStrikes())
  }

  const handleClearStudentStrikes = (studentId: string) => {
    dataStore.deleteStrikesByStudent(studentId)
    setStrikes(dataStore.getStrikes())
  }

  const handleLinkStudent = (e: React.FormEvent) => {
    e.preventDefault()
    if (!linkData.studentId || !linkData.userId) return

    dataStore.updateStudent(linkData.studentId, { linkedUserId: linkData.userId })
    dataStore.updateUser(linkData.userId, { linkedStudentId: linkData.studentId })

    setActionResult({ type: "success", message: "Ученикът е свързан с акаунта успешно!" })
    setLinkDialogOpen(false)
    setLinkData({ studentId: "", userId: "" })
  }

  const stats = {
    users: dataStore.getUsers().length,
    students: dataStore.getStudents().length,
    teachers: teacherUsers.length,
    attendance: dataStore.getAttendance().length,
    grades: dataStore.getGrades().length,
    messages: dataStore.getMessages().length,
    classes: classes.length,
    subjects: subjects.length,
  }

  const StrikeIndicator = ({ count }: { count: number }) => (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <div key={i} className={`w-4 h-4 rounded-full ${i <= count ? "bg-red-500" : "bg-muted-foreground/20"}`} />
      ))}
      <span className="ml-2 text-sm text-muted-foreground">{count}/5</span>
    </div>
  )

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Админ инструменти</h1>
          <p className="text-muted-foreground">Системна администрация и контроли за управление</p>
        </div>

        {actionResult && (
          <Alert variant={actionResult.type === "success" ? "default" : "destructive"}>
            <AlertTitle>{actionResult.type === "success" ? "Успех" : "Грешка"}</AlertTitle>
            <AlertDescription>{actionResult.message}</AlertDescription>
          </Alert>
        )}

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5" />
              Статус на системата
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className={`w-3 h-3 rounded-full ${isShutdown ? "bg-destructive" : "bg-green-500"} animate-pulse`} />
              <span className="font-medium">{isShutdown ? "Сайтът е ОФЛАЙН" : "Сайтът е ОНЛАЙН"}</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5" />
              Статистика
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4 lg:grid-cols-8">
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.users}</div>
                <div className="text-sm text-muted-foreground">Потребители</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.students}</div>
                <div className="text-sm text-muted-foreground">Ученици</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.teachers}</div>
                <div className="text-sm text-muted-foreground">Учители</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.classes}</div>
                <div className="text-sm text-muted-foreground">Класове</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.subjects}</div>
                <div className="text-sm text-muted-foreground">Предмети</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.attendance}</div>
                <div className="text-sm text-muted-foreground">Присъствия</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.grades}</div>
                <div className="text-sm text-muted-foreground">Оценки</div>
              </div>
              <div className="text-center p-4 bg-muted rounded-lg">
                <div className="text-2xl font-bold">{stats.messages}</div>
                <div className="text-sm text-muted-foreground">Съобщения</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="tools" className="space-y-4">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="tools">Инструменти</TabsTrigger>
            <TabsTrigger value="features">Функции</TabsTrigger>
            <TabsTrigger value="classes">Класове</TabsTrigger>
            <TabsTrigger value="subjects">Предмети</TabsTrigger>
            <TabsTrigger value="teachers">Учители</TabsTrigger>
            <TabsTrigger value="strikes">Наказания</TabsTrigger>
            <TabsTrigger value="linking">Ученици</TabsTrigger>
            <TabsTrigger value="parents">Родители</TabsTrigger>
          </TabsList>

          <TabsContent value="tools">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Download className="w-5 h-5" />
                    Експорт на данни
                  </CardTitle>
                  <CardDescription>Изтеглете всички данни като JSON</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={handleExportData} className="w-full">
                    <Download className="w-4 h-4 mr-2" />
                    Експортирай
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-destructive">
                    <Trash2 className="w-5 h-5" />
                    Изтрий всички данни
                  </CardTitle>
                  <CardDescription>Изтриване на всички данни освен админ акаунтите</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="destructive" onClick={() => setDeleteDialogOpen(true)} className="w-full">
                    <Trash2 className="w-4 h-4 mr-2" />
                    Изтрий всичко
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {isShutdown ? <Power className="w-5 h-5 text-green-500" /> : <PowerOff className="w-5 h-5" />}
                    {isShutdown ? "Възстанови сайта" : "Спри сайта"}
                  </CardTitle>
                  <CardDescription>
                    {isShutdown ? "Върнете уебсайта онлайн" : "Спрете уебсайта за поддръжка"}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    variant={isShutdown ? "default" : "secondary"}
                    onClick={() => setShutdownDialogOpen(true)}
                    className="w-full"
                  >
                    {isShutdown ? (
                      <>
                        <Power className="w-4 h-4 mr-2" />
                        Възстанови
                      </>
                    ) : (
                      <>
                        <PowerOff className="w-4 h-4 mr-2" />
                        Спри сайта
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Управление на потребители
                  </CardTitle>
                  <CardDescription>Добавяне, редактиране или премахване на потребители</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" onClick={() => router.push("/dashboard/users")} className="w-full">
                    <Users className="w-4 h-4 mr-2" />
                    Към потребителите
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="features">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Настройки на функциите
                </CardTitle>
                <CardDescription>Активирайте или деактивирайте функции на системата</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Оценки</p>
                      <p className="text-sm text-muted-foreground">Позволява добавяне на оценки</p>
                    </div>
                    <Switch
                      checked={featureSettings.gradesEnabled}
                      onCheckedChange={(checked) => saveFeatureSettings({ ...featureSettings, gradesEnabled: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Присъствие</p>
                      <p className="text-sm text-muted-foreground">Позволява отбелязване на присъствие</p>
                    </div>
                    <Switch
                      checked={featureSettings.attendanceEnabled}
                      onCheckedChange={(checked) =>
                        saveFeatureSettings({ ...featureSettings, attendanceEnabled: checked })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Поведение</p>
                      <p className="text-sm text-muted-foreground">Позволява добавяне на отзиви</p>
                    </div>
                    <Switch
                      checked={featureSettings.behaviorEnabled}
                      onCheckedChange={(checked) =>
                        saveFeatureSettings({ ...featureSettings, behaviorEnabled: checked })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Домашни</p>
                      <p className="text-sm text-muted-foreground">Позволява задаване на домашни</p>
                    </div>
                    <Switch
                      checked={featureSettings.homeworkEnabled}
                      onCheckedChange={(checked) =>
                        saveFeatureSettings({ ...featureSettings, homeworkEnabled: checked })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Здраве</p>
                      <p className="text-sm text-muted-foreground">Записи от психолог/медицинска сестра</p>
                    </div>
                    <Switch
                      checked={featureSettings.healthEnabled}
                      onCheckedChange={(checked) => saveFeatureSettings({ ...featureSettings, healthEnabled: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Събития</p>
                      <p className="text-sm text-muted-foreground">Позволява създаване на събития</p>
                    </div>
                    <Switch
                      checked={featureSettings.eventsEnabled}
                      onCheckedChange={(checked) => saveFeatureSettings({ ...featureSettings, eventsEnabled: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Съобщения</p>
                      <p className="text-sm text-muted-foreground">Позволява изпращане на съобщения</p>
                    </div>
                    <Switch
                      checked={featureSettings.messagesEnabled}
                      onCheckedChange={(checked) =>
                        saveFeatureSettings({ ...featureSettings, messagesEnabled: checked })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Заявки за материали</p>
                      <p className="text-sm text-muted-foreground">Позволява заявки за материали</p>
                    </div>
                    <Switch
                      checked={featureSettings.suppliesEnabled}
                      onCheckedChange={(checked) =>
                        saveFeatureSettings({ ...featureSettings, suppliesEnabled: checked })
                      }
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="classes">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <GraduationCap className="w-5 h-5" />
                    Управление на класове
                  </CardTitle>
                  <CardDescription>Добавяне на класове с дневен режим и предмети</CardDescription>
                </div>
                <Button
                  onClick={() => {
                    setEditingClass(null)
                    setNewClassName("")
                    setNewClassGrade("")
                    setClassDialogOpen(true)
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Добави клас
                </Button>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Име на класа</TableHead>
                        <TableHead>Клас</TableHead>
                        <TableHead>Дневен режим</TableHead>
                        <TableHead>Предмети</TableHead>
                        <TableHead className="text-right">Действия</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {classes.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                            Няма добавени класове
                          </TableCell>
                        </TableRow>
                      ) : (
                        classes.map((cls) => (
                          <TableRow key={cls.id}>
                            <TableCell className="font-medium">{cls.name}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{cls.grade} клас</Badge>
                            </TableCell>
                            <TableCell>
                              <Button variant="outline" size="sm" onClick={() => handleOpenScheduleDialog(cls)}>
                                <Clock className="w-4 h-4 mr-1" />
                                {cls.schedule && cls.schedule.length > 0 ? `${cls.schedule.length} часа` : "Добави"}
                              </Button>
                            </TableCell>
                            <TableCell>
                              <Button variant="outline" size="sm" onClick={() => handleOpenClassSubjects(cls)}>
                                <BookOpen className="w-4 h-4 mr-1" />
                                {cls.subjects && cls.subjects.length > 0 ? `${cls.subjects.length} предмета` : "Избери"}
                              </Button>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                <Button variant="ghost" size="sm" onClick={() => handleEditClass(cls)}>
                                  <Pencil className="w-4 h-4" />
                                </Button>
                                <Button variant="ghost" size="sm" onClick={() => handleDeleteClass(cls.id)}>
                                  <Trash2 className="w-4 h-4 text-destructive" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subjects">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="w-5 h-5" />
                    Управление на предмети
                  </CardTitle>
                  <CardDescription>Настройка на типове оценки за всеки предмет</CardDescription>
                </div>
                <Button
                  onClick={() => {
                    setEditingSubject(null)
                    setNewSubjectName("")
                    setSubjectDialogOpen(true)
                  }}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Добави предмет
                </Button>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Предмет</TableHead>
                        <TableHead className="text-center">Текущи</TableHead>
                        <TableHead className="text-center">Срочни</TableHead>
                        <TableHead className="text-center">Годишна</TableHead>
                        <TableHead className="text-right">Действия</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {subjects.map((subj) => (
                        <TableRow key={subj.id}>
                          <TableCell className="font-medium">{subj.name}</TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center gap-2">
                              <Switch
                                checked={subj.allowCurrentGrades}
                                onCheckedChange={() => handleToggleSubjectGradeType(subj.id, "allowCurrentGrades")}
                              />
                              <Badge variant={subj.allowCurrentGrades ? "default" : "destructive"}>
                                {subj.allowCurrentGrades ? "ДА" : "НЕ"}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center gap-2">
                              <Switch
                                checked={subj.allowTermGrades}
                                onCheckedChange={() => handleToggleSubjectGradeType(subj.id, "allowTermGrades")}
                              />
                              <Badge variant={subj.allowTermGrades ? "default" : "destructive"}>
                                {subj.allowTermGrades ? "ДА" : "НЕ"}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center justify-center gap-2">
                              <Switch
                                checked={subj.allowYearlyGrades}
                                onCheckedChange={() => handleToggleSubjectGradeType(subj.id, "allowYearlyGrades")}
                              />
                              <Badge variant={subj.allowYearlyGrades ? "default" : "destructive"}>
                                {subj.allowYearlyGrades ? "ДА" : "НЕ"}
                              </Badge>
                            </div>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button variant="ghost" size="sm" onClick={() => handleEditSubject(subj)}>
                                <Pencil className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => handleDeleteSubject(subj.id)}>
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="teachers">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <UserCheck className="w-5 h-5" />
                    Назначаване на учители
                  </CardTitle>
                  <CardDescription>Определете кои учители преподават в кои класове</CardDescription>
                </div>
                <Button onClick={() => setTeacherAssignDialogOpen(true)} disabled={teacherUsers.length === 0}>
                  <Plus className="w-4 h-4 mr-2" />
                  Назначи учител
                </Button>
              </CardHeader>
              <CardContent>
                {teacherUsers.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    Няма добавени учители. Първо добавете потребители с роля "Учител".
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Учител</TableHead>
                          <TableHead>Клас</TableHead>
                          <TableHead>Предмет</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {teacherAssignments.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                              Няма назначени учители
                            </TableCell>
                          </TableRow>
                        ) : (
                          teacherAssignments.map((assignment) => {
                            const teacher = users.find((u) => u.id === assignment.teacherUserId)
                            const cls = classes.find((c) => c.id === assignment.classId)
                            const subj = subjects.find((s) => s.id === assignment.subjectId)
                            return (
                              <TableRow key={assignment.id}>
                                <TableCell className="font-medium">{teacher?.name || "Неизвестен"}</TableCell>
                                <TableCell>
                                  <Badge variant="outline">{cls?.name || "Неизвестен"}</Badge>
                                </TableCell>
                                <TableCell>{subj?.name || "Неизвестен"}</TableCell>
                                <TableCell className="text-right">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleDeleteTeacherAssignment(assignment.id)}
                                  >
                                    <Trash2 className="w-4 h-4 text-destructive" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            )
                          })
                        )}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="strikes">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-red-500" />
                    Управление на наказания
                  </CardTitle>
                  <CardDescription>Добавяне или премахване на наказания (макс. 5 на ученик)</CardDescription>
                </div>
                <Button onClick={() => setStrikeDialogOpen(true)} disabled={students.length === 0}>
                  <Plus className="w-4 h-4 mr-2" />
                  Добави наказание
                </Button>
              </CardHeader>
              <CardContent>
                {students.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    Няма добавени ученици. Първо добавете ученици.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Ученик</TableHead>
                          <TableHead>Клас</TableHead>
                          <TableHead>Наказания</TableHead>
                          <TableHead>Последна причина</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {students.map((student) => {
                          const studentStrikes = strikes.filter((s) => s.studentId === student.id)
                          const lastStrike = studentStrikes[studentStrikes.length - 1]
                          return (
                            <TableRow key={student.id}>
                              <TableCell className="font-medium">{student.name}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{student.class}</Badge>
                              </TableCell>
                              <TableCell>
                                <StrikeIndicator count={studentStrikes.length} />
                              </TableCell>
                              <TableCell className="max-w-xs truncate">{lastStrike?.reason || "-"}</TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  {studentStrikes.length < 5 && (
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      onClick={() => {
                                        setNewStrike({ studentId: student.id, reason: "" })
                                        setStrikeDialogOpen(true)
                                      }}
                                    >
                                      <Plus className="w-4 h-4" />
                                    </Button>
                                  )}
                                  {studentStrikes.length > 0 && (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => handleClearStudentStrikes(student.id)}
                                    >
                                      <Trash2 className="w-4 h-4 text-destructive" />
                                    </Button>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="linking">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Link className="w-5 h-5" />
                    Свързване на ученици с акаунти
                  </CardTitle>
                  <CardDescription>Свържете записи на ученици с потребителски акаунти</CardDescription>
                </div>
                <Button
                  onClick={() => setLinkDialogOpen(true)}
                  disabled={students.length === 0 || studentUsers.length === 0}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Свържи ученик
                </Button>
              </CardHeader>
              <CardContent>
                {students.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    Няма добавени ученици. Първо добавете ученици.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Ученик</TableHead>
                          <TableHead>Клас</TableHead>
                          <TableHead>Свързан акаунт</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {students.map((student) => {
                          const linkedUser = users.find((u) => u.id === student.linkedUserId)
                          return (
                            <TableRow key={student.id}>
                              <TableCell className="font-medium">{student.name}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{student.class}</Badge>
                              </TableCell>
                              <TableCell>
                                {linkedUser ? (
                                  <Badge className="bg-green-500/20 text-green-400 border-green-500">
                                    {linkedUser.email}
                                  </Badge>
                                ) : (
                                  <span className="text-muted-foreground">Не е свързан</span>
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setLinkData({ studentId: student.id, userId: student.linkedUserId || "" })
                                    setLinkDialogOpen(true)
                                  }}
                                >
                                  <Link className="w-4 h-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="parents">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="w-5 h-5" />
                    Свързване на родители с ученици
                  </CardTitle>
                  <CardDescription>Свържете родителски акаунти с ученици</CardDescription>
                </div>
                <Button
                  onClick={() => setParentLinkDialogOpen(true)}
                  disabled={students.length === 0 || parentUsers.length === 0}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Свържи родител
                </Button>
              </CardHeader>
              <CardContent>
                {parentUsers.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    Няма добавени родители. Първо добавете потребители с роля "Родител".
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Ученик</TableHead>
                          <TableHead>Клас</TableHead>
                          <TableHead>Свързан родител</TableHead>
                          <TableHead className="text-right">Действия</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {students.map((student) => {
                          const linkedParent = users.find((u) => u.id === student.linkedParentUserId)
                          return (
                            <TableRow key={student.id}>
                              <TableCell className="font-medium">{student.name}</TableCell>
                              <TableCell>
                                <Badge variant="outline">{student.class}</Badge>
                              </TableCell>
                              <TableCell>
                                {linkedParent ? (
                                  <Badge className="bg-amber-500/20 text-amber-400 border-amber-500">
                                    {linkedParent.name} ({linkedParent.email})
                                  </Badge>
                                ) : (
                                  <span className="text-muted-foreground">Не е свързан</span>
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    setParentLinkData({
                                      studentId: student.id,
                                      parentUserId: student.linkedParentUserId || "",
                                    })
                                    setParentLinkDialogOpen(true)
                                  }}
                                >
                                  <Link className="w-4 h-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add Class Dialog */}
        <Dialog open={classDialogOpen} onOpenChange={setClassDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingClass ? "Редактирай клас" : "Добави нов клас"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddClass} className="space-y-4">
              <div className="space-y-2">
                <Label>Име на класа (напр. 5А, 10Б)</Label>
                <Input
                  value={newClassName}
                  onChange={(e) => setNewClassName(e.target.value)}
                  placeholder="5А"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Клас (1-12)</Label>
                <Select value={newClassGrade} onValueChange={setNewClassGrade}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете клас" />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 12 }, (_, i) => (
                      <SelectItem key={i + 1} value={(i + 1).toString()}>
                        {i + 1} клас
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setClassDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">{editingClass ? "Запази" : "Добави"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Schedule Dialog - New dialog for daily schedule */}
        <Dialog open={scheduleDialogOpen} onOpenChange={setScheduleDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Добавяне на дневен режим - {selectedClassForSchedule?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Име: *</Label>
                <Input value={scheduleName} onChange={(e) => setScheduleName(e.target.value)} placeholder="Смяна 1" />
              </div>

              <div className="space-y-2">
                <Label>Дневен режим:</Label>
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-16">Час</TableHead>
                        <TableHead>Начало</TableHead>
                        <TableHead>Продължителност</TableHead>
                        <TableHead>Край</TableHead>
                        <TableHead className="w-16"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {schedulePeriods.map((period, index) => (
                        <TableRow key={index}>
                          <TableCell>
                            <Input
                              type="number"
                              value={period.period}
                              onChange={(e) => handleUpdatePeriod(index, "period", Number.parseInt(e.target.value))}
                              className="w-16"
                              min={1}
                            />
                          </TableCell>
                          <TableCell>
                            <Input
                              type="time"
                              value={period.startTime}
                              onChange={(e) => handleUpdatePeriod(index, "startTime", e.target.value)}
                            />
                          </TableCell>
                          <TableCell>
                            <Select
                              value={period.duration.toString()}
                              onValueChange={(v) => handleUpdatePeriod(index, "duration", Number.parseInt(v))}
                            >
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="30">30 мин</SelectItem>
                                <SelectItem value="35">35 мин</SelectItem>
                                <SelectItem value="40">40 мин</SelectItem>
                                <SelectItem value="45">45 мин</SelectItem>
                                <SelectItem value="50">50 мин</SelectItem>
                                <SelectItem value="60">60 мин</SelectItem>
                              </SelectContent>
                            </Select>
                          </TableCell>
                          <TableCell>
                            <span className="text-muted-foreground">{period.endTime}</span>
                          </TableCell>
                          <TableCell>
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => handleRemovePeriod(index)}
                              className="text-destructive"
                            >
                              <Minus className="w-4 h-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
                <Button type="button" variant="outline" size="sm" onClick={handleAddPeriod}>
                  <Plus className="w-4 h-4 mr-1" />
                  Добави час
                </Button>
              </div>
            </div>
            <DialogFooter className="flex gap-2">
              <Button variant="outline" onClick={() => setScheduleDialogOpen(false)}>
                Назад
              </Button>
              <Button onClick={handleSaveSchedule}>Запази</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Class Subjects Dialog - Select subjects for class */}
        <Dialog open={classSubjectsDialogOpen} onOpenChange={setClassSubjectsDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Предмети за {selectedClassForSubjects?.name}</DialogTitle>
              <DialogDescription>Изберете кои предмети се преподават в този клас</DialogDescription>
            </DialogHeader>
            <div className="max-h-96 overflow-y-auto space-y-2">
              {subjects.map((subj) => (
                <div
                  key={subj.id}
                  className={`flex items-center gap-2 p-2 rounded cursor-pointer hover:bg-muted ${
                    selectedSubjectsForClass.includes(subj.id) ? "bg-primary/20" : ""
                  }`}
                  onClick={() => handleToggleSubjectForClass(subj.id)}
                >
                  <Checkbox checked={selectedSubjectsForClass.includes(subj.id)} />
                  <span>{subj.name}</span>
                </div>
              ))}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setClassSubjectsDialogOpen(false)}>
                Отказ
              </Button>
              <Button onClick={handleSaveClassSubjects}>Запази ({selectedSubjectsForClass.length} предмета)</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Teacher Assignment Dialog - Assign teacher to class/subject */}
        <Dialog open={teacherAssignDialogOpen} onOpenChange={setTeacherAssignDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Назначи учител</DialogTitle>
              <DialogDescription>Изберете учител, клас и предмет</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleAddTeacherAssignment} className="space-y-4">
              <div className="space-y-2">
                <Label>Учител</Label>
                <Select
                  value={newAssignment.teacherUserId}
                  onValueChange={(v) => setNewAssignment({ ...newAssignment, teacherUserId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете учител" />
                  </SelectTrigger>
                  <SelectContent>
                    {teacherUsers.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Клас</Label>
                <Select
                  value={newAssignment.classId}
                  onValueChange={(v) => setNewAssignment({ ...newAssignment, classId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете клас" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Предмет</Label>
                <Select
                  value={newAssignment.subjectId}
                  onValueChange={(v) => setNewAssignment({ ...newAssignment, subjectId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете предмет" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setTeacherAssignDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">Назначи</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Parent Link Dialog - Link parent to student */}
        <Dialog open={parentLinkDialogOpen} onOpenChange={setParentLinkDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Свържи родител с ученик</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleLinkParent} className="space-y-4">
              <div className="space-y-2">
                <Label>Ученик</Label>
                <Select
                  value={parentLinkData.studentId}
                  onValueChange={(v) => setParentLinkData({ ...parentLinkData, studentId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете ученик" />
                  </SelectTrigger>
                  <SelectContent>
                    {students.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name} ({s.class})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Родителски акаунт</Label>
                <Select
                  value={parentLinkData.parentUserId}
                  onValueChange={(v) => setParentLinkData({ ...parentLinkData, parentUserId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете родител" />
                  </SelectTrigger>
                  <SelectContent>
                    {parentUsers.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.name} ({p.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setParentLinkDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">Свържи</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Add Subject Dialog */}
        <Dialog open={subjectDialogOpen} onOpenChange={setSubjectDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingSubject ? "Редактирай предмет" : "Добави нов предмет"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddSubject} className="space-y-4">
              <div className="space-y-2">
                <Label>Име на предмета</Label>
                <Input
                  value={newSubjectName}
                  onChange={(e) => setNewSubjectName(e.target.value)}
                  placeholder="Математика"
                  required
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setSubjectDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">{editingSubject ? "Запази" : "Добави"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Strike Dialog */}
        <Dialog open={strikeDialogOpen} onOpenChange={setStrikeDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Добави наказание</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleAddStrike} className="space-y-4">
              <div className="space-y-2">
                <Label>Ученик</Label>
                <Select value={newStrike.studentId} onValueChange={(v) => setNewStrike({ ...newStrike, studentId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете ученик" />
                  </SelectTrigger>
                  <SelectContent>
                    {students
                      .filter((s) => dataStore.getStrikesByStudent(s.id).length < 5)
                      .map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.name} ({s.class})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Причина</Label>
                <Textarea
                  value={newStrike.reason}
                  onChange={(e) => setNewStrike({ ...newStrike, reason: e.target.value })}
                  placeholder="Опишете причината за наказанието..."
                  required
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setStrikeDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">Добави наказание</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Link Student Dialog */}
        <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Свържи ученик с акаунт</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleLinkStudent} className="space-y-4">
              <div className="space-y-2">
                <Label>Ученик</Label>
                <Select value={linkData.studentId} onValueChange={(v) => setLinkData({ ...linkData, studentId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете ученик" />
                  </SelectTrigger>
                  <SelectContent>
                    {students.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.name} ({s.class})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Потребителски акаунт</Label>
                <Select value={linkData.userId} onValueChange={(v) => setLinkData({ ...linkData, userId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Изберете акаунт" />
                  </SelectTrigger>
                  <SelectContent>
                    {studentUsers.map((u) => (
                      <SelectItem key={u.id} value={u.id}>
                        {u.name} ({u.email})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setLinkDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">Свържи</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete All Confirmation */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="text-destructive">Изтриване на всички данни</DialogTitle>
              <DialogDescription>
                Сигурни ли сте? Това ще изтрие ВСИЧКИ данни освен админ акаунтите. Това действие не може да бъде
                отменено.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                Отказ
              </Button>
              <Button variant="destructive" onClick={handleDeleteAllData}>
                Изтрий всичко
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Shutdown Confirmation */}
        <Dialog open={shutdownDialogOpen} onOpenChange={setShutdownDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{isShutdown ? "Възстановяване на сайта" : "Спиране на сайта"}</DialogTitle>
              <DialogDescription>
                {isShutdown
                  ? "Сайтът ще стане достъпен за всички потребители."
                  : "Сайтът ще бъде недостъпен за всички потребители освен администраторите."}
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShutdownDialogOpen(false)}>
                Отказ
              </Button>
              <Button onClick={handleToggleShutdown}>{isShutdown ? "Възстанови" : "Спри сайта"}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
