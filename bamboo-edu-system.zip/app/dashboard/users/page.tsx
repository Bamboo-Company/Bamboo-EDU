"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { dataStore } from "@/lib/data-store"
import type { User, UserRole } from "@/lib/types"
import { Plus, Edit, Trash2, AlertTriangle, Search } from "lucide-react"

const ROLES: UserRole[] = [
  "admin",
  "principal",
  "vice-principal",
  "teacher",
  "psychologist",
  "nurse",
  "student",
  "parent",
]

const ROLE_LABELS: Record<UserRole, string> = {
  admin: "Администратор",
  principal: "Директор",
  "vice-principal": "Зам.-директор",
  teacher: "Учител",
  psychologist: "Психолог",
  nurse: "Мед. сестра",
  student: "Ученик",
  parent: "Родител",
}

const getRoleBadgeColor = (role: UserRole) => {
  const colors: Record<UserRole, string> = {
    admin: "bg-red-500/20 text-red-400 border-red-500",
    principal: "bg-purple-500/20 text-purple-400 border-purple-500",
    "vice-principal": "bg-indigo-500/20 text-indigo-400 border-indigo-500",
    teacher: "bg-blue-500/20 text-blue-400 border-blue-500",
    psychologist: "bg-teal-500/20 text-teal-400 border-teal-500",
    nurse: "bg-pink-500/20 text-pink-400 border-pink-500",
    student: "bg-green-500/20 text-green-400 border-green-500",
    parent: "bg-amber-500/20 text-amber-400 border-amber-500",
  }
  return colors[role]
}

export default function UsersPage() {
  const { user } = useAuth()
  const [users, setUsers] = useState<User[]>(dataStore.getUsers())
  const [searchTerm, setSearchTerm] = useState("")
  const [roleFilter, setRoleFilter] = useState<UserRole | "all">("all")
  const [dialogOpen, setDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [userToDelete, setUserToDelete] = useState<User | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "student" as UserRole,
  })

  if (!user || !["admin", "principal"].includes(user.role)) {
    return (
      <DashboardLayout>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Достъпът отказан</AlertTitle>
          <AlertDescription>Нямате право да достъпвате тази страница.</AlertDescription>
        </Alert>
      </DashboardLayout>
    )
  }

  const isAdmin = user.role === "admin"

  const filteredUsers = users.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesRole = roleFilter === "all" || u.role === roleFilter
    return matchesSearch && matchesRole
  })

  const handleOpenDialog = (userToEdit?: User) => {
    if (userToEdit) {
      setEditingUser(userToEdit)
      setFormData({
        name: userToEdit.name,
        email: userToEdit.email,
        password: userToEdit.password,
        role: userToEdit.role,
      })
    } else {
      setEditingUser(null)
      setFormData({ name: "", email: "", password: "", role: "student" })
    }
    setDialogOpen(true)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingUser) {
      dataStore.updateUser(editingUser.id, formData)
    } else {
      const newUser: User = {
        id: Date.now().toString(),
        ...formData,
        createdAt: new Date(),
      }
      dataStore.addUser(newUser)
    }

    setUsers(dataStore.getUsers())
    setDialogOpen(false)
  }

  const handleDelete = () => {
    if (userToDelete) {
      dataStore.deleteUser(userToDelete.id)
      setUsers(dataStore.getUsers())
    }
    setDeleteDialogOpen(false)
    setUserToDelete(null)
  }

  const confirmDelete = (userToRemove: User) => {
    setUserToDelete(userToRemove)
    setDeleteDialogOpen(true)
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Управление на потребители</h1>
            <p className="text-muted-foreground">Управлявайте всички потребителски акаунти в системата</p>
          </div>
          <Button onClick={() => handleOpenDialog()}>
            <Plus className="w-4 h-4 mr-2" />
            Добави потребител
          </Button>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Търсене по име или имейл..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={roleFilter} onValueChange={(v) => setRoleFilter(v as UserRole | "all")}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Филтрирай по роля" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Всички роли</SelectItem>
                  {ROLES.map((role) => (
                    <SelectItem key={role} value={role}>
                      {ROLE_LABELS[role]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Users Table */}
        <Card>
          <CardHeader>
            <CardTitle>Потребители ({filteredUsers.length})</CardTitle>
            <CardDescription>Списък на всички потребители в системата</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Име</TableHead>
                    <TableHead>Имейл</TableHead>
                    <TableHead>Роля</TableHead>
                    {isAdmin && <TableHead>Парола</TableHead>}
                    <TableHead className="text-right">Действия</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">{u.name}</TableCell>
                      <TableCell>{u.email}</TableCell>
                      <TableCell>
                        <Badge className={getRoleBadgeColor(u.role)}>{ROLE_LABELS[u.role]}</Badge>
                      </TableCell>
                      {isAdmin && (
                        <TableCell>
                          <code className="text-xs bg-muted px-2 py-1 rounded">{u.password}</code>
                        </TableCell>
                      )}
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(u)}>
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => confirmDelete(u)}
                            disabled={u.id === user.id || u.email === "didopetdim@gmail.com"}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Add/Edit User Dialog */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingUser ? "Редактирай потребител" : "Добави нов потребител"}</DialogTitle>
              <DialogDescription>
                {editingUser
                  ? "Актуализирайте информацията за потребителя"
                  : "Попълнете данните за създаване на нов потребител"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Пълно име</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Имейл</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Парола</Label>
                <Input
                  id="password"
                  type="text"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="role">Роля</Label>
                <Select value={formData.role} onValueChange={(v) => setFormData({ ...formData, role: v as UserRole })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {ROLES.map((role) => (
                      <SelectItem key={role} value={role}>
                        {ROLE_LABELS[role]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit">{editingUser ? "Запази промените" : "Създай потребител"}</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Изтриване на потребител?</DialogTitle>
              <DialogDescription>
                Сигурни ли сте, че искате да изтриете {userToDelete?.name}? Това действие не може да бъде отменено.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                Отказ
              </Button>
              <Button variant="destructive" onClick={handleDelete}>
                Изтрий
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
