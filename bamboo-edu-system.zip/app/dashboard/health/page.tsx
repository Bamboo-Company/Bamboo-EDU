"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/lib/auth-context"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { dataStore } from "@/lib/data-store"
import type { StudentLog } from "@/lib/types"
import { Plus, Heart, Brain, Lock, AlertTriangle, Eye, Trash2 } from "lucide-react"

const HEALTH_LOGS_STORAGE_KEY = "bamboo_edu_health_logs"

export default function HealthPage() {
  const { user } = useAuth()
  const [logs, setLogs] = useState<StudentLog[]>([])
  const [dialogOpen, setDialogOpen] = useState(false)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)
  const [selectedLog, setSelectedLog] = useState<StudentLog | null>(null)
  const [activeTab, setActiveTab] = useState<"all" | "psychologist" | "nurse">("all")
  const [selectedStudents, setSelectedStudents] = useState<string[]>([])

  const [formData, setFormData] = useState({
    notes: "",
    confidential: false,
  })

  useEffect(() => {
    const stored = localStorage.getItem(HEALTH_LOGS_STORAGE_KEY)
    if (stored) {
      setLogs(JSON.parse(stored))
    } else {
      setLogs(dataStore.getStudentLogs())
    }
  }, [])

  const saveLogs = (updatedLogs: StudentLog[]) => {
    localStorage.setItem(HEALTH_LOGS_STORAGE_KEY, JSON.stringify(updatedLogs))
    setLogs(updatedLogs)
  }

  if (!user) return null

  const isPsychologist = user.role === "psychologist"
  const isNurse = user.role === "nurse"
  const isAdmin = user.role === "admin"
  const isPrincipal = user.role === "principal"
  const canCreate = isPsychologist || isNurse
  const canViewAll = isAdmin || isPrincipal

  const students = dataStore.getStudents()

  // Filter logs based on role and tab
  let visibleLogs = logs
  if (!canViewAll) {
    visibleLogs = logs.filter((l) => l.staffId === user.id)
  }
  if (activeTab !== "all") {
    visibleLogs = visibleLogs.filter((l) => l.staffRole === activeTab)
  }

  const toggleStudent = (studentId: string) => {
    setSelectedStudents((prev) =>
      prev.includes(studentId) ? prev.filter((id) => id !== studentId) : [...prev, studentId],
    )
  }

  const selectAllStudents = () => {
    if (selectedStudents.length === students.length) {
      setSelectedStudents([])
    } else {
      setSelectedStudents(students.map((s) => s.id))
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (selectedStudents.length === 0) return

    const newLogs: StudentLog[] = selectedStudents.map((studentId) => {
      const student = students.find((s) => s.id === studentId)
      return {
        id: `${Date.now()}-${studentId}`,
        studentId,
        staffId: user.id,
        staffRole: isPsychologist ? "psychologist" : "nurse",
        date: new Date().toISOString(),
        school: student?.school || "",
        city: student?.city || "",
        country: student?.country || "",
        notes: formData.notes,
        confidential: formData.confidential,
      }
    })

    const updatedLogs = [...logs, ...newLogs]
    saveLogs(updatedLogs)

    // Also save to dataStore
    newLogs.forEach((log) => dataStore.addStudentLog(log))

    setDialogOpen(false)
    setFormData({ notes: "", confidential: false })
    setSelectedStudents([])
  }

  const handleDeleteLog = (logId: string) => {
    const updatedLogs = logs.filter((l) => l.id !== logId)
    saveLogs(updatedLogs)
  }

  const viewLog = (log: StudentLog) => {
    setSelectedLog(log)
    setViewDialogOpen(true)
  }

  const getRoleBadge = (role: StudentLog["staffRole"]) => {
    if (role === "psychologist") {
      return (
        <Badge className="bg-purple-500/20 text-purple-400 border-purple-500">
          <Brain className="w-3 h-3 mr-1" />
          Психолог
        </Badge>
      )
    }
    return (
      <Badge className="bg-pink-500/20 text-pink-400 border-pink-500">
        <Heart className="w-3 h-3 mr-1" />
        Медицинска сестра
      </Badge>
    )
  }

  if (!canCreate && !canViewAll) {
    return (
      <DashboardLayout>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertTitle>Достъпът е отказан</AlertTitle>
          <AlertDescription>Нямате права за достъп до здравните записи.</AlertDescription>
        </Alert>
      </DashboardLayout>
    )
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">🏥 Здраве и благополучие</h1>
            <p className="text-muted-foreground">
              {isPsychologist
                ? "Психологически записи"
                : isNurse
                  ? "Здравни записи"
                  : "Преглед на всички здравни записи"}
            </p>
          </div>
          {canCreate && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Нов запис
            </Button>
          )}
        </div>

        {/* Stats */}
        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">🧠 Психологически записи</p>
                  <p className="text-2xl font-bold">{logs.filter((l) => l.staffRole === "psychologist").length}</p>
                </div>
                <Brain className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">💊 Медицински записи</p>
                  <p className="text-2xl font-bold">{logs.filter((l) => l.staffRole === "nurse").length}</p>
                </div>
                <Heart className="w-8 h-8 text-pink-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Logs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)}>
          <TabsList>
            <TabsTrigger value="all">Всички записи</TabsTrigger>
            <TabsTrigger value="psychologist">🧠 Психолог</TabsTrigger>
            <TabsTrigger value="nurse">💊 Мед. сестра</TabsTrigger>
          </TabsList>

          <TabsContent value={activeTab} className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Записи на ученици ({visibleLogs.length})</CardTitle>
                <CardDescription>Здравни и психологически записи за учениците</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Дата</TableHead>
                        <TableHead>Ученик</TableHead>
                        <TableHead>Училище</TableHead>
                        <TableHead>Град</TableHead>
                        <TableHead>Държава</TableHead>
                        <TableHead>Тип</TableHead>
                        <TableHead>Поверителен</TableHead>
                        <TableHead className="text-right">Действия</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {visibleLogs.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                            Няма намерени записи
                          </TableCell>
                        </TableRow>
                      ) : (
                        visibleLogs.map((log) => {
                          const student = students.find((s) => s.id === log.studentId)
                          return (
                            <TableRow key={log.id}>
                              <TableCell>{new Date(log.date).toLocaleDateString("bg-BG")}</TableCell>
                              <TableCell className="font-medium">{student?.name || "Неизвестен"}</TableCell>
                              <TableCell>{log.school}</TableCell>
                              <TableCell>{log.city}</TableCell>
                              <TableCell>{log.country}</TableCell>
                              <TableCell>{getRoleBadge(log.staffRole)}</TableCell>
                              <TableCell>
                                {log.confidential ? (
                                  <Badge variant="destructive">
                                    <Lock className="w-3 h-3 mr-1" />
                                    Да
                                  </Badge>
                                ) : (
                                  <Badge variant="secondary">Не</Badge>
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-1">
                                  <Button variant="ghost" size="icon" onClick={() => viewLog(log)}>
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                  {canCreate && (
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => handleDeleteLog(log.id)}
                                      className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          )
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* New Log Dialog with Multi-Select */}
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Нов {isPsychologist ? "психологически" : "здравен"} запис</DialogTitle>
              <DialogDescription>Създайте нов запис за един или повече ученици</DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Ученици ({selectedStudents.length} избрани)</Label>
                  <Button type="button" variant="outline" size="sm" onClick={selectAllStudents}>
                    {selectedStudents.length === students.length ? "Премахни всички" : "Избери всички"}
                  </Button>
                </div>
                <div className="border rounded-lg max-h-48 overflow-y-auto p-2 space-y-1">
                  {students.length === 0 ? (
                    <p className="text-muted-foreground text-sm p-2">Няма добавени ученици</p>
                  ) : (
                    students.map((student) => (
                      <div
                        key={student.id}
                        className={`flex items-center gap-2 p-2 rounded cursor-pointer hover:bg-muted ${
                          selectedStudents.includes(student.id) ? "bg-primary/20" : ""
                        }`}
                        onClick={() => toggleStudent(student.id)}
                      >
                        <Checkbox
                          checked={selectedStudents.includes(student.id)}
                          onCheckedChange={() => toggleStudent(student.id)}
                        />
                        <span className="flex-1">
                          {student.name} ({student.class}) - {student.school}, {student.city}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Бележки</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder={
                    isPsychologist
                      ? "Бележки от сесията, наблюдения, препоръки..."
                      : "Здравни бележки, симптоми, лечение..."
                  }
                  rows={5}
                  required
                />
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="confidential"
                  checked={formData.confidential}
                  onCheckedChange={(checked) => setFormData({ ...formData, confidential: checked as boolean })}
                />
                <label htmlFor="confidential" className="text-sm cursor-pointer">
                  Маркирай като поверителен (ограничен достъп)
                </label>
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                  Отказ
                </Button>
                <Button type="submit" disabled={selectedStudents.length === 0}>
                  Създай запис ({selectedStudents.length})
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* View Log Dialog */}
        <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                {selectedLog?.staffRole === "psychologist" ? (
                  <Brain className="w-5 h-5 text-purple-500" />
                ) : (
                  <Heart className="w-5 h-5 text-pink-500" />
                )}
                {selectedLog?.staffRole === "psychologist" ? "Психологически" : "Здравен"} запис
              </DialogTitle>
              <DialogDescription>
                {selectedLog && new Date(selectedLog.date).toLocaleDateString("bg-BG")}
              </DialogDescription>
            </DialogHeader>
            {selectedLog && (
              <div className="space-y-4">
                <div className="grid gap-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Ученик:</span>
                    <span className="font-medium">
                      {students.find((s) => s.id === selectedLog.studentId)?.name || "Неизвестен"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Училище:</span>
                    <span>{selectedLog.school}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Местоположение:</span>
                    <span>
                      {selectedLog.city}, {selectedLog.country}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Поверителен:</span>
                    <span>{selectedLog.confidential ? "Да" : "Не"}</span>
                  </div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Бележки</Label>
                  <div className="mt-1 p-3 bg-muted rounded-lg text-sm whitespace-pre-wrap">{selectedLog.notes}</div>
                </div>
              </div>
            )}
            <DialogFooter>
              <Button onClick={() => setViewDialogOpen(false)}>Затвори</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardLayout>
  )
}
