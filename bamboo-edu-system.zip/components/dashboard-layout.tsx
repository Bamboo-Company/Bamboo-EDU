"use client"

import { type ReactNode, useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Leaf,
  Home,
  Users,
  Calendar,
  ClipboardList,
  BookOpen,
  Bell,
  MessageSquare,
  LogOut,
  Menu,
  X,
  GraduationCap,
  Heart,
  ShoppingBag,
  BarChart3,
  Shield,
  FileText,
  UserCheck,
  LinkIcon,
  Building2,
  CalendarDays,
  Receipt,
} from "lucide-react"
import { dataStore } from "@/lib/data-store"
import { cn } from "@/lib/utils"

interface NavItem {
  label: string
  href: string
  icon: ReactNode
  roles: string[]
}

const navItems: NavItem[] = [
  {
    label: "Табло",
    href: "/dashboard",
    icon: <Home className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "psychologist", "nurse", "student", "parent"],
  },
  {
    label: "Училища",
    href: "/dashboard/schools",
    icon: <Building2 className="w-5 h-5" />,
    roles: ["admin"],
  },
  {
    label: "Потребители",
    href: "/dashboard/users",
    icon: <Users className="w-5 h-5" />,
    roles: ["admin", "principal"],
  },
  {
    label: "Ученици",
    href: "/dashboard/students",
    icon: <GraduationCap className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "psychologist", "nurse"],
  },
  {
    label: "Свързване",
    href: "/dashboard/linking",
    icon: <LinkIcon className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal"],
  },
  {
    label: "Програма",
    href: "/dashboard/schedule",
    icon: <CalendarDays className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "student", "parent"],
  },
  {
    label: "Присъствие",
    href: "/dashboard/attendance",
    icon: <UserCheck className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher"],
  },
  {
    label: "Поведение",
    href: "/dashboard/behavior",
    icon: <ClipboardList className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "student", "parent"],
  },
  {
    label: "Домашни",
    href: "/dashboard/homework",
    icon: <BookOpen className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "student", "parent"],
  },
  {
    label: "Оценки",
    href: "/dashboard/grades",
    icon: <BarChart3 className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "student", "parent"],
  },
  {
    label: "Дневник на учителя",
    href: "/dashboard/teacher-logs",
    icon: <FileText className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher"],
  },
  {
    label: "Здраве и благополучие",
    href: "/dashboard/health",
    icon: <Heart className="w-5 h-5" />,
    roles: ["admin", "principal", "psychologist", "nurse"],
  },
  {
    label: "Такси и задължения",
    href: "/dashboard/taxes",
    icon: <Receipt className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "student", "parent"],
  },
  {
    label: "Заявки за консумативи",
    href: "/dashboard/supplies",
    icon: <ShoppingBag className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher"],
  },
  {
    label: "Събития",
    href: "/dashboard/events",
    icon: <Calendar className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "psychologist", "nurse", "student", "parent"],
  },
  {
    label: "Съобщения",
    href: "/dashboard/messages",
    icon: <MessageSquare className="w-5 h-5" />,
    roles: ["admin", "principal", "vice-principal", "teacher", "psychologist", "nurse", "student", "parent"],
  },
  {
    label: "Админ инструменти",
    href: "/dashboard/admin",
    icon: <Shield className="w-5 h-5" />,
    roles: ["admin", "principal"],
  },
]

const ROLE_TRANSLATIONS: Record<string, string> = {
  admin: "Администратор",
  principal: "Директор",
  "vice-principal": "Заместник-директор",
  teacher: "Учител",
  psychologist: "Психолог",
  nurse: "Медицинска сестра",
  student: "Ученик",
  parent: "Родител",
}

export function DashboardLayout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth()
  const router = useRouter()
  const pathname = usePathname()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [featureSettings, setFeatureSettings] = useState(dataStore.getFeatureSettings())

  useEffect(() => {
    const loadFeatures = () => {
      setFeatureSettings(dataStore.getFeatureSettings())
    }

    loadFeatures()

    const interval = setInterval(loadFeatures, 1000)
    return () => clearInterval(interval)
  }, [])

  if (!user) {
    router.push("/")
    return null
  }

  const filteredNavItems = navItems.filter((item) => {
    if (!item.roles.includes(user.role)) return false

    if (item.href === "/dashboard/grades" && !featureSettings.gradesEnabled) return false
    if (item.href === "/dashboard/attendance" && !featureSettings.attendanceEnabled) return false
    if (item.href === "/dashboard/behavior" && !featureSettings.behaviorEnabled) return false
    if (item.href === "/dashboard/homework" && !featureSettings.homeworkEnabled) return false
    if (item.href === "/dashboard/health" && !featureSettings.healthEnabled) return false
    if (item.href === "/dashboard/events" && !featureSettings.eventsEnabled) return false
    if (item.href === "/dashboard/messages" && !featureSettings.messagesEnabled) return false
    if (item.href === "/dashboard/supplies" && !featureSettings.suppliesEnabled) return false

    return true
  })

  const unreadNotifications = dataStore.getUnreadNotifications(user.id).length
  const unreadMessages = dataStore.getInbox(user.id).filter((m) => !m.read).length

  const handleLogout = () => {
    logout()
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile header */}
      <header className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-card border-b border-border z-50 flex items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(!sidebarOpen)}>
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
          <div className="flex items-center gap-2">
            <Leaf className="w-6 h-6 text-primary" />
            <span className="font-bold text-primary">🎋 Bamboo EDU</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/dashboard/messages">
            <Button variant="ghost" size="icon" className="relative">
              <MessageSquare className="w-5 h-5" />
              {unreadMessages > 0 && (
                <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs">
                  {unreadMessages}
                </Badge>
              )}
            </Button>
          </Link>
          <Link href="/dashboard/notifications">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5" />
              {unreadNotifications > 0 && (
                <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs">
                  {unreadNotifications}
                </Badge>
              )}
            </Button>
          </Link>
        </div>
      </header>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-0 left-0 h-full w-64 bg-card border-r border-border z-40 transition-transform duration-300",
          "lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="h-16 flex items-center gap-2 px-4 border-b border-border">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
              <Leaf className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-bold text-primary">🎋 Bamboo EDU</h1>
              <p className="text-xs text-muted-foreground">{ROLE_TRANSLATIONS[user.role] || user.role}</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-4">
            <ul className="space-y-1">
              {filteredNavItems.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    onClick={() => setSidebarOpen(false)}
                    className={cn(
                      "flex items-center gap-3 px-3 py-2 rounded-lg transition-colors",
                      pathname === item.href
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground",
                    )}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* User section */}
          <div className="p-4 border-t border-border">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="w-full justify-start gap-3 h-auto py-2">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium truncate">{user.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{user.email}</p>
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>Моят акаунт</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                  <LogOut className="w-4 h-4 mr-2" />
                  Изход
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main content */}
      <main className="lg:ml-64 pt-16 lg:pt-0 min-h-screen">
        {/* Desktop header */}
        <header className="hidden lg:flex h-16 items-center justify-between px-6 border-b border-border bg-card">
          <h2 className="text-lg font-semibold">
            {filteredNavItems.find((item) => item.href === pathname)?.label || "Табло"}
          </h2>
          <div className="flex items-center gap-2">
            <Link href="/dashboard/messages">
              <Button variant="ghost" size="icon" className="relative">
                <MessageSquare className="w-5 h-5" />
                {unreadMessages > 0 && (
                  <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs">
                    {unreadMessages}
                  </Badge>
                )}
              </Button>
            </Link>
            <Link href="/dashboard/notifications">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="w-5 h-5" />
                {unreadNotifications > 0 && (
                  <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs">
                    {unreadNotifications}
                  </Badge>
                )}
              </Button>
            </Link>
          </div>
        </header>

        {/* Page content */}
        <div className="p-6">{children}</div>
      </main>
    </div>
  )
}
