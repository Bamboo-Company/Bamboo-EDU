export type UserRole =
  | "admin"
  | "principal"
  | "vice-principal"
  | "teacher"
  | "psychologist"
  | "nurse"
  | "student"
  | "parent"

export interface School {
  id: string
  fullName: string // Пълно (официално) име
  shortName: string // Кратко име
  type: string // Вид (Средно училище, Основно, etc.)
  ownership: string // Тип (Държавно, Общинско, Частно)
  isRegionalCenter: boolean // Средищно училище
  isProtected: boolean // Защитено училище
  isInnovative: boolean // Иновативно училище
  isStateFunded: boolean // На държавно финансиране
  isNationalImportance: boolean // От национално значение
  providesVocationalTraining: boolean // Осигурява професионална подготовка
  fundedBy: string // Финансира се от
  hasDelegatedBudget: boolean // На делегиран бюджет
  approvedBudget: string // Утвърден бюджет за текущата календарна година
  createdByInternationalTreaty: boolean // Създадено по силата на международен договор
  city: string // Населено място
  district: string // Район
  address: string // Адрес
  postalCode: string // Пощенски код
  phone1: string // Телефон
  phone2: string // Телефон №2
  website: string // Уеб сайт
  email1: string // Ел. поща
  email2: string // Ел. поща №2
  isFullEDnevnik: boolean // 100% e-dневник
  createdAt: string
}

export interface SchoolUserRole {
  id: string
  userId: string
  schoolId: string
  role: UserRole
}

export interface User {
  id: string
  email: string
  password: string
  name: string
  role: UserRole // Primary role (admin is global)
  avatar?: string
  createdAt: Date
  linkedStudentId?: string
  linkedParentId?: string
  schoolRoles?: SchoolUserRole[] // Multiple school-role assignments
}

export interface Student {
  id: string
  name: string
  grade: string
  class: string
  school: string
  schoolId?: string // Added school ID reference
  city: string
  country: string
  parentId: string
  dateOfBirth: string
  enrollmentDate: string
  avatar?: string
  linkedUserId?: string
  linkedParentUserId?: string
}

export interface Attendance {
  id: string
  studentId: string
  date: string
  status: "present" | "absent" | "late" | "excused"
  recordedBy: string
}

export type BehaviorType = "positive" | "negative"

export interface BehaviorBadge {
  id: string
  name: string
  icon: string // Icon name or emoji
  type: BehaviorType
  color: string
  description: string
}

export const POSITIVE_BADGES: BehaviorBadge[] = [
  {
    id: "general_praise",
    name: "Обща похвала",
    icon: "thumbsup",
    type: "positive",
    color: "#22c55e",
    description: "Обща похвала за ученика.",
  },
  {
    id: "active",
    name: "Активно участие",
    icon: "hand",
    type: "positive",
    color: "#22c55e",
    description: "Ученикът участва активно в занятията.",
  },
  {
    id: "excellent_performance",
    name: "Отлично представяне",
    icon: "crown",
    type: "positive",
    color: "#eab308",
    description: "Отлично представяне в час.",
  },
  {
    id: "completed_task",
    name: "Изпълнена задача",
    icon: "check",
    type: "positive",
    color: "#22c55e",
    description: "Успешно изпълнена задача.",
  },
  {
    id: "curiosity",
    name: "Любознание",
    icon: "lightbulb",
    type: "positive",
    color: "#3b82f6",
    description: "Проявява любознателност.",
  },
  {
    id: "diligence",
    name: "Старание",
    icon: "heart",
    type: "positive",
    color: "#22c55e",
    description: "Показва старание в учението.",
  },
  {
    id: "progress",
    name: "Прогрес",
    icon: "trendingup",
    type: "positive",
    color: "#22c55e",
    description: "Показва напредък.",
  },
  {
    id: "communication",
    name: "Комуникативност",
    icon: "megaphone",
    type: "positive",
    color: "#3b82f6",
    description: "Добри комуникативни умения.",
  },
  {
    id: "alertmind",
    name: "Бодър ум",
    icon: "brain",
    type: "positive",
    color: "#ec4899",
    description: "Бърз и бодър ум.",
  },
  {
    id: "concentration",
    name: "Концентрация",
    icon: "target",
    type: "positive",
    color: "#22c55e",
    description: "Добра концентрация.",
  },
  {
    id: "creative",
    name: "Креативност",
    icon: "palette",
    type: "positive",
    color: "#a855f7",
    description: "Проявява креативно мислене.",
  },
  {
    id: "teamwork",
    name: "Работа в екип",
    icon: "users",
    type: "positive",
    color: "#3b82f6",
    description: "Отлична работа в екип.",
  },
  {
    id: "leadership",
    name: "Лидерство",
    icon: "star",
    type: "positive",
    color: "#eab308",
    description: "Проявява лидерски качества.",
  },
  {
    id: "helping",
    name: "Помага на другите",
    icon: "handhelping",
    type: "positive",
    color: "#22c55e",
    description: "Ученикът помага на съучениците си.",
  },
  {
    id: "respect",
    name: "Уважителен",
    icon: "thumbsup",
    type: "positive",
    color: "#22c55e",
    description: "Проявява уважение към учители и съученици.",
  },
  {
    id: "punctual",
    name: "Точен",
    icon: "clock",
    type: "positive",
    color: "#22c55e",
    description: "Винаги е точен в час.",
  },
  {
    id: "disciplined",
    name: "Дисциплиниран",
    icon: "check",
    type: "positive",
    color: "#22c55e",
    description: "Спазва училищния ред.",
  },
]

export const NEGATIVE_BADGES: BehaviorBadge[] = [
  {
    id: "aggression",
    name: "Агресия",
    icon: "angry",
    type: "negative",
    color: "#ef4444",
    description: "Проявява агресивно поведение.",
  },
  {
    id: "disrespect",
    name: "Неуважение",
    icon: "megaphone",
    type: "negative",
    color: "#ef4444",
    description: "Проявява неуважение.",
  },
  {
    id: "official_remark",
    name: "Официална забележка",
    icon: "gavel",
    type: "negative",
    color: "#ef4444",
    description: "Получава официална забележка.",
  },
  {
    id: "inattention",
    name: "Липса на внимание",
    icon: "alerttriangle",
    type: "negative",
    color: "#f97316",
    description: "Не внимава в час.",
  },
  {
    id: "bad_discipline",
    name: "Лоша дисциплина",
    icon: "alert",
    type: "negative",
    color: "#f97316",
    description: "Нарушава дисциплината.",
  },
  {
    id: "general_remark",
    name: "Обща забележка",
    icon: "clipboard",
    type: "negative",
    color: "#f97316",
    description: "Обща забележка за поведение.",
  },
  {
    id: "removed_class",
    name: "Отстранен от час",
    icon: "dooropen",
    type: "negative",
    color: "#ef4444",
    description: "Отстранен от учебен час.",
  },
  {
    id: "absence",
    name: "Отсъствие",
    icon: "userminus",
    type: "negative",
    color: "#ef4444",
    description: "Неизвинено отсъствие.",
  },
  {
    id: "poor_performance",
    name: "Слабо представяне",
    icon: "trendingdown",
    type: "negative",
    color: "#f97316",
    description: "Слабо представяне в час.",
  },
  {
    id: "late",
    name: "Закъснение",
    icon: "hourglass",
    type: "negative",
    color: "#f97316",
    description: "Ученикът системно закъснява.",
  },
  {
    id: "no_supplies",
    name: "Без пособия",
    icon: "bookx",
    type: "negative",
    color: "#f97316",
    description: "Няма необходимите учебни пособия.",
  },
  {
    id: "no_uniform",
    name: "Без униформа",
    icon: "shirt",
    type: "negative",
    color: "#f97316",
    description: "Няма училищна униформа.",
  },
  {
    id: "no_homework",
    name: "Без домашна работа",
    icon: "filequestion",
    type: "negative",
    color: "#f97316",
    description: "Не е написал домашна работа.",
  },
  {
    id: "cheating",
    name: "Преписване",
    icon: "copy",
    type: "negative",
    color: "#ef4444",
    description: "Хванат да преписва.",
  },
  {
    id: "bullying",
    name: "Тормоз",
    icon: "frown",
    type: "negative",
    color: "#ef4444",
    description: "Участва в тормоз на съученици.",
  },
]

export const POSITIVE_BEHAVIORS = POSITIVE_BADGES.map((b) => b.name)
export const NEGATIVE_BEHAVIORS = NEGATIVE_BADGES.map((b) => b.name)

export interface BehavioralReview {
  id: string
  studentId: string
  date: string
  type: BehaviorType
  category: string
  badgeId: string // Added badge ID reference
  description: string
  recordedBy: string
}

export interface TeacherLog {
  id: string
  teacherId: string
  studentId: string
  date: string
  subject: string
  notes: string
  strikes: number // max 5
}

export interface StudentLog {
  id: string
  studentId: string
  staffId: string
  staffRole: "psychologist" | "nurse"
  date: string
  school: string
  city: string
  country: string
  notes: string
  confidential: boolean
}

export interface HomeworkAssignment {
  id: string
  teacherId: string
  classId: string
  subject: string
  title: string
  description: string
  dueDate: string
  createdAt: string
}

export interface HomeworkSubmission {
  id: string
  assignmentId: string
  studentId: string
  status: "done" | "partially-done" | "not-done"
  submittedAt?: string
  gradedBy?: string
}

export interface Grade {
  id: string
  studentId: string
  subject: string
  score: number
  maxScore: number
  date: string
  assignmentName: string
  teacherId: string
  gradeType: "current" | "term1" | "term2" | "yearly"
}

export interface SupplyRequest {
  id: string
  teacherId: string
  type: "books" | "workbooks" | "supplies" | "teacher-books"
  itemName: string
  quantity: number
  reason: string
  status: "pending" | "approved" | "denied"
  createdAt: string
  reviewedBy?: string
  reviewedAt?: string
}

export interface Event {
  id: string
  title: string
  description: string
  date: string
  time: string
  location: string
  createdBy: string
  targetRoles: UserRole[]
}

export interface Message {
  id: string
  senderId: string
  receiverId: string // Keep for backward compatibility, now represents first recipient
  receiverIds: string[] // Added for multiple recipients
  subject: string
  content: string
  read: boolean
  important: boolean // Added importance flag
  createdAt: string
}

export interface Notification {
  id: string
  userId: string
  title: string
  message: string
  type: "info" | "warning" | "success" | "error"
  read: boolean
  createdAt: string
}

export interface ClassPeriod {
  period: number
  startTime: string
  duration: number // in minutes
  endTime: string
}

export interface SchoolClass {
  id: string
  name: string
  grade: string
  createdAt: string
  schedule?: ClassPeriod[] // Added schedule/daily regime
  subjects?: string[] // Added subjects for this class
  schoolId?: string // Added school reference
}

export interface TeacherAssignment {
  id: string
  teacherUserId: string
  classId: string
  subjectId: string
}

export interface Teacher {
  id: string
  userId: string
  name: string
  subject: string
  school: string
  city: string
  country: string
  classes: string[]
  assignedClasses?: string[] // Classes teacher is assigned to
  assignedSubjects?: string[] // Subjects teacher can teach
}

export interface Strike {
  id: string
  studentId: string
  reason: string
  issuedBy: string
  date: string
}

export interface FeatureSettings {
  gradesEnabled: boolean
  attendanceEnabled: boolean
  behaviorEnabled: boolean
  homeworkEnabled: boolean
  healthEnabled: boolean
  eventsEnabled: boolean
  messagesEnabled: boolean
  suppliesEnabled: boolean
}

export interface Punishment {
  id: string
  studentId: string
  type: string
  description: string
  issuedBy: string
  issuedByRole: string
  date: string
  expiresAt?: string
}

// Added Subject interface
export interface Subject {
  id: string
  name: string
  createdAt: string
  allowCurrentGrades: boolean
  allowTermGrades: boolean
  allowYearlyGrades: boolean
}

export interface DailySchedule {
  dayOfWeek: number // 1-5 (Monday-Friday)
  periods: {
    period: number
    subjectId: string
    teacherId?: string
  }[]
}

export interface ClassProgram {
  id: string
  classId: string
  schoolId?: string
  weeklySchedule: DailySchedule[]
  createdAt: string
  updatedAt: string
}

export interface Tax {
  id: string
  schoolId: string
  name: string // e.g., "Такса за извънкласни дейности"
  description: string
  amount: number
  currency: string // "лв."
  dueDate: string
  targetClasses: string[] // Which classes this applies to
  targetStudentIds?: string[] // Specific students if not all
  isRecurring: boolean
  recurringPeriod?: "monthly" | "semester" | "yearly"
  createdBy: string
  createdAt: string
}

export interface TaxPayment {
  id: string
  taxId: string
  studentId: string
  paidAmount: number
  paidDate: string
  status: "paid" | "partial" | "unpaid" | "exempt"
  notes?: string
  recordedBy: string
}
