import type {
  User,
  Student,
  Teacher,
  Attendance,
  BehavioralReview,
  TeacherLog,
  StudentLog,
  HomeworkAssignment,
  HomeworkSubmission,
  Grade,
  SupplyRequest,
  Event,
  Message,
  Notification,
  SchoolClass,
  Subject,
  Strike,
  FeatureSettings,
  Punishment,
  TeacherAssignment,
  School,
  SchoolUserRole,
  ClassProgram,
  Tax, // Added Tax import
  TaxPayment, // Added TaxPayment import
} from "./types"

// Storage keys
const STORAGE_KEYS = {
  users: "bamboo_edu_users",
  students: "bamboo_edu_students",
  teachers: "bamboo_edu_teachers",
  attendance: "bamboo_edu_attendance",
  behavioralReviews: "bamboo_edu_behavioral_reviews",
  teacherLogs: "bamboo_edu_teacher_logs",
  studentLogs: "bamboo_edu_student_logs",
  homeworkAssignments: "bamboo_edu_homework_assignments",
  homeworkSubmissions: "bamboo_edu_homework_submissions",
  grades: "bamboo_edu_grades",
  supplyRequests: "bamboo_edu_supply_requests",
  events: "bamboo_edu_events",
  messages: "bamboo_edu_messages",
  notifications: "bamboo_edu_notifications",
  classes: "bamboo_edu_classes",
  subjects: "bamboo_edu_subjects",
  strikes: "bamboo_edu_strikes",
  featureSettings: "bamboo_edu_feature_settings",
  punishments: "bamboo_edu_punishments",
  teacherAssignments: "bamboo_edu_teacher_assignments",
  isShutdown: "bamboo_edu_is_shutdown",
  schools: "bamboo_edu_schools", // Added
  schoolUserRoles: "bamboo_edu_school_user_roles", // Added
  classPrograms: "bamboo_edu_class_programs", // Added class programs storage key
  taxes: "bamboo_edu_taxes", // Added taxes storage key
  taxPayments: "bamboo_edu_tax_payments", // Added tax payments storage key
}

// Initialize with admin account
const initialUsers: User[] = [
  {
    id: "1",
    email: "didopetdim@gmail.com",
    password: "Pe8699267",
    name: "Admin User",
    role: "admin",
    createdAt: new Date(),
  },
]

const defaultSubjects: Subject[] = [
  {
    id: "1",
    name: "Български език и литература",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "2",
    name: "Математика",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "3",
    name: "Английски език",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "4",
    name: "Немски език",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "5",
    name: "Руски език",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "6",
    name: "Френски език",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "7",
    name: "Испански език",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "8",
    name: "История и цивилизации",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "9",
    name: "География и икономика",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "10",
    name: "Физика и астрономия",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "11",
    name: "Химия и опазване на околната среда",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "12",
    name: "Биология и здравно образование",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "13",
    name: "Информатика",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "14",
    name: "Информационни технологии",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "15",
    name: "Философия",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "16",
    name: "Гражданско образование",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "17",
    name: "Музика",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "18",
    name: "Изобразително изкуство",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "19",
    name: "Физическо възпитание и спорт",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "20",
    name: "Технологии и предприемачество",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "21",
    name: "Човекът и природата",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "22",
    name: "Човекът и обществото",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "23",
    name: "Домашен бит и техника",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "24",
    name: "Религия",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "25",
    name: "Психология и логика",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "26",
    name: "Етика и право",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
  {
    id: "27",
    name: "Свят и личност",
    createdAt: new Date().toISOString(),
    allowCurrentGrades: true,
    allowTermGrades: true,
    allowYearlyGrades: true,
  },
]

const defaultClasses: SchoolClass[] = [
  { id: "1", name: "1А", grade: "1", createdAt: new Date().toISOString() },
  { id: "2", name: "1Б", grade: "1", createdAt: new Date().toISOString() },
  { id: "3", name: "2А", grade: "2", createdAt: new Date().toISOString() },
  { id: "4", name: "2Б", grade: "2", createdAt: new Date().toISOString() },
  { id: "5", name: "3А", grade: "3", createdAt: new Date().toISOString() },
  { id: "6", name: "3Б", grade: "3", createdAt: new Date().toISOString() },
  { id: "7", name: "4А", grade: "4", createdAt: new Date().toISOString() },
  { id: "8", name: "4Б", grade: "4", createdAt: new Date().toISOString() },
  { id: "9", name: "5А", grade: "5", createdAt: new Date().toISOString() },
  { id: "10", name: "5Б", grade: "5", createdAt: new Date().toISOString() },
  { id: "11", name: "6А", grade: "6", createdAt: new Date().toISOString() },
  { id: "12", name: "6Б", grade: "6", createdAt: new Date().toISOString() },
  { id: "13", name: "7А", grade: "7", createdAt: new Date().toISOString() },
  { id: "14", name: "7Б", grade: "7", createdAt: new Date().toISOString() },
  { id: "15", name: "8А", grade: "8", createdAt: new Date().toISOString() },
  { id: "16", name: "8Б", grade: "8", createdAt: new Date().toISOString() },
  { id: "17", name: "9А", grade: "9", createdAt: new Date().toISOString() },
  { id: "18", name: "9Б", grade: "9", createdAt: new Date().toISOString() },
  { id: "19", name: "10А", grade: "10", createdAt: new Date().toISOString() },
  { id: "20", name: "10Б", grade: "10", createdAt: new Date().toISOString() },
  { id: "21", name: "11А", grade: "11", createdAt: new Date().toISOString() },
  { id: "22", name: "11Б", grade: "11", createdAt: new Date().toISOString() },
  { id: "23", name: "12А", grade: "12", createdAt: new Date().toISOString() },
  { id: "24", name: "12Б", grade: "12", createdAt: new Date().toISOString() },
]

const defaultFeatureSettings: FeatureSettings = {
  gradesEnabled: true,
  attendanceEnabled: true,
  behaviorEnabled: true,
  homeworkEnabled: true,
  healthEnabled: true,
  eventsEnabled: true,
  messagesEnabled: true,
  suppliesEnabled: true,
}

// Helper functions for localStorage - runs only on client side
const isClient = typeof window !== "undefined"

function loadFromStorage<T>(key: string, defaultValue: T): T {
  if (!isClient) return defaultValue
  try {
    const stored = localStorage.getItem(key)
    if (stored) {
      return JSON.parse(stored)
    }
  } catch (e) {
    console.error(`Error loading ${key} from localStorage:`, e)
  }
  return defaultValue
}

function saveToStorage<T>(key: string, data: T): void {
  if (!isClient) return
  try {
    localStorage.setItem(key, JSON.stringify(data))
  } catch (e) {
    console.error(`Error saving ${key} to localStorage:`, e)
  }
}

class DataStore {
  private getUsers(): User[] {
    const stored = loadFromStorage<User[]>(STORAGE_KEYS.users, [])
    if (stored.length === 0) {
      // Initialize with admin if no users exist
      saveToStorage(STORAGE_KEYS.users, initialUsers)
      return [...initialUsers]
    }
    return stored
  }

  private setUsers(users: User[]): void {
    saveToStorage(STORAGE_KEYS.users, users)
  }

  // Auth methods
  login(email: string, password: string): User | null {
    if (this.getShutdownStatus()) return null
    return this.getUsers().find((u) => u.email === email && u.password === password) || null
  }

  // User methods
  getAllUsers(): User[] {
    return this.getUsers()
  }
  getUserById(id: string): User | undefined {
    return this.getUsers().find((u) => u.id === id)
  }
  addUser(user: User): void {
    const users = this.getUsers()
    users.push(user)
    this.setUsers(users)
  }
  updateUser(id: string, data: Partial<User>): void {
    const users = this.getUsers()
    const index = users.findIndex((u) => u.id === id)
    if (index !== -1) {
      users[index] = { ...users[index], ...data }
      this.setUsers(users)
    }
  }
  deleteUser(id: string): void {
    const users = this.getUsers().filter((u) => u.id !== id)
    this.setUsers(users)
  }

  // School methods (Added)
  getSchools(): School[] {
    return loadFromStorage<School[]>(STORAGE_KEYS.schools, [])
  }
  private setSchools(schools: School[]): void {
    saveToStorage(STORAGE_KEYS.schools, schools)
  }
  getSchoolById(id: string): School | undefined {
    return this.getSchools().find((s) => s.id === id)
  }
  addSchool(school: School): void {
    const schools = this.getSchools()
    schools.push(school)
    this.setSchools(schools)
  }
  updateSchool(id: string, data: Partial<School>): void {
    const schools = this.getSchools()
    const index = schools.findIndex((s) => s.id === id)
    if (index !== -1) {
      schools[index] = { ...schools[index], ...data }
      this.setSchools(schools)
    }
  }
  deleteSchool(id: string): void {
    const schools = this.getSchools().filter((s) => s.id !== id)
    this.setSchools(schools)
  }

  // School User Role methods (Added)
  getSchoolUserRoles(): SchoolUserRole[] {
    return loadFromStorage<SchoolUserRole[]>(STORAGE_KEYS.schoolUserRoles, [])
  }
  private setSchoolUserRoles(roles: SchoolUserRole[]): void {
    saveToStorage(STORAGE_KEYS.schoolUserRoles, roles)
  }
  addSchoolUserRole(role: SchoolUserRole): void {
    const roles = this.getSchoolUserRoles()
    roles.push(role)
    this.setSchoolUserRoles(roles)
  }
  deleteSchoolUserRole(id: string): void {
    const roles = this.getSchoolUserRoles().filter((r) => r.id !== id)
    this.setSchoolUserRoles(roles)
  }
  getSchoolUserRolesByUser(userId: string): SchoolUserRole[] {
    return this.getSchoolUserRoles().filter((r) => r.userId === userId)
  }
  getSchoolUserRolesBySchool(schoolId: string): SchoolUserRole[] {
    return this.getSchoolUserRoles().filter((r) => r.schoolId === schoolId)
  }
  getUserRoleInSchool(userId: string, schoolId: string): string | null {
    const role = this.getSchoolUserRoles().find((r) => r.userId === userId && r.schoolId === schoolId)
    return role ? role.role : null
  }
  isDirectorOfSchool(userId: string, schoolId: string): boolean {
    const role = this.getUserRoleInSchool(userId, schoolId)
    return role === "principal" || role === "vice-principal"
  }

  // Student methods
  getStudents(): Student[] {
    return loadFromStorage<Student[]>(STORAGE_KEYS.students, [])
  }
  private setStudents(students: Student[]): void {
    saveToStorage(STORAGE_KEYS.students, students)
  }
  getStudentById(id: string): Student | undefined {
    return this.getStudents().find((s) => s.id === id)
  }
  addStudent(student: Student): void {
    const students = this.getStudents()
    students.push(student)
    this.setStudents(students)
  }
  updateStudent(id: string, data: Partial<Student>): void {
    const students = this.getStudents()
    const index = students.findIndex((s) => s.id === id)
    if (index !== -1) {
      students[index] = { ...students[index], ...data }
      this.setStudents(students)
    }
  }
  deleteStudent(id: string): void {
    const students = this.getStudents().filter((s) => s.id !== id)
    this.setStudents(students)
  }
  getStudentByUserId(userId: string): Student | undefined {
    const storedLinks = loadFromStorage<{ studentId: string; userId: string }[]>("bamboo_edu_student_links", [])
    const link = storedLinks.find((l) => l.userId === userId)
    if (link) {
      return this.getStudents().find((s) => s.id === link.studentId)
    }
    return this.getStudents().find((s) => s.linkedUserId === userId)
  }
  getStudentByParentId(parentUserId: string): Student | undefined {
    const storedLinks = loadFromStorage<{ studentId: string; parentUserId: string }[]>("bamboo_edu_parent_links", [])
    const link = storedLinks.find((l) => l.parentUserId === parentUserId)
    if (link) {
      return this.getStudents().find((s) => s.id === link.studentId)
    }
    return this.getStudents().find((s) => s.parentId === parentUserId)
  }
  getStudentsByParentId(parentUserId: string): Student[] {
    const linkedStudents: Student[] = []
    const storedLinks = loadFromStorage<{ studentId: string; parentUserId: string }[]>("bamboo_edu_parent_links", [])
    const parentLinks = storedLinks.filter((l) => l.parentUserId === parentUserId)
    const students = this.getStudents()
    parentLinks.forEach((link) => {
      const student = students.find((s) => s.id === link.studentId)
      if (student) linkedStudents.push(student)
    })
    students.forEach((s) => {
      if (s.parentId === parentUserId && !linkedStudents.find((ls) => ls.id === s.id)) {
        linkedStudents.push(s)
      }
    })
    return linkedStudents
  }
  getStudentsByClass(classId: string): Student[] {
    // Added
    return this.getStudents().filter((s) => s.class === classId)
  }
  getStudentsBySchool(schoolId: string): Student[] {
    // Added
    return this.getStudents().filter((s) => s.schoolId === schoolId)
  }
  linkParentToStudent(studentId: string, parentUserId: string): void {
    const storedLinks = loadFromStorage<{ studentId: string; parentUserId: string }[]>("bamboo_edu_parent_links", [])
    const existingIndex = storedLinks.findIndex((l) => l.studentId === studentId && l.parentUserId === parentUserId)
    if (existingIndex === -1) {
      storedLinks.push({ studentId, parentUserId })
      saveToStorage("bamboo_edu_parent_links", storedLinks)
    }
  }

  // Teacher methods
  getTeachers(): Teacher[] {
    return loadFromStorage<Teacher[]>(STORAGE_KEYS.teachers, [])
  }
  private setTeachers(teachers: Teacher[]): void {
    saveToStorage(STORAGE_KEYS.teachers, teachers)
  }
  getTeacherById(id: string): Teacher | undefined {
    return this.getTeachers().find((t) => t.id === id)
  }
  getTeacherByUserId(userId: string): Teacher | undefined {
    return this.getTeachers().find((t) => t.userId === userId)
  }
  addTeacher(teacher: Teacher): void {
    const teachers = this.getTeachers()
    teachers.push(teacher)
    this.setTeachers(teachers)
  }
  updateTeacher(id: string, data: Partial<Teacher>): void {
    const teachers = this.getTeachers()
    const index = teachers.findIndex((t) => t.id === id)
    if (index !== -1) {
      teachers[index] = { ...teachers[index], ...data }
      this.setTeachers(teachers)
    }
  }
  deleteTeacher(id: string): void {
    const teachers = this.getTeachers().filter((t) => t.id !== id)
    this.setTeachers(teachers)
  }

  // Attendance methods
  getAttendance(): Attendance[] {
    return loadFromStorage<Attendance[]>(STORAGE_KEYS.attendance, [])
  }
  private setAttendance(records: Attendance[]): void {
    saveToStorage(STORAGE_KEYS.attendance, records)
  }
  getAttendanceByStudent(studentId: string): Attendance[] {
    return this.getAttendance().filter((a) => a.studentId === studentId)
  }
  addAttendance(record: Attendance): void {
    const records = this.getAttendance()
    records.push(record)
    this.setAttendance(records)
  }
  updateAttendance(id: string, data: Partial<Attendance>): void {
    const records = this.getAttendance()
    const index = records.findIndex((a) => a.id === id)
    if (index !== -1) {
      records[index] = { ...records[index], ...data }
      this.setAttendance(records)
    }
  }
  deleteAttendance(id: string): void {
    const records = this.getAttendance().filter((a) => a.id !== id)
    this.setAttendance(records)
  }

  // Behavioral review methods
  getBehavioralReviews(): BehavioralReview[] {
    return loadFromStorage<BehavioralReview[]>(STORAGE_KEYS.behavioralReviews, [])
  }
  private setBehavioralReviews(reviews: BehavioralReview[]): void {
    saveToStorage(STORAGE_KEYS.behavioralReviews, reviews)
  }
  getBehavioralReviewsByStudent(studentId: string): BehavioralReview[] {
    return this.getBehavioralReviews().filter((b) => b.studentId === studentId)
  }
  addBehavioralReview(review: BehavioralReview): void {
    const reviews = this.getBehavioralReviews()
    reviews.push(review)
    this.setBehavioralReviews(reviews)
  }
  deleteBehavioralReview(id: string): void {
    const reviews = this.getBehavioralReviews().filter((b) => b.id !== id)
    this.setBehavioralReviews(reviews)
  }

  // Teacher log methods
  getTeacherLogs(): TeacherLog[] {
    return loadFromStorage<TeacherLog[]>(STORAGE_KEYS.teacherLogs, [])
  }
  private setTeacherLogs(logs: TeacherLog[]): void {
    saveToStorage(STORAGE_KEYS.teacherLogs, logs)
  }
  getTeacherLogsByStudent(studentId: string): TeacherLog[] {
    return this.getTeacherLogs().filter((l) => l.studentId === studentId)
  }
  addTeacherLog(log: TeacherLog): void {
    const logs = this.getTeacherLogs()
    logs.push(log)
    this.setTeacherLogs(logs)
  }
  updateTeacherLog(id: string, data: Partial<TeacherLog>): void {
    const logs = this.getTeacherLogs()
    const index = logs.findIndex((l) => l.id === id)
    if (index !== -1) {
      logs[index] = { ...logs[index], ...data }
      this.setTeacherLogs(logs)
    }
  }
  deleteTeacherLog(id: string): void {
    const logs = this.getTeacherLogs().filter((l) => l.id !== id)
    this.setTeacherLogs(logs)
  }

  // Student log methods (for psychologist/nurse)
  getStudentLogs(): StudentLog[] {
    return loadFromStorage<StudentLog[]>(STORAGE_KEYS.studentLogs, [])
  }
  private setStudentLogs(logs: StudentLog[]): void {
    saveToStorage(STORAGE_KEYS.studentLogs, logs)
  }
  getStudentLogsByStudent(studentId: string): StudentLog[] {
    return this.getStudentLogs().filter((l) => l.studentId === studentId)
  }
  getStudentLogsByStaff(staffId: string): StudentLog[] {
    return this.getStudentLogs().filter((l) => l.staffId === staffId)
  }
  addStudentLog(log: StudentLog): void {
    const logs = this.getStudentLogs()
    logs.push(log)
    this.setStudentLogs(logs)
  }
  deleteStudentLog(id: string): void {
    const logs = this.getStudentLogs().filter((l) => l.id !== id)
    this.setStudentLogs(logs)
  }

  // Homework methods
  getHomeworkAssignments(): HomeworkAssignment[] {
    return loadFromStorage<HomeworkAssignment[]>(STORAGE_KEYS.homeworkAssignments, [])
  }
  private setHomeworkAssignments(assignments: HomeworkAssignment[]): void {
    saveToStorage(STORAGE_KEYS.homeworkAssignments, assignments)
  }
  getHomeworkByTeacher(teacherId: string): HomeworkAssignment[] {
    return this.getHomeworkAssignments().filter((h) => h.teacherId === teacherId)
  }
  getHomeworkByClass(classId: string): HomeworkAssignment[] {
    return this.getHomeworkAssignments().filter((h) => h.classId === classId)
  }
  addHomeworkAssignment(assignment: HomeworkAssignment): void {
    const assignments = this.getHomeworkAssignments()
    assignments.push(assignment)
    this.setHomeworkAssignments(assignments)
  }
  updateHomeworkAssignment(id: string, data: Partial<HomeworkAssignment>): void {
    const assignments = this.getHomeworkAssignments()
    const index = assignments.findIndex((a) => a.id === id)
    if (index !== -1) {
      assignments[index] = { ...assignments[index], ...data }
      this.setHomeworkAssignments(assignments)
    }
  }
  deleteHomeworkAssignment(id: string): void {
    const assignments = this.getHomeworkAssignments().filter((a) => a.id !== id)
    this.setHomeworkAssignments(assignments)
  }

  getHomeworkSubmissions(): HomeworkSubmission[] {
    return loadFromStorage<HomeworkSubmission[]>(STORAGE_KEYS.homeworkSubmissions, [])
  }
  private setHomeworkSubmissions(submissions: HomeworkSubmission[]): void {
    saveToStorage(STORAGE_KEYS.homeworkSubmissions, submissions)
  }
  getSubmissionsByAssignment(assignmentId: string): HomeworkSubmission[] {
    return this.getHomeworkSubmissions().filter((s) => s.assignmentId === assignmentId)
  }
  getSubmissionsByStudent(studentId: string): HomeworkSubmission[] {
    return this.getHomeworkSubmissions().filter((s) => s.studentId === studentId)
  }
  addHomeworkSubmission(submission: HomeworkSubmission): void {
    const submissions = this.getHomeworkSubmissions()
    submissions.push(submission)
    this.setHomeworkSubmissions(submissions)
  }
  updateHomeworkSubmission(id: string, data: Partial<HomeworkSubmission>): void {
    const submissions = this.getHomeworkSubmissions()
    const index = submissions.findIndex((s) => s.id === id)
    if (index !== -1) {
      submissions[index] = { ...submissions[index], ...data }
      this.setHomeworkSubmissions(submissions)
    }
  }

  // Grade methods
  getGrades(): Grade[] {
    return loadFromStorage<Grade[]>(STORAGE_KEYS.grades, [])
  }
  private setGrades(grades: Grade[]): void {
    saveToStorage(STORAGE_KEYS.grades, grades)
  }
  getGradesByStudent(studentId: string): Grade[] {
    return this.getGrades().filter((g) => g.studentId === studentId)
  }
  getGradesBySubject(studentId: string, subject: string): Grade[] {
    return this.getGrades().filter((g) => g.studentId === studentId && g.subject === subject)
  }
  addGrade(grade: Grade): void {
    const grades = this.getGrades()
    grades.push(grade)
    this.setGrades(grades)
  }
  updateGrade(id: string, data: Partial<Grade>): void {
    const grades = this.getGrades()
    const index = grades.findIndex((g) => g.id === id)
    if (index !== -1) {
      grades[index] = { ...grades[index], ...data }
      this.setGrades(grades)
    }
  }
  deleteGrade(gradeId: string): void {
    const grades = this.getGrades().filter((g) => g.id !== gradeId)
    this.setGrades(grades)
  }

  // Supply request methods
  getSupplyRequests(): SupplyRequest[] {
    return loadFromStorage<SupplyRequest[]>(STORAGE_KEYS.supplyRequests, [])
  }
  private setSupplyRequests(requests: SupplyRequest[]): void {
    saveToStorage(STORAGE_KEYS.supplyRequests, requests)
  }
  getSupplyRequestsByTeacher(teacherId: string): SupplyRequest[] {
    return this.getSupplyRequests().filter((s) => s.teacherId === teacherId)
  }
  getPendingSupplyRequests(): SupplyRequest[] {
    return this.getSupplyRequests().filter((s) => s.status === "pending")
  }
  addSupplyRequest(request: SupplyRequest): void {
    const requests = this.getSupplyRequests()
    requests.push(request)
    this.setSupplyRequests(requests)
  }
  updateSupplyRequest(id: string, data: Partial<SupplyRequest>): void {
    const requests = this.getSupplyRequests()
    const index = requests.findIndex((s) => s.id === id)
    if (index !== -1) {
      requests[index] = { ...requests[index], ...data }
      this.setSupplyRequests(requests)
    }
  }
  deleteSupplyRequest(id: string): void {
    const requests = this.getSupplyRequests().filter((s) => s.id !== id)
    this.setSupplyRequests(requests)
  }

  // Event methods
  getEvents(): Event[] {
    return loadFromStorage<Event[]>(STORAGE_KEYS.events, [])
  }
  private setEvents(events: Event[]): void {
    saveToStorage(STORAGE_KEYS.events, events)
  }
  getEventsByRole(role: string): Event[] {
    return this.getEvents().filter((e) => e.targetRoles.includes(role as any))
  }
  addEvent(event: Event): void {
    const events = this.getEvents()
    events.push(event)
    this.setEvents(events)
  }
  updateEvent(id: string, data: Partial<Event>): void {
    const events = this.getEvents()
    const index = events.findIndex((e) => e.id === id)
    if (index !== -1) {
      events[index] = { ...events[index], ...data }
      this.setEvents(events)
    }
  }
  deleteEvent(id: string): void {
    const events = this.getEvents().filter((e) => e.id !== id)
    this.setEvents(events)
  }

  // Message methods
  getMessages(): Message[] {
    return loadFromStorage<Message[]>(STORAGE_KEYS.messages, [])
  }
  private setMessages(messages: Message[]): void {
    saveToStorage(STORAGE_KEYS.messages, messages)
  }
  getMessagesByUser(userId: string): Message[] {
    return this.getMessages().filter(
      (m) => m.receiverId === userId || m.receiverIds?.includes(userId) || m.senderId === userId,
    )
  }
  getInbox(userId: string): Message[] {
    return this.getMessages().filter((m) => m.receiverId === userId || m.receiverIds?.includes(userId))
  }
  getSent(userId: string): Message[] {
    return this.getMessages().filter((m) => m.senderId === userId)
  }
  addMessage(message: Message): void {
    const messages = this.getMessages()
    messages.push(message)
    this.setMessages(messages)
  }
  markMessageRead(id: string): void {
    const messages = this.getMessages()
    const index = messages.findIndex((m) => m.id === id)
    if (index !== -1) {
      messages[index].read = true
      this.setMessages(messages)
    }
  }
  deleteMessage(id: string): void {
    const messages = this.getMessages().filter((m) => m.id !== id)
    this.setMessages(messages)
  }

  // Notification methods
  getNotifications(): Notification[] {
    return loadFromStorage<Notification[]>(STORAGE_KEYS.notifications, [])
  }
  private setNotifications(notifications: Notification[]): void {
    saveToStorage(STORAGE_KEYS.notifications, notifications)
  }
  getNotificationsByUser(userId: string): Notification[] {
    return this.getNotifications().filter((n) => n.userId === userId)
  }
  getUnreadNotifications(userId: string): Notification[] {
    return this.getNotifications().filter((n) => n.userId === userId && !n.read)
  }
  addNotification(notification: Notification): void {
    const notifications = this.getNotifications()
    notifications.push(notification)
    this.setNotifications(notifications)
  }
  markNotificationRead(id: string): void {
    const notifications = this.getNotifications()
    const index = notifications.findIndex((n) => n.id === id)
    if (index !== -1) {
      notifications[index].read = true
      this.setNotifications(notifications)
    }
  }
  markAllNotificationsRead(userId: string): void {
    const notifications = this.getNotifications()
    notifications.forEach((n) => {
      if (n.userId === userId) n.read = true
    })
    this.setNotifications(notifications)
  }
  deleteNotification(id: string): void {
    const notifications = this.getNotifications().filter((n) => n.id !== id)
    this.setNotifications(notifications)
  }

  // Class methods
  getClasses(): SchoolClass[] {
    const stored = loadFromStorage<SchoolClass[]>(STORAGE_KEYS.classes, [])
    if (stored.length === 0) {
      saveToStorage(STORAGE_KEYS.classes, defaultClasses)
      return [...defaultClasses]
    }
    return stored
  }
  private setClasses(classes: SchoolClass[]): void {
    saveToStorage(STORAGE_KEYS.classes, classes)
  }
  addClass(schoolClass: SchoolClass): void {
    const classes = this.getClasses()
    classes.push(schoolClass)
    this.setClasses(classes)
  }
  updateClass(id: string, data: Partial<SchoolClass>): void {
    const classes = this.getClasses()
    const index = classes.findIndex((c) => c.id === id)
    if (index !== -1) {
      classes[index] = { ...classes[index], ...data }
      this.setClasses(classes)
    }
  }
  deleteClass(id: string): void {
    const classes = this.getClasses().filter((c) => c.id !== id)
    this.setClasses(classes)
  }

  // Subject methods
  getSubjects(): Subject[] {
    const stored = loadFromStorage<Subject[]>(STORAGE_KEYS.subjects, [])
    if (stored.length === 0) {
      saveToStorage(STORAGE_KEYS.subjects, defaultSubjects)
      return [...defaultSubjects]
    }
    return stored
  }
  private setSubjects(subjects: Subject[]): void {
    saveToStorage(STORAGE_KEYS.subjects, subjects)
  }
  addSubject(subject: Subject): void {
    const subjects = this.getSubjects()
    subjects.push(subject)
    this.setSubjects(subjects)
  }
  updateSubject(id: string, data: Partial<Subject>): void {
    const subjects = this.getSubjects()
    const index = subjects.findIndex((s) => s.id === id)
    if (index !== -1) {
      subjects[index] = { ...subjects[index], ...data }
      this.setSubjects(subjects)
    }
  }
  deleteSubject(id: string): void {
    const subjects = this.getSubjects().filter((s) => s.id !== id)
    this.setSubjects(subjects)
  }

  // Strike methods
  getStrikes(): Strike[] {
    return loadFromStorage<Strike[]>(STORAGE_KEYS.strikes, [])
  }
  private setStrikes(strikes: Strike[]): void {
    saveToStorage(STORAGE_KEYS.strikes, strikes)
  }
  getStrikesByStudent(studentId: string): Strike[] {
    return this.getStrikes().filter((s) => s.studentId === studentId)
  }
  addStrike(strike: Strike): void {
    const strikes = this.getStrikes()
    strikes.push(strike)
    this.setStrikes(strikes)
  }
  deleteStrike(id: string): void {
    const strikes = this.getStrikes().filter((s) => s.id !== id)
    this.setStrikes(strikes)
  }
  deleteStrikesByStudent(studentId: string): void {
    const strikes = this.getStrikes().filter((s) => s.studentId !== studentId)
    this.setStrikes(strikes)
  }

  // Feature settings methods
  getFeatureSettings(): FeatureSettings {
    return loadFromStorage<FeatureSettings>(STORAGE_KEYS.featureSettings, defaultFeatureSettings)
  }
  updateFeatureSettings(settings: Partial<FeatureSettings>): void {
    const current = this.getFeatureSettings()
    saveToStorage(STORAGE_KEYS.featureSettings, { ...current, ...settings })
  }

  // Punishment methods
  getPunishments(): Punishment[] {
    return loadFromStorage<Punishment[]>(STORAGE_KEYS.punishments, [])
  }
  private setPunishments(punishments: Punishment[]): void {
    saveToStorage(STORAGE_KEYS.punishments, punishments)
  }
  getPunishmentsByStudent(studentId: string): Punishment[] {
    return this.getPunishments().filter((p) => p.studentId === studentId)
  }
  addPunishment(punishment: Punishment): void {
    const punishments = this.getPunishments()
    punishments.push(punishment)
    this.setPunishments(punishments)
  }
  deletePunishment(id: string): void {
    const punishments = this.getPunishments().filter((p) => p.id !== id)
    this.setPunishments(punishments)
  }

  // Teacher assignment methods
  getTeacherAssignments(): TeacherAssignment[] {
    return loadFromStorage<TeacherAssignment[]>(STORAGE_KEYS.teacherAssignments, [])
  }
  private setTeacherAssignments(assignments: TeacherAssignment[]): void {
    saveToStorage(STORAGE_KEYS.teacherAssignments, assignments)
  }
  getTeacherAssignmentsByTeacher(teacherId: string): TeacherAssignment[] {
    return this.getTeacherAssignments().filter((a) => a.teacherId === teacherId)
  }
  addTeacherAssignment(assignment: TeacherAssignment): void {
    const assignments = this.getTeacherAssignments()
    assignments.push(assignment)
    this.setTeacherAssignments(assignments)
  }
  deleteTeacherAssignment(id: string): void {
    const assignments = this.getTeacherAssignments().filter((a) => a.id !== id)
    this.setTeacherAssignments(assignments)
  }

  // Class Program methods
  getClassPrograms(): ClassProgram[] {
    return loadFromStorage<ClassProgram[]>(STORAGE_KEYS.classPrograms, [])
  }

  getClassProgramByClassId(classId: string): ClassProgram | undefined {
    return this.getClassPrograms().find((p) => p.classId === classId)
  }

  addClassProgram(program: ClassProgram) {
    const programs = this.getClassPrograms()
    programs.push(program)
    saveToStorage(STORAGE_KEYS.classPrograms, programs)
  }

  updateClassProgram(programId: string, updates: Partial<ClassProgram>) {
    const programs = this.getClassPrograms()
    const index = programs.findIndex((p) => p.id === programId)
    if (index !== -1) {
      programs[index] = { ...programs[index], ...updates, updatedAt: new Date().toISOString() }
      saveToStorage(STORAGE_KEYS.classPrograms, programs)
    }
  }

  deleteClassProgram(programId: string) {
    const programs = this.getClassPrograms().filter((p) => p.id !== programId)
    saveToStorage(STORAGE_KEYS.classPrograms, programs)
  }

  getTaxes(): Tax[] {
    return loadFromStorage(STORAGE_KEYS.taxes, [])
  }

  getTaxesBySchool(schoolId: string): Tax[] {
    return this.getTaxes().filter((t) => t.schoolId === schoolId)
  }

  addTax(tax: Tax): void {
    const taxes = this.getTaxes()
    taxes.push(tax)
    saveToStorage(STORAGE_KEYS.taxes, taxes)
  }

  updateTax(id: string, updates: Partial<Tax>): void {
    const taxes = this.getTaxes()
    const index = taxes.findIndex((t) => t.id === id)
    if (index !== -1) {
      taxes[index] = { ...taxes[index], ...updates }
      saveToStorage(STORAGE_KEYS.taxes, taxes)
    }
  }

  deleteTax(id: string): void {
    const taxes = this.getTaxes().filter((t) => t.id !== id)
    saveToStorage(STORAGE_KEYS.taxes, taxes)
  }

  getTaxPayments(): TaxPayment[] {
    return loadFromStorage(STORAGE_KEYS.taxPayments, [])
  }

  getTaxPaymentsByTax(taxId: string): TaxPayment[] {
    return this.getTaxPayments().filter((p) => p.taxId === taxId)
  }

  getTaxPaymentsByStudent(studentId: string): TaxPayment[] {
    return this.getTaxPayments().filter((p) => p.studentId === studentId)
  }

  addTaxPayment(payment: TaxPayment): void {
    const payments = this.getTaxPayments()
    payments.push(payment)
    saveToStorage(STORAGE_KEYS.taxPayments, payments)
  }

  updateTaxPayment(id: string, updates: Partial<TaxPayment>): void {
    const payments = this.getTaxPayments()
    const index = payments.findIndex((p) => p.id === id)
    if (index !== -1) {
      payments[index] = { ...payments[index], ...updates }
      saveToStorage(STORAGE_KEYS.taxPayments, payments)
    }
  }

  // Admin methods
  exportAllData(): object {
    return {
      users: this.getAllUsers(),
      students: this.getStudents(),
      teachers: this.getTeachers(),
      attendance: this.getAttendance(),
      behavioralReviews: this.getBehavioralReviews(),
      teacherLogs: this.getTeacherLogs(),
      studentLogs: this.getStudentLogs(),
      homeworkAssignments: this.getHomeworkAssignments(),
      homeworkSubmissions: this.getHomeworkSubmissions(),
      grades: this.getGrades(),
      supplyRequests: this.getSupplyRequests(),
      events: this.getEvents(),
      messages: this.getMessages(),
      notifications: this.getNotifications(),
      classes: this.getClasses(),
      subjects: this.getSubjects(),
      strikes: this.getStrikes(),
      featureSettings: this.getFeatureSettings(),
      punishments: this.getPunishments(),
      teacherAssignments: this.getTeacherAssignments(),
      schools: this.getSchools(), // Added
      schoolUserRoles: this.getSchoolUserRoles(), // Added
      classPrograms: this.getClassPrograms(), // Added
      taxes: this.getTaxes(), // Added
      taxPayments: this.getTaxPayments(), // Added
      exportedAt: new Date().toISOString(),
    }
  }

  deleteAllData(): void {
    Object.values(STORAGE_KEYS).forEach((key) => {
      if (isClient) localStorage.removeItem(key)
    })
    if (isClient) {
      localStorage.removeItem("bamboo_edu_student_links")
      localStorage.removeItem("bamboo_edu_parent_links")
    }
    const adminUser = this.getAllUsers().find((u) => u.role === "admin")
    if (adminUser) {
      this.setUsers([adminUser])
    }
    saveToStorage(STORAGE_KEYS.classes, defaultClasses)
    saveToStorage(STORAGE_KEYS.subjects, defaultSubjects)
    saveToStorage(STORAGE_KEYS.featureSettings, defaultFeatureSettings)
  }

  shutdownSite(): void {
    saveToStorage(STORAGE_KEYS.isShutdown, true)
  }
  restoreSite(): void {
    saveToStorage(STORAGE_KEYS.isShutdown, false)
  }
  getShutdownStatus(): boolean {
    return loadFromStorage<boolean>(STORAGE_KEYS.isShutdown, false)
  }

  // Added methods
  isPrincipalOfSchool(userId: string, schoolId: string): boolean {
    // Added
    const roles = this.getSchoolUserRoles()
    return roles.some(
      (r) => r.userId === userId && r.schoolId === schoolId && (r.role === "principal" || r.role === "vice-principal"),
    )
  }

  getUserPrincipalSchools(userId: string): string[] {
    // Added
    const roles = this.getSchoolUserRoles()
    return roles
      .filter((r) => r.userId === userId && (r.role === "principal" || r.role === "vice-principal"))
      .map((r) => r.schoolId)
  }
}

export const dataStore = new DataStore()
